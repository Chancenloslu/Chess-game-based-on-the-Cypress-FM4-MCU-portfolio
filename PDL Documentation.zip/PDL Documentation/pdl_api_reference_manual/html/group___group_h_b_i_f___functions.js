var group___group_h_b_i_f___functions =
[
    [ "Hbif_Init", "group___group_h_b_i_f___functions.html#ga0857b6770b6516bd27eb485fb6b45702", null ],
    [ "Hbif_DeInit", "group___group_h_b_i_f___functions.html#ga46bbe2f41f49e00614ae952d29074870", null ],
    [ "Hbif_GetStatus", "group___group_h_b_i_f___functions.html#gad61f82f66996e1de2c2f265367b36b11", null ],
    [ "Hbif_GetInterruptFlag", "group___group_h_b_i_f___functions.html#gafa36408c737ae2fd769a908438a37dbf", null ],
    [ "Hbif_SetWriteProtection", "group___group_h_b_i_f___functions.html#ga8ef61a2f95627e63781c81f3d64e070e", null ],
    [ "Hbif_SetGpo0Level", "group___group_h_b_i_f___functions.html#ga884814308fe1203dd1aceca756d84cb3", null ],
    [ "Hbif_SetGpo1Level", "group___group_h_b_i_f___functions.html#ga6b660f9b343f5e308dfaf356af5e4f84", null ]
];