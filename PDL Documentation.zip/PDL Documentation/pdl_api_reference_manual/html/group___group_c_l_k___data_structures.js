var group___group_c_l_k___data_structures =
[
    [ "stc_clk_intern_data_t", "structstc__clk__intern__data__t.html", [
      [ "pfnPllStabCb", "structstc__clk__intern__data__t.html#a21b0482a8d4a22089bbfbbbd3207fb14", null ],
      [ "pfnScoStabCb", "structstc__clk__intern__data__t.html#a8a2078445f35e4f80143a394312bdb81", null ],
      [ "pfnMcoStabCb", "structstc__clk__intern__data__t.html#a3bc7805e9ca215bf17d5530d10fdbbc4", null ]
    ] ],
    [ "stc_clk_config_t", "structstc__clk__config__t.html", [
      [ "enBaseClkDiv", "structstc__clk__config__t.html#a50df519f931bb13256770485454d8938", null ],
      [ "enAPB0Div", "structstc__clk__config__t.html#abbd5f7a8efdb8dfcd985824cb80af8e7", null ],
      [ "enAPB1Div", "structstc__clk__config__t.html#a3897f8a92bc112e5e054eca2e5be88aa", null ],
      [ "enAPB2Div", "structstc__clk__config__t.html#a52c8a78ecb57f90aee89a69abe09e8fb", null ],
      [ "bAPB1Disable", "structstc__clk__config__t.html#a97cdc2de7e60f72f0ce467cb385f24d5", null ],
      [ "bAPB2Disable", "structstc__clk__config__t.html#ad6086350ce19a81bb91e9f1b2ddc737c", null ],
      [ "enMCOWaitTime", "structstc__clk__config__t.html#ab03687070edf4156d4e53ac8daaaf727", null ],
      [ "enSCOWaitTime", "structstc__clk__config__t.html#a4078817e61ae2530756d4569e136d248", null ],
      [ "enPLLOWaitTime", "structstc__clk__config__t.html#a6cdf68edd716a3409aca21bea9169a4d", null ],
      [ "u8PllK", "structstc__clk__config__t.html#a0016f45e220be10d1eb50cd455e5f942", null ],
      [ "u8PllM", "structstc__clk__config__t.html#a98926570a852ee00cf8aa065e0360cfd", null ],
      [ "u8PllN", "structstc__clk__config__t.html#a42aaf28f92d43801d7e1d558f00c33c6", null ],
      [ "bPllIrq", "structstc__clk__config__t.html#af5a8f06ea5096ff2a70e86d9707ff628", null ],
      [ "bMcoIrq", "structstc__clk__config__t.html#a8f6575be25548ff0f0851a2331012ec4", null ],
      [ "bScoIrq", "structstc__clk__config__t.html#a1b031920b62dd44cbfa44657959e561f", null ],
      [ "pfnPllStabCb", "structstc__clk__config__t.html#a7b202ad15230c3b705500a0f3370ad1a", null ],
      [ "pfnMcoStabCb", "structstc__clk__config__t.html#a121c6336f96ed0775f75294d8484efd0", null ],
      [ "pfnScoStabCb", "structstc__clk__config__t.html#a22616ce321a423b521984910cd5b7c2f", null ]
    ] ]
];