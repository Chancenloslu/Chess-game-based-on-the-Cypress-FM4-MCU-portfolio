var group___group_l_p_m =
[
    [ "Macros", "group___group_l_p_m___macros.html", null ],
    [ "Functions", "group___group_l_p_m___functions.html", "group___group_l_p_m___functions" ],
    [ "Data Structures", "group___group_l_p_m___data_structures.html", "group___group_l_p_m___data_structures" ],
    [ "Enumerated Types", "group___group_l_p_m___types.html", "group___group_l_p_m___types" ]
];