var group___group_m_f_t___f_r_t___types =
[
    [ "en_frt_instance_index_t", "group___group_m_f_t___f_r_t___types.html#gac654741a29c87c70f16295a00e8785a2", [
      [ "FrtInstanceIndexFrt0", "group___group_m_f_t___f_r_t___types.html#ggac654741a29c87c70f16295a00e8785a2ace588c83fcba6debef1ded55b144002e", null ],
      [ "FrtInstanceIndexFrt1", "group___group_m_f_t___f_r_t___types.html#ggac654741a29c87c70f16295a00e8785a2acb72d4d7ff4d14a6cf6c93e0a4c45a8e", null ],
      [ "FrtInstanceIndexFrt2", "group___group_m_f_t___f_r_t___types.html#ggac654741a29c87c70f16295a00e8785a2a35c714e0b8fbde8124f2c6ef6277a819", null ]
    ] ],
    [ "en_mft_frt_clock_t", "group___group_m_f_t___f_r_t___types.html#gab5e0a66994ec7c47200860aa2f61dc24", [
      [ "FrtPclkDiv1", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24a178b462f7b60b96570035860aa1923ce", null ],
      [ "FrtPclkDiv2", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24a71b0a7d7960ec10f9a76651aaf9f5223", null ],
      [ "FrtPclkDiv4", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24aa55d6904a34f84f4fc5470cbc3cca589", null ],
      [ "FrtPclkDiv8", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24aedc2eac4948c21bd00461efe314e1d5b", null ],
      [ "FrtPclkDiv16", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24ad94da2862d445d9e943d0e3d523d66af", null ],
      [ "FrtPclkDiv32", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24a8c02e6a9786e3966fcb9bed82019c3cc", null ],
      [ "FrtPclkDiv64", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24afcf23952b4e8183ff0a92e65f69fadd5", null ],
      [ "FrtPclkDiv128", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24a11727a8e8ddd0419e5b3115abd0b48a6", null ],
      [ "FrtPclkDiv256", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24a6c992c09a91e5c71d1dbce04a695a6ce", null ],
      [ "FrtPclkDiv512", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24af209b5bd6ea51d17901fb78c4bd4cf3e", null ],
      [ "FrtPclkDiv1024", "group___group_m_f_t___f_r_t___types.html#ggab5e0a66994ec7c47200860aa2f61dc24ad711431c88f2c0d9f42880f1708bf28e", null ]
    ] ],
    [ "en_mft_frt_mode_t", "group___group_m_f_t___f_r_t___types.html#ga4a91c19d850f0249981484225588c88a", [
      [ "FrtUpCount", "group___group_m_f_t___f_r_t___types.html#gga4a91c19d850f0249981484225588c88aa8222bc5f6e9e24fa5dab52ebf1be4196", null ],
      [ "FrtUpDownCount", "group___group_m_f_t___f_r_t___types.html#gga4a91c19d850f0249981484225588c88aa989eb201bb81bef1c3f1cfd095bb5468", null ]
    ] ],
    [ "en_mft_frt_irq_t", "group___group_m_f_t___f_r_t___types.html#gaa4adbe72fa82f0a37f708605080ed892", [
      [ "enFrtZeroMatchIrq", "group___group_m_f_t___f_r_t___types.html#ggaa4adbe72fa82f0a37f708605080ed892a88b86d0bdce593e1909c8db424fdc267", null ],
      [ "enFrtPeakMatchIrq", "group___group_m_f_t___f_r_t___types.html#ggaa4adbe72fa82f0a37f708605080ed892acd95f6c30a99e749b4535fc44b970847", null ]
    ] ],
    [ "en_frt_offset_ch_t", "group___group_m_f_t___f_r_t___types.html#gaec1e13f477a739b1f491e6942a8d8e86", [
      [ "FrtOffsetCh1", "group___group_m_f_t___f_r_t___types.html#ggaec1e13f477a739b1f491e6942a8d8e86a36da09429d4c5c0deec1aa508263d259", null ],
      [ "FrtOffsetCh2", "group___group_m_f_t___f_r_t___types.html#ggaec1e13f477a739b1f491e6942a8d8e86a52eb8041065f33d853f975c11036d5f6", null ]
    ] ]
];