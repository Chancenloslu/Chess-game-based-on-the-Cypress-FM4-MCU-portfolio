var group___group_h_s_s_p_i___functions =
[
    [ "HsSpi_Init", "group___group_h_s_s_p_i___functions.html#ga7581afad372733fb4b809bf82cad43b7", null ],
    [ "HsSpi_DeInit", "group___group_h_s_s_p_i___functions.html#ga2146b960638ccba840f7424684e7070c", null ],
    [ "HsSpi_SetMode", "group___group_h_s_s_p_i___functions.html#gaba1e150431d43f0f7dc27519c0153f1e", null ],
    [ "HsSpi_SetExternalDeviceConfig", "group___group_h_s_s_p_i___functions.html#ga80db62528e962c0444c98a962aad556a", null ],
    [ "HsSpi_DirectModeTransferHalfDuplex", "group___group_h_s_s_p_i___functions.html#ga3c4d4f5d720b75472f88ddf2defe996b", null ],
    [ "HsSpi_DirectModeTransferHalfDuplexList", "group___group_h_s_s_p_i___functions.html#gaabd3e2de597791f8a5ae640088da7df6", null ],
    [ "HsSpi_MultiModeTransfer", "group___group_h_s_s_p_i___functions.html#gaa6ac19b806d33be56ced3f0526fc7e74", null ],
    [ "HsSpi_SetReadCommandSequence", "group___group_h_s_s_p_i___functions.html#gab712aeb658f9f6917d13dd91049f4510", null ],
    [ "HsSpi_SetWriteCommandSequence", "group___group_h_s_s_p_i___functions.html#ga9a629dae254e331170b5605a2992a186", null ]
];