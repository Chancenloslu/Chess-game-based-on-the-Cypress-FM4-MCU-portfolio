var group___group_m_f_t___a_d_c_m_p___data_structures =
[
    [ "stc_mft_adcmp_config_t", "structstc__mft__adcmp__config__t.html", [
      [ "enFrt", "structstc__mft__adcmp__config__t.html#a09cfb9119c826c5bacadbb5155d9fb7c", null ],
      [ "enBuf", "structstc__mft__adcmp__config__t.html#a046c64b8f356c00bf80ff01f9ab6d72e", null ],
      [ "enTrigSel", "structstc__mft__adcmp__config__t.html#af7787e327fc1eb99ce3dc238e36ead95", null ],
      [ "enMode", "structstc__mft__adcmp__config__t.html#a6a3f241810b5870e5832aea10f6e34ba", null ],
      [ "enOccpSel", "structstc__mft__adcmp__config__t.html#a39710e25505732004664c887754e11eb", null ],
      [ "bCompareFrtZeroMaskCntVal", "structstc__mft__adcmp__config__t.html#abce3af5500dd65e7c0340e20ffee9b04", null ],
      [ "bCompareFrtPeakMaskCntVal", "structstc__mft__adcmp__config__t.html#a6885a50a14583a94456b669cf48f9bc4", null ],
      [ "u8CompareVal", "structstc__mft__adcmp__config__t.html#a9294408bc60e26c5c36b55539a6d68b1", null ]
    ] ],
    [ "stc_mft_adcmp_func_t", "structstc__mft__adcmp__func__t.html", [
      [ "bDownEn", "structstc__mft__adcmp__func__t.html#a1833df480cb0600ebc752e0c47df4331", null ],
      [ "bPeakEn", "structstc__mft__adcmp__func__t.html#a1fcadadb23f732b34fdafb18a948d3d5", null ],
      [ "bUpEn", "structstc__mft__adcmp__func__t.html#ae14b5bb98188b5ea3200d804b4ae3665", null ],
      [ "bZeroEn", "structstc__mft__adcmp__func__t.html#aaff93f1f2e8e614d75d8058140af576a", null ]
    ] ],
    [ "stc_mft_adcmp_config_fm3_t", "structstc__mft__adcmp__config__fm3__t.html", [
      [ "enFrt", "structstc__mft__adcmp__config__fm3__t.html#af6cb638e05863a41c7d2f68cc68f55bf", null ],
      [ "enMode", "structstc__mft__adcmp__config__fm3__t.html#afb4b4bf219955e37125152b190fd0b0f", null ],
      [ "enBuf", "structstc__mft__adcmp__config__fm3__t.html#aacee075800e71d3c22eb7e7011893921", null ],
      [ "enTrigSel", "structstc__mft__adcmp__config__fm3__t.html#a7df49598033d0888b8ec7f492b1386b3", null ]
    ] ]
];