var group___group_h_b_i_f =
[
    [ "Functions", "group___group_h_b_i_f___functions.html", "group___group_h_b_i_f___functions" ],
    [ "Data Structures", "group___group_h_b_i_f___data_structures.html", "group___group_h_b_i_f___data_structures" ],
    [ "Enumerated Types", "group___group_h_b_i_f___types.html", "group___group_h_b_i_f___types" ]
];