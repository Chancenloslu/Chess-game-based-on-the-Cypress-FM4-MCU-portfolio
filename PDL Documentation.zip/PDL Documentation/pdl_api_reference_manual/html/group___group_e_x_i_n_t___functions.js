var group___group_e_x_i_n_t___functions =
[
    [ "Exint_IrqHandler", "group___group_e_x_i_n_t___functions.html#ga0bfc2a567e730aec22685fb31c76aa3c", null ],
    [ "Exint_Init", "group___group_e_x_i_n_t___functions.html#ga3a865edeacd83793fdc01c0845e73e88", null ],
    [ "Exint_DeInit", "group___group_e_x_i_n_t___functions.html#ga1e5737d87ba7c1c6667bd9ee8cd5bad6", null ],
    [ "Exint_EnableChannel", "group___group_e_x_i_n_t___functions.html#gaf78a42a1643edb8d1df74d3903e5fc71", null ],
    [ "Exint_DisableChannel", "group___group_e_x_i_n_t___functions.html#ga43328a426765a748f70aadb8981c9050", null ],
    [ "Exint_SetDetectMode", "group___group_e_x_i_n_t___functions.html#ga37be83641c6d46e548912a861643b806", null ],
    [ "Exint_GetDetectMode", "group___group_e_x_i_n_t___functions.html#ga1e3af8445a2ab84a780651fb0de5f549", null ],
    [ "Exint_Nmi_IrqHandler", "group___group_e_x_i_n_t___functions.html#gad098de337a457fcdaffe663d75e33987", null ],
    [ "Exint_Nmi_Init", "group___group_e_x_i_n_t___functions.html#gac59e33d12f8f4297180d1bb2e35112fe", null ],
    [ "Exint_Nmi_DeInit", "group___group_e_x_i_n_t___functions.html#ga7904b5d751feaf05275bb989974720c3", null ]
];