var group___group_l_v_d =
[
    [ "Macros", "group___group_l_v_d___macros.html", null ],
    [ "Functions", "group___group_l_v_d___functions.html", "group___group_l_v_d___functions" ],
    [ "Data Structures", "group___group_l_v_d___data_structures.html", "group___group_l_v_d___data_structures" ],
    [ "Enumerated Types", "group___group_l_v_d___types.html", "group___group_l_v_d___types" ]
];