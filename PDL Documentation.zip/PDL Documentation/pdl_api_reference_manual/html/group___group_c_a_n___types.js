var group___group_c_a_n___types =
[
    [ "en_can_prescaler_t", "group___group_c_a_n___types.html#gafda31a0ae84928d1124cdd7a0c646c92", [
      [ "CanPreDiv11", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92a3321e99a26dbcb042897e9646017259d", null ],
      [ "CanPreDiv12", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92a82f9eac17d64a26fa09aee8c4c166b03", null ],
      [ "CanPreDiv14", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92af011227445d9f02284d6e006c27363f8", null ],
      [ "CanPreDiv18", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92a09a0ec3cce59c81096037d939b72844c", null ],
      [ "CanPreDiv23", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92acc41e27177d12bab38cd179207e08ff4", null ],
      [ "CanPreDiv13", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92ad9dcc978be4af646e5b19e4d46f808b9", null ],
      [ "CanPreDiv16", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92a37bbad3a9cfb4ae7b3104ad17bd3e088", null ],
      [ "CanPreDiv112", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92ab574ce7120f6814d58ea9173b9e6704c", null ],
      [ "CanPreDiv15", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92a1e9afd3b49920d32ebad678b331fe090", null ],
      [ "CanPreDiv110", "group___group_c_a_n___types.html#ggafda31a0ae84928d1124cdd7a0c646c92a1768959e6e39e4afdcd247221e217142", null ]
    ] ],
    [ "en_can_tx_mode_t", "group___group_c_a_n___types.html#ga394463884556f90fa7d01912dbedd57e", [
      [ "CanImmediateTransmit", "group___group_c_a_n___types.html#gga394463884556f90fa7d01912dbedd57ea6939f9db949b14a597f94f9ba8ad79c5", null ],
      [ "CanRemoteTransmit", "group___group_c_a_n___types.html#gga394463884556f90fa7d01912dbedd57eab5102bbf2cff0d7b5638cd990f65c4f4", null ]
    ] ],
    [ "en_can_status_t", "group___group_c_a_n___types.html#ga2103c9cc5ed928277b405e5c79c24707", [
      [ "CanNoError", "group___group_c_a_n___types.html#gga2103c9cc5ed928277b405e5c79c24707ac48cf9e7800cefffbd0da7557e7fb613", null ],
      [ "CanStuffError", "group___group_c_a_n___types.html#gga2103c9cc5ed928277b405e5c79c24707a143e6831b051e8d89bafe498e43f3362", null ],
      [ "CanFormError", "group___group_c_a_n___types.html#gga2103c9cc5ed928277b405e5c79c24707a8b892eda3f36f64b8bae2446b7f2b833", null ],
      [ "CanAckError", "group___group_c_a_n___types.html#gga2103c9cc5ed928277b405e5c79c24707a4a9d289a22ad204722bd2380ba508a53", null ],
      [ "CanBit1Error", "group___group_c_a_n___types.html#gga2103c9cc5ed928277b405e5c79c24707aa03b54cc83dc6fdb7ad045ade4b6b162", null ],
      [ "CanBit0Error", "group___group_c_a_n___types.html#gga2103c9cc5ed928277b405e5c79c24707a95765ec2221bde02b5adb9b25395168d", null ],
      [ "CanCRCError", "group___group_c_a_n___types.html#gga2103c9cc5ed928277b405e5c79c24707abfad4920336f464dfd77ba3a35355591", null ]
    ] ],
    [ "en_can_error_t", "group___group_c_a_n___types.html#ga40e4b655820bd8aa447d5bd49bd6c5f1", [
      [ "CanBusOff", "group___group_c_a_n___types.html#gga40e4b655820bd8aa447d5bd49bd6c5f1a471a992b777d69717f6f65e849c03410", null ],
      [ "CanWarning", "group___group_c_a_n___types.html#gga40e4b655820bd8aa447d5bd49bd6c5f1aa605f9caf7a10d923e8869d45fe4f314", null ]
    ] ],
    [ "en_can_instance_index_t", "group___group_c_a_n___types.html#ga10696a797b794ddb26b93953d0b3fbf5", null ]
];