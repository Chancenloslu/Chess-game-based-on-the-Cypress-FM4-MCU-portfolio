var group___group_r_t_c =
[
    [ "Macros", "group___group_r_t_c___macros.html", "group___group_r_t_c___macros" ],
    [ "Functions", "group___group_r_t_c___functions.html", "group___group_r_t_c___functions" ],
    [ "Global Variables", "group___group_r_t_c___global_variables.html", "group___group_r_t_c___global_variables" ],
    [ "Data Structures", "group___group_r_t_c___data_structures.html", "group___group_r_t_c___data_structures" ],
    [ "Enumerated Types", "group___group_r_t_c___types.html", "group___group_r_t_c___types" ]
];