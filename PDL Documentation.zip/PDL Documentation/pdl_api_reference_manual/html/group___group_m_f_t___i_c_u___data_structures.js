var group___group_m_f_t___i_c_u___data_structures =
[
    [ "stc_mft_icu_intern_data_t", "structstc__mft__icu__intern__data__t.html", [
      [ "pfnIcu0IrqCb", "structstc__mft__icu__intern__data__t.html#ae22467cad00e2b3f0f82a99e543ebaae", null ],
      [ "pfnIcu1IrqCb", "structstc__mft__icu__intern__data__t.html#a7a96ffa1d01b144c5c7cd01ae19332a2", null ],
      [ "pfnIcu2IrqCb", "structstc__mft__icu__intern__data__t.html#a0fb0fac294867f11887f83e590ed758b", null ],
      [ "pfnIcu3IrqCb", "structstc__mft__icu__intern__data__t.html#a762cc85fcd3ac47e9989ece5c4542278", null ]
    ] ],
    [ "stc_mft_icu_instance_data_t", "structstc__mft__icu__instance__data__t.html", [
      [ "pstcInstance", "structstc__mft__icu__instance__data__t.html#a9a7c74a1a1c7ab5d45ff0ac8bc50017a", null ],
      [ "stcInternData", "structstc__mft__icu__instance__data__t.html#ac4d4afb3d92480c6a21c17f79577a90a", null ]
    ] ]
];