#ifndef BLINK_H
#define BLINK_H

/**
 * Periodically switches the RGB LED on and off
 */
int BlinkMain();

void RedLedOn();

void BlueLedOn();

void GreenLedOn();

#endif
