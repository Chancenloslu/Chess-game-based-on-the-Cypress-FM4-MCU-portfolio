var group___group_w_f_l_a_s_h___functions =
[
    [ "WFlash_ChipErase", "group___group_w_f_l_a_s_h___functions.html#ga29f04a445263c151c76cc22101a3a58a", null ],
    [ "WFlash_SectorErase", "group___group_w_f_l_a_s_h___functions.html#ga519e39e4d5b716e40f8219c1f68d3052", null ],
    [ "WFlash_WriteData32Bit", "group___group_w_f_l_a_s_h___functions.html#ga2046151611f6aa3ac99a03b8f3070e87", null ],
    [ "WFlash_WriteData16Bit", "group___group_w_f_l_a_s_h___functions.html#ga3f28410cea2ac128e2646b92a423c045", null ]
];