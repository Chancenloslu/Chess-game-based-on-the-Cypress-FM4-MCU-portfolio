var group___group_g_p_i_o =
[
    [ "Fast General-purpose I/O ports (FGPIO)", "group___group_f_g_p_i_o.html", "group___group_f_g_p_i_o" ],
    [ "Macros", "group___group_g_p_i_o___macros.html", null ],
    [ "Data Structures", "group___group_g_p_i_o___data_structures.html", "group___group_g_p_i_o___data_structures" ]
];