var group___group_b_t___types =
[
    [ "en_bt_instance_index_t", "group___group_b_t___types.html#ga6192bd8b03b61cf2d763c7572555e8af", [
      [ "BtInstanceIndexBt0", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa98b4144d289e877399549f278de667b4", null ],
      [ "BtInstanceIndexBt1", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa73de8698474ccdc502bb9cf91e0a88ac", null ],
      [ "BtInstanceIndexBt2", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa4440b319ee6e7b3e17bcb99653e9e770", null ],
      [ "BtInstanceIndexBt3", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa0d6dd9ab990cef9e3d093c15445e54a4", null ],
      [ "BtInstanceIndexBt4", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afae25e2fd52f2fcddbe1ba2200b09922f7", null ],
      [ "BtInstanceIndexBt5", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa4d02971293d4b715dc483d5841d876b3", null ],
      [ "BtInstanceIndexBt6", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa534148b79e3768d2a47cf8afff35cd9c", null ],
      [ "BtInstanceIndexBt7", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa6bf6040af2938ebffac7c08c7ec86ece", null ],
      [ "BtInstanceIndexBt8", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afaee7ec30e105ea22c9f02f49bb6c630f8", null ],
      [ "BtInstanceIndexBt9", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afab39b94836886aed3f1b38aadf750001b", null ],
      [ "BtInstanceIndexBt10", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa885f7048c7c9934ce65e378a93648d05", null ],
      [ "BtInstanceIndexBt11", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa142d39df8defd24ca4d7a407a69a7f71", null ],
      [ "BtInstanceIndexBt12", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa0712632f69e45c2fe8be47936645dca5", null ],
      [ "BtInstanceIndexBt13", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afaf00a3384b4bedcea34b41e8b732e7f7d", null ],
      [ "BtInstanceIndexBt14", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa67381ec9eb3a6d86e5520bb54b1693be", null ],
      [ "BtInstanceIndexBt15", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa69111664b76da7bec26d3dce789b1971", null ],
      [ "BtInstanceIndexMax", "group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afa64ace7a0c33bad87963e6c7b221595e2", null ]
    ] ],
    [ "en_bt_io_mode_t", "group___group_b_t___types.html#ga6178d5d6bb9f9f89dab4ce001d069a1b", [
      [ "BtIoMode0", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1ba66515c70811cb4ce5fb4cbb2519cb8d4", null ],
      [ "BtIoMode1", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1ba497a778eb52513b2b44585a46b42bf85", null ],
      [ "BtIoMode2", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1ba350de64ff720286d0321ae74089ff082", null ],
      [ "BtIoMode3", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1baafc1a43a5e6e3defe40a0cdea13795d6", null ],
      [ "BtIoMode4", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1ba77dd12c3167df379f54fa95facaf3da2", null ],
      [ "BtIoMode5", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1ba112e03a9089b0f164b920ec7278bd3c9", null ],
      [ "BtIoMode6", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1bab2b9fdf3dc15c7e0df2729b774261dfb", null ],
      [ "BtIoMode7", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1ba1670ff42643e0a73b69e9d5363d69a3e", null ],
      [ "BtIoMode8", "group___group_b_t___types.html#gga6178d5d6bb9f9f89dab4ce001d069a1ba8cd24fea2c1c2b48b61765ae5419aef8", null ]
    ] ],
    [ "en_bt_timer_mode_t", "group___group_b_t___types.html#gacce761abafb039994bb1ec6795fae1d9", [
      [ "BtResetMode", "group___group_b_t___types.html#ggacce761abafb039994bb1ec6795fae1d9aeb5164872b16ae8ec1fb91b83e59a4d8", null ],
      [ "BtPwmMode", "group___group_b_t___types.html#ggacce761abafb039994bb1ec6795fae1d9ad494aeb2169cec8428e13aa42f0972ca", null ],
      [ "BtPpgMode", "group___group_b_t___types.html#ggacce761abafb039994bb1ec6795fae1d9af43b81d5b91837538bf9180653dc3404", null ],
      [ "BtRtMode", "group___group_b_t___types.html#ggacce761abafb039994bb1ec6795fae1d9ab5fbb1469eb67e7590aad0056651d82f", null ],
      [ "BtPwcMode", "group___group_b_t___types.html#ggacce761abafb039994bb1ec6795fae1d9ab3b8b1bed6599259e149e5731d17307f", null ]
    ] ],
    [ "en_pwm_clock_pres_t", "group___group_b_t___types.html#ga3d12e767f8410082afef4d7e031e4eb8", [
      [ "PwmPresNone", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8aca311ff54a16015f4916063876ac5f2c", null ],
      [ "PwmPres1Div4", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8a9ccfc2ac2bf4f1fda8ecc8ae63d6cf97", null ],
      [ "PwmPres1Div16", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8a3d4c93fc3234e7d8db47fc3a9bfcf7df", null ],
      [ "PwmPres1Div128", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8a70f8726b6fc15862945a087399fb30b1", null ],
      [ "PwmPres1Div256", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8ab6591a7bb151596a66e738e4fe904e83", null ],
      [ "PwmPres1ExtClkRising", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8a1c63f4e0b9ccb6ec5ef27458b5ba9b8d", null ],
      [ "PwmPres1ExtClkFalling", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8a872f5e5f021c5d87ef54ebe2dea066f3", null ],
      [ "PwmPres1ExtClkBoth", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8af69ed7caf7c8b2a2eee470178e3cf923", null ],
      [ "PwmPres1Div512", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8a050d388ab4c062b06f713a110b7394e3", null ],
      [ "PwmPres1Div1024", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8abad76b6184e58d60b702e7337c44a56d", null ],
      [ "PwmPres1Div2048", "group___group_b_t___types.html#gga3d12e767f8410082afef4d7e031e4eb8a6be3250e494f3ffeabac48647b3d8299", null ]
    ] ],
    [ "en_pwm_restart_enable_t", "group___group_b_t___types.html#gad50ce075167cc78bda808bef8f467b93", [
      [ "PwmRestartDisable", "group___group_b_t___types.html#ggad50ce075167cc78bda808bef8f467b93ac7b6a5208b0bc94c14c11523d467d53e", null ],
      [ "PwmRestartEnable", "group___group_b_t___types.html#ggad50ce075167cc78bda808bef8f467b93af032de9d3cc232db3686f1538ca88517", null ]
    ] ],
    [ "en_pwm_output_mask_t", "group___group_b_t___types.html#ga7f054262ef905c7b2f02d77165e28165", [
      [ "PwmOutputNormal", "group___group_b_t___types.html#gga7f054262ef905c7b2f02d77165e28165ab889af5da404a0c3512cb015f8097549", null ],
      [ "PwmOutputMask", "group___group_b_t___types.html#gga7f054262ef905c7b2f02d77165e28165a420233e4fe7e98027df6927fb326d152", null ]
    ] ],
    [ "en_pwm_ext_trig_t", "group___group_b_t___types.html#ga419d91d7c403ab6eef77f024eb93e1a9", [
      [ "PwmExtTrigDisable", "group___group_b_t___types.html#gga419d91d7c403ab6eef77f024eb93e1a9abfe0b986d6f0df3276d05bb2ec2eda10", null ],
      [ "PwmExtTrigRising", "group___group_b_t___types.html#gga419d91d7c403ab6eef77f024eb93e1a9a3c7dae73348a7606c6b31e9f9dfc7253", null ],
      [ "PwmExtTrigFalling", "group___group_b_t___types.html#gga419d91d7c403ab6eef77f024eb93e1a9a5c83a7996f5016b8432e38cefebe63ff", null ],
      [ "PwmExtTrigBoth", "group___group_b_t___types.html#gga419d91d7c403ab6eef77f024eb93e1a9a6c2c3960fa8b36e4dd27c576366b655d", null ]
    ] ],
    [ "en_pwm_output_polarity_t", "group___group_b_t___types.html#ga8edf9d0cebe4d554976ab9feb5789a7c", [
      [ "PwmPolarityLow", "group___group_b_t___types.html#gga8edf9d0cebe4d554976ab9feb5789a7ca7b54c8357de68543cda0d770cb38b7ca", null ],
      [ "PwmPolarityHigh", "group___group_b_t___types.html#gga8edf9d0cebe4d554976ab9feb5789a7ca4c6909912bc563c37fe066745da40f53", null ]
    ] ],
    [ "en_pwm_mode_t", "group___group_b_t___types.html#ga4d6edaa99d901accc43b1d51c7b8ec47", [
      [ "PwmContinuous", "group___group_b_t___types.html#gga4d6edaa99d901accc43b1d51c7b8ec47afcb36165931c4218c78ca7c476cc162e", null ],
      [ "PwmOneshot", "group___group_b_t___types.html#gga4d6edaa99d901accc43b1d51c7b8ec47a0312b1269a375bffa226f3bad4f8cfd0", null ]
    ] ],
    [ "en_pwm_irq_sel_t", "group___group_b_t___types.html#gad7db12349c3bfc9da8f016c562db2cec", [
      [ "PwmTrigIrq", "group___group_b_t___types.html#ggad7db12349c3bfc9da8f016c562db2cecaaa24c096d4b7c10b9790844659ca309f", null ],
      [ "PwmDutyMatchIrq", "group___group_b_t___types.html#ggad7db12349c3bfc9da8f016c562db2ceca5bfa4b6b780042e702f1c92ee0fcfb94", null ],
      [ "PwmUnderflowIrq", "group___group_b_t___types.html#ggad7db12349c3bfc9da8f016c562db2cecae040cbf0be78f81f9cb2b914e641d597", null ]
    ] ],
    [ "en_ppg_clock_pres_t", "group___group_b_t___types.html#ga2f40e4a885367c4611c7000560eb9438", [
      [ "PpgPresNone", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a5a8bb0fa69dec29c0eafe486d32f57fc", null ],
      [ "PpgPres1Div4", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a261d85e1f9808004aa19d103b295f791", null ],
      [ "PpgPres1Div16", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438ab4bdfa4d62ab30e567361f2b600ec87a", null ],
      [ "PpgPres1Div128", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a2300c8fece6b92bd3b2ce5f69f7c468b", null ],
      [ "PpgPres1Div256", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a7df3f3112b63060bf6ab775b2e3c587a", null ],
      [ "PpgPres1ExtClkRising", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438af6660ea310ad9036c8171c3ee3209b2c", null ],
      [ "PpgPres1ExtClkFalling", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438aafc43f496cfa3850e90f84e05e77f508", null ],
      [ "PpgPres1ExtClkBoth", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a848d61a7314ff03b97943b2ca94728e3", null ],
      [ "PpgPres1Div512", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a14e1de0e185d13b42283a1dea5c249ef", null ],
      [ "PpgPres1Div1024", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a1b6d721f42553f4a45f9bcccb7ed75fe", null ],
      [ "PpgPres1Div2048", "group___group_b_t___types.html#gga2f40e4a885367c4611c7000560eb9438a24b7565b1f23891efdf422df42aa3598", null ]
    ] ],
    [ "en_ppg_restart_enable_t", "group___group_b_t___types.html#ga4c2fb4b9cc74374fec340ecded80dad6", [
      [ "PpgRestartDisable", "group___group_b_t___types.html#gga4c2fb4b9cc74374fec340ecded80dad6a18fe80ba11717b8fffa1be0b55d13732", null ],
      [ "PpgRestartEnable", "group___group_b_t___types.html#gga4c2fb4b9cc74374fec340ecded80dad6a3aced2c7a2bb63cbea90bf9853d8729a", null ]
    ] ],
    [ "en_ppg_output_mask_t", "group___group_b_t___types.html#ga2e658a12d6c4b5c2c6aa341c565f5710", [
      [ "PpgOutputNormal", "group___group_b_t___types.html#gga2e658a12d6c4b5c2c6aa341c565f5710acd35dedf5c271f5794cb4b342e9e627e", null ],
      [ "PpgOutputMask", "group___group_b_t___types.html#gga2e658a12d6c4b5c2c6aa341c565f5710a753990846716af74859c65a312a24646", null ]
    ] ],
    [ "en_ppg_ext_trig_t", "group___group_b_t___types.html#ga0e7e27e1fbb372b770522a67d6280db0", [
      [ "PpgExtTrigDisable", "group___group_b_t___types.html#gga0e7e27e1fbb372b770522a67d6280db0a95e87e6b44a946834196de7544c12e79", null ],
      [ "PpgExtTrigRising", "group___group_b_t___types.html#gga0e7e27e1fbb372b770522a67d6280db0acb03792fac2b4d03561f77b3a5ba3f8a", null ],
      [ "PpgExtTrigFalling", "group___group_b_t___types.html#gga0e7e27e1fbb372b770522a67d6280db0a0765d2eddc6239a57e41c94c8e54e362", null ],
      [ "PpgExtTrigBoth", "group___group_b_t___types.html#gga0e7e27e1fbb372b770522a67d6280db0a42c8d8292a58edd5c0411df2d4434b24", null ]
    ] ],
    [ "en_ppg_output_polarity_t", "group___group_b_t___types.html#ga6a61633debe2d27065da94b9e2918683", [
      [ "PpgPolarityLow", "group___group_b_t___types.html#gga6a61633debe2d27065da94b9e2918683aa102c56b9c1bd3954c31043b91fad9c2", null ],
      [ "PpgPolarityHigh", "group___group_b_t___types.html#gga6a61633debe2d27065da94b9e2918683a4a023fa169b82e0aa96966874a5f79ab", null ]
    ] ],
    [ "en_ppg_mode_t", "group___group_b_t___types.html#gab07786444910f6716709429b0bff368e", [
      [ "PpgContinuous", "group___group_b_t___types.html#ggab07786444910f6716709429b0bff368eaa75622a9a61b1c14a986676d21a4ead7", null ],
      [ "PpgOneshot", "group___group_b_t___types.html#ggab07786444910f6716709429b0bff368ea7ee781ceee929247c7cbc196acd47c43", null ]
    ] ],
    [ "en_ppg_irq_sel_t", "group___group_b_t___types.html#ga47bf4f78d2b7a54ed86bc1a7f45a1ec3", [
      [ "PpgTrigIrq", "group___group_b_t___types.html#gga47bf4f78d2b7a54ed86bc1a7f45a1ec3a694d26917fd481efdb9f8c9285e75fdf", null ],
      [ "PpgUnderflowIrq", "group___group_b_t___types.html#gga47bf4f78d2b7a54ed86bc1a7f45a1ec3a5ac05c92cadab279095ab3254efdf35a", null ]
    ] ],
    [ "en_rt_clock_pres_t", "group___group_b_t___types.html#ga283fa321f7791d952e19bf3b0de58827", [
      [ "RtPresNone", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827ae44ca0a79cdeb51fbf5264db65a43f0d", null ],
      [ "RtPres1Div4", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827a1e2637a6352870879ccca186a97d074c", null ],
      [ "RtPres1Div16", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827a6aff234164e653b2d5a9e0ec725e226e", null ],
      [ "RtPres1Div128", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827a42f5fd574bdbe28d26eea0f7964b2f42", null ],
      [ "RtPres1Div256", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827ae1130176e87eb1bc69cc0406e2210dbc", null ],
      [ "RtPres1ExtClkRising", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827a55be746aafb5dc6d92aa908b9613500d", null ],
      [ "RtPres1ExtClkFalling", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827a44fb3174c08ae78b41ab4dd2374d8be0", null ],
      [ "RtPres1ExtClkBoth", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827adc1d9d4b77de45f3eb765611680e0a8d", null ],
      [ "RtPres1Div512", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827abed7c6f278ce4b0aef2191fc28e4c392", null ],
      [ "RtPres1Div1024", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827a8b89fc911c1c6a4f00d2cf954ddd96c7", null ],
      [ "RtPres1Div2048", "group___group_b_t___types.html#gga283fa321f7791d952e19bf3b0de58827a8cc0d671282911de683fdcda2b0897cc", null ]
    ] ],
    [ "en_rt_ext_trigger_t", "group___group_b_t___types.html#ga11d63e503af65b4b80d23ab0e0c728fc", [
      [ "RtExtTiggerDisable", "group___group_b_t___types.html#gga11d63e503af65b4b80d23ab0e0c728fca2b9fbac9e44368a596a400ab06d31e9c", null ],
      [ "RtExtTiggerRisingEdge", "group___group_b_t___types.html#gga11d63e503af65b4b80d23ab0e0c728fca4a6629240eeef0f5bc81b0057522c01c", null ],
      [ "RtExtTiggerFallingEdge", "group___group_b_t___types.html#gga11d63e503af65b4b80d23ab0e0c728fca24d0d38b663ffb1748b42e44100e9789", null ],
      [ "RtExtTiggerBothEdge", "group___group_b_t___types.html#gga11d63e503af65b4b80d23ab0e0c728fca7a508edda00051ea3ce22d081e03235b", null ],
      [ "RtExtTiggerLowLevel", "group___group_b_t___types.html#gga11d63e503af65b4b80d23ab0e0c728fcaf091dbfd181519530dd9d543c75c5e2b", null ],
      [ "RtExtTiggerHighLevel", "group___group_b_t___types.html#gga11d63e503af65b4b80d23ab0e0c728fcacc71059cd9919dd255ed3b907fa51724", null ]
    ] ],
    [ "en_rt_output_polarity_t", "group___group_b_t___types.html#ga6cdd84280de56317394500a724fda564", [
      [ "RtPolarityLow", "group___group_b_t___types.html#gga6cdd84280de56317394500a724fda564a4ce24d1b949a94ea4c9db315972aec5a", null ],
      [ "RtPolarityHigh", "group___group_b_t___types.html#gga6cdd84280de56317394500a724fda564a064865c57e31976be50955ca8f44d2b7", null ]
    ] ],
    [ "en_rt_mode_t", "group___group_b_t___types.html#ga850f31d9b22da6b365bfcfd5079e0450", [
      [ "RtReload", "group___group_b_t___types.html#gga850f31d9b22da6b365bfcfd5079e0450a4d3aaccf0478aa3999d0453d6a079da1", null ],
      [ "RtOneshot", "group___group_b_t___types.html#gga850f31d9b22da6b365bfcfd5079e0450a50d9ddf9bfb8ee6219352a99f2331cd1", null ]
    ] ],
    [ "en_rt_timer_size_t", "group___group_b_t___types.html#ga998897de20c8fa7d001e1e9046499eb0", [
      [ "RtSize16Bit", "group___group_b_t___types.html#gga998897de20c8fa7d001e1e9046499eb0ae936c134d781c9d709adc7ec4a70cfc6", null ],
      [ "RtSize32Bit", "group___group_b_t___types.html#gga998897de20c8fa7d001e1e9046499eb0a23035774c353e555f575064639096083", null ]
    ] ],
    [ "en_rt_irq_sel_t", "group___group_b_t___types.html#ga3a37a4b82803eba2840e099aa6d16328", [
      [ "RtTrigIrq", "group___group_b_t___types.html#gga3a37a4b82803eba2840e099aa6d16328a73bed9854d9b9470daad9af7bfd20c9f", null ],
      [ "RtUnderflowIrq", "group___group_b_t___types.html#gga3a37a4b82803eba2840e099aa6d16328adc7348a956ae33665cac142da7661c39", null ]
    ] ],
    [ "en_pwc_clock_pres_t", "group___group_b_t___types.html#gabc6c836679fd4ae4800c6252a4091d6c", [
      [ "PwcPresNone", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6cae8ede76962cc1a2e3a2841baf710873d", null ],
      [ "PwcPres1Div4", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6caf06e988e25367f6e1cafca36e8e50a69", null ],
      [ "PwcPres1Div16", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6ca032fbdb30277c3246981f35ec508c12e", null ],
      [ "PwcPres1Div128", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6ca91438809349e4f7d0731d9c0a24c744e", null ],
      [ "PwcPres1Div256", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6ca908fd0dedfa334c813011379d1d67412", null ],
      [ "PwcPres1Div512", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6caeb8f6eb6086671fe34b27c38deb860eb", null ],
      [ "PwcPres1Div1024", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6cac7c462824c6f4c81f1486e57dfff8537", null ],
      [ "PwcPres1Div2048", "group___group_b_t___types.html#ggabc6c836679fd4ae4800c6252a4091d6ca1c7d5bb2d020a4f162b79b6335dcdf76", null ]
    ] ],
    [ "en_pwc_measure_edge_t", "group___group_b_t___types.html#gab25a9dfca40c91f1a25fd6a9cea1cbd0", [
      [ "PwcMeasureRisingToFalling", "group___group_b_t___types.html#ggab25a9dfca40c91f1a25fd6a9cea1cbd0a3e81025710cbd3c04da8374afadb9dfd", null ],
      [ "PwcMeasureRisingToRising", "group___group_b_t___types.html#ggab25a9dfca40c91f1a25fd6a9cea1cbd0a8a23799516b1a39fbf66890f57388149", null ],
      [ "PwcMeasureFallingToFalling", "group___group_b_t___types.html#ggab25a9dfca40c91f1a25fd6a9cea1cbd0ab4eb3d5c518f10e287452cc80abf064b", null ],
      [ "PwcMeasureEitherToEither", "group___group_b_t___types.html#ggab25a9dfca40c91f1a25fd6a9cea1cbd0a8e50f907f0ca0e73e70e1277ae790c4b", null ],
      [ "PwcMeasureFallingToRising", "group___group_b_t___types.html#ggab25a9dfca40c91f1a25fd6a9cea1cbd0adcd18dc20ef51861f06d07c7179e543c", null ]
    ] ],
    [ "en_pwc_mode_t", "group___group_b_t___types.html#ga650ba841ee8b779bd9b395c0168e8c02", [
      [ "PwcContinuous", "group___group_b_t___types.html#gga650ba841ee8b779bd9b395c0168e8c02a3bc547f499f704d30c2fa7aad6f8927f", null ],
      [ "PwcOneshot", "group___group_b_t___types.html#gga650ba841ee8b779bd9b395c0168e8c02ad16dd53cfa4823249ab900826b0c83eb", null ]
    ] ],
    [ "en_pwc_timer_size_t", "group___group_b_t___types.html#gadce2fb418891b8563d68a5a9782cd11e", [
      [ "PwcSize16Bit", "group___group_b_t___types.html#ggadce2fb418891b8563d68a5a9782cd11ea9684c0dcc522907a7857f68f092359cb", null ],
      [ "PwcSize32Bit", "group___group_b_t___types.html#ggadce2fb418891b8563d68a5a9782cd11eacf89bce54321e03ea5b4717c9f6832c9", null ]
    ] ],
    [ "en_pwc_irq_sel_t", "group___group_b_t___types.html#gaa690e22b23beaaefd6190f8c64b35120", [
      [ "PwcMeasureCompleteIrq", "group___group_b_t___types.html#ggaa690e22b23beaaefd6190f8c64b35120ad5491bc2bc922895ea00ed381dc0ed56", null ],
      [ "PwcMeasureOverflowIrq", "group___group_b_t___types.html#ggaa690e22b23beaaefd6190f8c64b35120a12298bd93f3b3e75f5b690ba00aa463f", null ]
    ] ]
];