var group___group_w_c___types =
[
    [ "en_input_clk_t", "group___group_w_c___types.html#ga254d84dfc14f6cc285f7cb6b5a72cede", [
      [ "WcPresInClkSubOsc", "group___group_w_c___types.html#gga254d84dfc14f6cc285f7cb6b5a72cedea911de71ebe4271f329acca905e81e7ab", null ],
      [ "WcPresInClkMainOsc", "group___group_w_c___types.html#gga254d84dfc14f6cc285f7cb6b5a72cedea10da5a2ebb48c79cca1215249c99ee47", null ],
      [ "WcPresInClkHighCr", "group___group_w_c___types.html#gga254d84dfc14f6cc285f7cb6b5a72cedeac60a620c144dc4dd38a79c5c230d4cfc", null ],
      [ "WcPresInClkLowCr", "group___group_w_c___types.html#gga254d84dfc14f6cc285f7cb6b5a72cedeada21dd17dc0bdfd0cc0ec109070a4373", null ]
    ] ],
    [ "en_output_clk_t", "group___group_w_c___types.html#ga24a69f57a98ce45cdd2b3a1406e69aa6", [
      [ "WcPresOutClkArray0", "group___group_w_c___types.html#gga24a69f57a98ce45cdd2b3a1406e69aa6a549a0590d40a30c7ebbf38e80b5113d6", null ],
      [ "WcPresOutClkArray1", "group___group_w_c___types.html#gga24a69f57a98ce45cdd2b3a1406e69aa6a88f8570dce6620588e893ef940b2a4cc", null ],
      [ "WcPresOutClkArray2", "group___group_w_c___types.html#gga24a69f57a98ce45cdd2b3a1406e69aa6a96bf0c060da1e10dffbc7c24e15ac209", null ],
      [ "WcPresOutClkArray3", "group___group_w_c___types.html#gga24a69f57a98ce45cdd2b3a1406e69aa6a0706c7012b94c1441894b99f99dbbc95", null ],
      [ "WcPresOutClkArray4", "group___group_w_c___types.html#gga24a69f57a98ce45cdd2b3a1406e69aa6a70116222295867045b626fdff424ef6a", null ],
      [ "WcPresOutClkArray5", "group___group_w_c___types.html#gga24a69f57a98ce45cdd2b3a1406e69aa6a5f876c4e589b437e56c77d028424c14d", null ],
      [ "WcPresOutClkArray6", "group___group_w_c___types.html#gga24a69f57a98ce45cdd2b3a1406e69aa6ad0e6c95839bd090019035788881bee90", null ]
    ] ],
    [ "en_wc_cnt_clk_t", "group___group_w_c___types.html#ga194a6b16d9f4821411bcd3fb5435f249", [
      [ "WcCntClkWcck0", "group___group_w_c___types.html#gga194a6b16d9f4821411bcd3fb5435f249ae337fc3dc9460719837d4abdd0250d9c", null ],
      [ "WcCntClkWcck1", "group___group_w_c___types.html#gga194a6b16d9f4821411bcd3fb5435f249af141882cb9cad1ae65923037c64be706", null ],
      [ "WcCntClkWcck2", "group___group_w_c___types.html#gga194a6b16d9f4821411bcd3fb5435f249aea998abfc0a617743e1b4e78ed1f4445", null ],
      [ "WcCntClkWcck3", "group___group_w_c___types.html#gga194a6b16d9f4821411bcd3fb5435f249a7b948073ca89ae70d60d9cc48092f90b", null ]
    ] ]
];