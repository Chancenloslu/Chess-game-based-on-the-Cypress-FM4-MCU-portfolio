#ifndef ACCELERATION_H
#define ACCELERATION_H

#define CPPP_ACCELERATION_X_MIN (x_out <= 0)

void cppp_rgbLEDAcceleration();
void cppp_rgbLEDAcceleration_s();

#endif
