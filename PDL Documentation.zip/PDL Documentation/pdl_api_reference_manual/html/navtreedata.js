var NAVTREE =
[
  [ "Cypress Peripheral Driver Library", "index.html", [
    [ "Drivers", "modules.html", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"group___group_a_d_c.html",
"group___group_b_t___types.html#gga6192bd8b03b61cf2d763c7572555e8afaf00a3384b4bedcea34b41e8b732e7f7d",
"group___group_c_l_k___types.html#gga5d24cca2e7a1ce8a56d0f1fd581adc1caaf6aaa4530715ba38cf1003e34d7db87",
"group___group_d_m_a___types.html#gga9cfd3cddaf334ecb789004aa3dd6867da266d5aa2241b67eb8a9d2db55f737e63",
"group___group_f_g_p_i_o___data_structures.html",
"group___group_h_s_s_p_i___types.html#ggafea6a3bb6154c29b57d41b29dfb11613a31090e6c9be941d9a894337530a81c85",
"group___group_i2_c_s___types.html#ga4b76ea3f9e74f9a1994ac992bf68c664",
"group___group_l_c_d___types.html#ggae318c0debbe8caae0a608b71d3862d99ab985c6b31f6bc5ab4ef0973153872499",
"group___group_m_f_s___functions.html#ga177e27061c085578fad8b71defb331fa",
"group___group_m_f_s___types.html#ggadd27328ea9f1f172a4a2bcd605162aefafab4bf8f85deaec040aebe8d6ed9bfc1",
"group___group_m_f_t___w_f_g___types.html#ga805910cd27ef98d3f1520e7cdcac639e",
"group___group_r_c___functions.html#ga35ae53beb8565124264aa8462d3a5975",
"group___group_s_d_i_f___types.html#ggacd67b2e91bb3c7fb27757daef89985f0a55cdc8c5b61a21ec1ccd8d623e5f7177",
"structstc__backupreg__t.html#a3cda8c2aa40c414c3e031de4a27b9403",
"structstc__dstc__config__t.html#a07219a0b1ea15985dd954e3c72b6cf9e",
"structstc__dstc__des01234__t.html#a3330c470a7d994c6196310fff93638bf",
"structstc__dstc__intern__data__t.html#aa2580cd29c080fbcf12413c73ab38861",
"structstc__i2c__irq__en__t.html#a223437fa9e82d856ab0d1199fb7dc610",
"structstc__lin__irq__cb__t.html#a536f407e43d0a47ff46eedcfdd91ef58",
"structstc__pwc__irq__cb__t.html",
"structstc__sdif__data__config__t.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';