var group___group_l_v_d___data_structures =
[
    [ "stc_lvd_intern_data_t", "structstc__lvd__intern__data__t.html", [
      [ "pfnIrqCallback", "structstc__lvd__intern__data__t.html#a314a7f34098705f4df5b73ba69f9ca05", null ]
    ] ],
    [ "stc_lvd_config_t", "structstc__lvd__config__t.html", [
      [ "enLvd0IrqDetectVoltage", "structstc__lvd__config__t.html#a132a33f748683d40510933095e6ad3c6", null ],
      [ "enLvd0IrqReleaseVoltage", "structstc__lvd__config__t.html#a36b6ed61c9f5737d1e5cf33ba676d707", null ],
      [ "bLvd0ReleaseVoltageEnable", "structstc__lvd__config__t.html#ae2ee605dc3a4594b6fed7acea3bdbf1c", null ],
      [ "enLvdResetVoltage", "structstc__lvd__config__t.html#a34460ee105c99f40a7433e477ca53f36", null ],
      [ "enLvd1IrqDetectVoltage", "structstc__lvd__config__t.html#adb7dd5ee247ddfac9393963fb54cd868", null ],
      [ "enLvd1IrqReleaseVoltage", "structstc__lvd__config__t.html#af53cf4ac2ea09059d3de7db74a1a04e4", null ],
      [ "bLvd1ReleaseVoltageEnable", "structstc__lvd__config__t.html#a0e8824656f5d666d1823d5141285ad9c", null ],
      [ "pfnIrqCallback", "structstc__lvd__config__t.html#af479f3ff9bbb0ec14a1988c57709525c", null ]
    ] ]
];