var group___group_q_p_r_c___types =
[
    [ "en_qprc_instance_index_t", "group___group_q_p_r_c___types.html#gab8e094cadb24d352795e1ee0468576d5", [
      [ "QprcInstanceIndexQprc0", "group___group_q_p_r_c___types.html#ggab8e094cadb24d352795e1ee0468576d5ad01f3dfe35d3c1c3d83300e17872a65d", null ],
      [ "QprcInstanceIndexQprc1", "group___group_q_p_r_c___types.html#ggab8e094cadb24d352795e1ee0468576d5aacc4a872c7a8c5f9957054a0e6b8f5cf", null ],
      [ "QprcInstanceIndexQprc2", "group___group_q_p_r_c___types.html#ggab8e094cadb24d352795e1ee0468576d5ae4da9c168dc2bebaf0cda623c307f848", null ],
      [ "QprcInstanceIndexQprc3", "group___group_q_p_r_c___types.html#ggab8e094cadb24d352795e1ee0468576d5aa3ec4b11b7d90d16bf6c7bfd17a93988", null ]
    ] ],
    [ "en_qprc_pcmode_t", "group___group_q_p_r_c___types.html#gae9df99375da081b9c67047ba8692ebd0", [
      [ "QprcPcMode0", "group___group_q_p_r_c___types.html#ggae9df99375da081b9c67047ba8692ebd0a8aff53560a3f57a3e2f4862e9b3f81a9", null ],
      [ "QprcPcMode1", "group___group_q_p_r_c___types.html#ggae9df99375da081b9c67047ba8692ebd0a3af9dd7ae4162db86afb9000e64cb50d", null ],
      [ "QprcPcMode2", "group___group_q_p_r_c___types.html#ggae9df99375da081b9c67047ba8692ebd0ad1d72fb3c474bb11412ddfe6f6762c53", null ],
      [ "QprcPcMode3", "group___group_q_p_r_c___types.html#ggae9df99375da081b9c67047ba8692ebd0a17b73933742b0f578dcc11bfdc96dda2", null ]
    ] ],
    [ "en_qprc_rcmode_t", "group___group_q_p_r_c___types.html#ga629e0f254312b5587bca61a22340ae7e", [
      [ "QprcRcMode0", "group___group_q_p_r_c___types.html#gga629e0f254312b5587bca61a22340ae7eae99b79eec42b9666b38ea29075ca53ad", null ],
      [ "QprcRcMode1", "group___group_q_p_r_c___types.html#gga629e0f254312b5587bca61a22340ae7ea302961475a4a2a0b9c4ecf50107bd685", null ],
      [ "QprcRcMode2", "group___group_q_p_r_c___types.html#gga629e0f254312b5587bca61a22340ae7ea45b5eeed30b551d3bf609c4062a3009a", null ],
      [ "QprcRcMode3", "group___group_q_p_r_c___types.html#gga629e0f254312b5587bca61a22340ae7eae35c87ea92cb8ea08a341b8f02620049", null ]
    ] ],
    [ "en_qprc_zinedge_t", "group___group_q_p_r_c___types.html#ga095b9f6b6fc0fd2b7c2bacdb765fcc25", [
      [ "QprcZinDisable", "group___group_q_p_r_c___types.html#gga095b9f6b6fc0fd2b7c2bacdb765fcc25a3437073151525aed0de29fed11eb5ef1", null ],
      [ "QprcZinFallingEdge", "group___group_q_p_r_c___types.html#gga095b9f6b6fc0fd2b7c2bacdb765fcc25ae935d2127f4fd41f96631e1641cf4f69", null ],
      [ "QprcZinRisingEdge", "group___group_q_p_r_c___types.html#gga095b9f6b6fc0fd2b7c2bacdb765fcc25a5c80017e59a5927a11061fec45cad4b9", null ],
      [ "QprcZinBothEdges", "group___group_q_p_r_c___types.html#gga095b9f6b6fc0fd2b7c2bacdb765fcc25a9c454755f147902a2317e2353dc9fd8e", null ],
      [ "QprcZinLowLevel", "group___group_q_p_r_c___types.html#gga095b9f6b6fc0fd2b7c2bacdb765fcc25a55f791ca3237c2da912f871d1862e550", null ],
      [ "QprcZinHighLevel", "group___group_q_p_r_c___types.html#gga095b9f6b6fc0fd2b7c2bacdb765fcc25a1b5ff61d1cc23d7ebed2ef3b61c9e973", null ]
    ] ],
    [ "en_qprc_binedge_t", "group___group_q_p_r_c___types.html#ga4b010f50a4b4f088a5470034320cc07b", [
      [ "QprcBinDisable", "group___group_q_p_r_c___types.html#gga4b010f50a4b4f088a5470034320cc07baefee0f785b421ec69c4d0599f495cd43", null ],
      [ "QprcBinFallingEdge", "group___group_q_p_r_c___types.html#gga4b010f50a4b4f088a5470034320cc07ba2efbd616d7a0e4a403838e37dc3dbdc5", null ],
      [ "QprcBinRisingEdge", "group___group_q_p_r_c___types.html#gga4b010f50a4b4f088a5470034320cc07ba413d5f38bc037863aba6db92e689e982", null ],
      [ "QprcBinBothEdges", "group___group_q_p_r_c___types.html#gga4b010f50a4b4f088a5470034320cc07bac9533f3bebceb6c7cea62b1f76a602d3", null ]
    ] ],
    [ "en_qprc_ainedge_t", "group___group_q_p_r_c___types.html#gafde87720c1f2df3b7728889f9a25e95d", [
      [ "QprcAinDisable", "group___group_q_p_r_c___types.html#ggafde87720c1f2df3b7728889f9a25e95dab9a95b7a1e50d296904a19c3154dbc33", null ],
      [ "QprcAinFallingEdge", "group___group_q_p_r_c___types.html#ggafde87720c1f2df3b7728889f9a25e95daba1ce4652cd34a7fed2aef9c2cc74e30", null ],
      [ "QprcAinRisingEdge", "group___group_q_p_r_c___types.html#ggafde87720c1f2df3b7728889f9a25e95da66f26052ad5a7655629c9e264f014b80", null ],
      [ "QprcAinBothEdges", "group___group_q_p_r_c___types.html#ggafde87720c1f2df3b7728889f9a25e95dacaba302b30771ede9dafc63c869280d0", null ]
    ] ],
    [ "en_qprc_pcresetmask_t", "group___group_q_p_r_c___types.html#gaae9bc50f78a215c42dd881f305744e51", [
      [ "QprcResetMaskDisable", "group___group_q_p_r_c___types.html#ggaae9bc50f78a215c42dd881f305744e51a708af8a0ee6ea6de4030243586f13f09", null ],
      [ "QprcResetMask2Times", "group___group_q_p_r_c___types.html#ggaae9bc50f78a215c42dd881f305744e51ac29f96faa06fe2269b5a629492477a27", null ],
      [ "QprcResetMask4Times", "group___group_q_p_r_c___types.html#ggaae9bc50f78a215c42dd881f305744e51a0014661dde0ffb65fcd7595175e5105e", null ],
      [ "QprcResetMask8Times", "group___group_q_p_r_c___types.html#ggaae9bc50f78a215c42dd881f305744e51a99ce1535148a47182fada7b79e8b4100", null ]
    ] ],
    [ "en_qprc_compmode_t", "group___group_q_p_r_c___types.html#ga37cad2e17aceab54262abdbaa78be5a7", [
      [ "QprcCompareWithPosition", "group___group_q_p_r_c___types.html#gga37cad2e17aceab54262abdbaa78be5a7a234d4414065eecdbb7fce69595776713", null ],
      [ "QprcCompareWithRevolution", "group___group_q_p_r_c___types.html#gga37cad2e17aceab54262abdbaa78be5a7a118e79bf2be1b580a09c63c551ede8ff", null ]
    ] ],
    [ "en_qprc_irq_sel_t", "group___group_q_p_r_c___types.html#gabd9e50e74f12df3ad0bf6c7be9e4c220", [
      [ "QprcPcOfUfZeroIrq", "group___group_q_p_r_c___types.html#ggabd9e50e74f12df3ad0bf6c7be9e4c220a3df18adc8d625874394edf0b0c65f12e", null ],
      [ "QprcPcMatchIrq", "group___group_q_p_r_c___types.html#ggabd9e50e74f12df3ad0bf6c7be9e4c220a906004834f4e1adc44224fb5cae39851", null ],
      [ "QprcPcRcMatchIrq", "group___group_q_p_r_c___types.html#ggabd9e50e74f12df3ad0bf6c7be9e4c220ae2c4109ec50eb8b77afe8ea1ede8443f", null ],
      [ "QprcPcMatchRcMatchIrq", "group___group_q_p_r_c___types.html#ggabd9e50e74f12df3ad0bf6c7be9e4c220a0fc8e103f19480008790b85de819e5fd", null ],
      [ "QprcPcCountInvertIrq", "group___group_q_p_r_c___types.html#ggabd9e50e74f12df3ad0bf6c7be9e4c220a44f9e3e5dc6e2c84c0d454392e3d4a55", null ],
      [ "QprcRcOutrangeIrq", "group___group_q_p_r_c___types.html#ggabd9e50e74f12df3ad0bf6c7be9e4c220a5db6d04a36357752e0102af4d870d3ce", null ]
    ] ],
    [ "en_qprc_filter_width_t", "group___group_q_p_r_c___types.html#gacb422373221438cfdf5483737dbf061f", [
      [ "QprcNoFilter", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fa72735df6e070d0485235c4d9792e451a", null ],
      [ "QprcFilterWidth4Pclk", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fa84721ef81f2b951d7a2482903f8386cc", null ],
      [ "QprcFilterWidth8Pclk", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fa79c3374f2a6ee52e5a0d43c4ed9683e5", null ],
      [ "QprcFilterWidth16Pclk", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fa3ac903e5cacc73baa5346f35a3f6f25a", null ],
      [ "QprcFilterWidth32Pclk", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fabad37d646e6aec3ec2bdbbab78626321", null ],
      [ "QprcFilterWidth64Pclk", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fa2f12c09af77935a5fc9c35bb88dd9345", null ],
      [ "QprcFilterWidth128Pclk", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fa4dd49df0484f5d57ac23841f41d90a01", null ],
      [ "QprcFilterWidth256Pclk", "group___group_q_p_r_c___types.html#ggacb422373221438cfdf5483737dbf061fad0aadf00abdd9ef616a152247d2974db", null ]
    ] ]
];