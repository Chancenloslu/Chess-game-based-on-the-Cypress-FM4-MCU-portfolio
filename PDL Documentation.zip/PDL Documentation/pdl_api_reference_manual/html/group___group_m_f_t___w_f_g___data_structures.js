var group___group_m_f_t___w_f_g___data_structures =
[
    [ "stc_wfg_config_t", "structstc__wfg__config__t.html", [
      [ "enMode", "structstc__wfg__config__t.html#ac28cef2747d35bc723abc4e28c81af7c", null ],
      [ "enGtenBits", "structstc__wfg__config__t.html#a7292f5289a19ce5a54767cc14c2f15e3", null ],
      [ "enPselBits", "structstc__wfg__config__t.html#ae202b91c359c53b9489efe409f57052f", null ],
      [ "enPgenBits", "structstc__wfg__config__t.html#a92c30fb0bec9bca2b5a4047a20f87154", null ],
      [ "enDmodBits", "structstc__wfg__config__t.html#a6b21569b122d3256010a93a43e037951", null ],
      [ "enClk", "structstc__wfg__config__t.html#a9a819b977ada9831cd9ed2cc209ec36e", null ],
      [ "bWfgimerIrqMask", "structstc__wfg__config__t.html#afb0f42def8514a72c7343598998d347e", null ],
      [ "pfnWfgTimerIrqCallback", "structstc__wfg__config__t.html#af6a12a68f6aaa0d0a20dfb951bae267d", null ],
      [ "bTouchNvic", "structstc__wfg__config__t.html#a86630cf11f5ecd56ed09b483a8219099", null ]
    ] ],
    [ "stc_mft_wfg_intern_data_t", "structstc__mft__wfg__intern__data__t.html", [
      [ "pfnWfg10TimerIrqCallback", "structstc__mft__wfg__intern__data__t.html#a52f29d58df2926417e928c9c82ef50a4", null ],
      [ "pfnWfg32TimerIrqCallback", "structstc__mft__wfg__intern__data__t.html#a513f6fee47875b8126a9daae36e1cabe", null ],
      [ "pfnWfg54TimerIrqCallback", "structstc__mft__wfg__intern__data__t.html#ae719437b390cae3be5b84d137c98f3f7", null ],
      [ "pfnDtifAnalogFilterIrqCallback", "structstc__mft__wfg__intern__data__t.html#a97b861c643890e4112de4377c79df41b", null ],
      [ "pfnDtifDigtalFilterIrqCallback", "structstc__mft__wfg__intern__data__t.html#a03470ab7b4139da347bbc42539c235b0", null ]
    ] ],
    [ "stc_wfg_nzcl_config_t", "structstc__wfg__nzcl__config__t.html", [
      [ "bEnDigitalFilter", "structstc__wfg__nzcl__config__t.html#a0d3d9c629b072c3944b6f04912838551", null ],
      [ "enDigitalFilterWidth", "structstc__wfg__nzcl__config__t.html#a7277679f68e18d20e706b6d69eca819d", null ],
      [ "bEnAnalogFilter", "structstc__wfg__nzcl__config__t.html#ab5d33b2f53c8490a48971f82a52e9ff3", null ],
      [ "bHoldRto", "structstc__wfg__nzcl__config__t.html#a69d64edb578655fa0f234a603b44d88f", null ],
      [ "bSwitchToGpio", "structstc__wfg__nzcl__config__t.html#a98abf47487320fc819a14984fea89cca", null ],
      [ "bDtifDigitalFilterIrqMask", "structstc__wfg__nzcl__config__t.html#ac1e4127ad59b3285236b4cc8e7532b63", null ],
      [ "bDtifAnalogFilterIrqMask", "structstc__wfg__nzcl__config__t.html#a4fb35099c0350e8ac51fc3f8962fbfd9", null ],
      [ "pfnDtifDigtalFilterIrqCallback", "structstc__wfg__nzcl__config__t.html#a026492ffd8b70176f4f392d269d17b08", null ],
      [ "pfnDtifAnalogFilterIrqCallback", "structstc__wfg__nzcl__config__t.html#a5857324d6dc6265d02ce7be3e8964e24", null ],
      [ "bTouchNvic", "structstc__wfg__nzcl__config__t.html#a4a069e2792ce99d2fb96b5e6f55be84d", null ]
    ] ],
    [ "stc_mft_wfg_instance_data_t", "structstc__mft__wfg__instance__data__t.html", [
      [ "pstcInstance", "structstc__mft__wfg__instance__data__t.html#af5895a8388d19354e65aa644a6f178eb", null ],
      [ "stcInternData", "structstc__mft__wfg__instance__data__t.html#a4c9fae81c31e6bf78d168410cc8496c2", null ]
    ] ]
];