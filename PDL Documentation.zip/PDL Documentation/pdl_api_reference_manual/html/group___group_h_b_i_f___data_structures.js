var group___group_h_b_i_f___data_structures =
[
    [ "stc_hbif_mem_config_t", "structstc__hbif__mem__config__t.html", [
      [ "u32MemBaseAddress", "structstc__hbif__mem__config__t.html#ad555b8b0b07ebd1334ac713ff3c774c1", null ],
      [ "bMergeContinuousRead", "structstc__hbif__mem__config__t.html#a1f0542db997fb50ad1a30b9163b9df76", null ],
      [ "bSupportAsymmetryCache", "structstc__hbif__mem__config__t.html#a5c9a7f70a02b6ecf359c72481c710f29", null ],
      [ "bRegisterSpace", "structstc__hbif__mem__config__t.html#aa4330eb1a33ab2a79ce9efed612a7708", null ],
      [ "bHyperRamDevice", "structstc__hbif__mem__config__t.html#a7c8cf623e0a05aff974e547386d8d3d6", null ],
      [ "enWrapBustsize", "structstc__hbif__mem__config__t.html#a326b38d960d1985ed8cb4e1c11dbd25c", null ],
      [ "enReadCsHighCycle", "structstc__hbif__mem__config__t.html#aae6d477c77f303c7e7db43e85b4d5333", null ],
      [ "enWriteCsHighCycle", "structstc__hbif__mem__config__t.html#ae7502f000f12009ef1af7e800311b10d", null ],
      [ "enReadCsNextClkCycle", "structstc__hbif__mem__config__t.html#acdd85c6b7b02e538d518a852cd25517c", null ],
      [ "enWriteCsNextClkCycle", "structstc__hbif__mem__config__t.html#a9b0013fdbfa7f2da378c859aef1a65bb", null ],
      [ "enReadCsHoldCycle", "structstc__hbif__mem__config__t.html#afb016d71786043ebe120112720e989a7", null ],
      [ "enWriteCsHoldCycle", "structstc__hbif__mem__config__t.html#af6cb679aeb37678166b0f745981dbe73", null ],
      [ "enHyperRamLatencyCycle", "structstc__hbif__mem__config__t.html#a33157a4a42096dc29db744214b5c9b63", null ],
      [ "bGpoOutputLevel", "structstc__hbif__mem__config__t.html#a14934b0cf713c5c497de2770977c7807", null ]
    ] ],
    [ "stc_hbif_config_t", "structstc__hbif__config__t.html", [
      [ "pstcMem0Config", "structstc__hbif__config__t.html#ad362974fd65a7d8ee7381d922e68f667", null ],
      [ "pstcMem1Config", "structstc__hbif__config__t.html#a58e8fbf9d5dcb7c107ac4a8ec2d78363", null ],
      [ "bEnableInterrupt", "structstc__hbif__config__t.html#a229191b80488409380c4ef53e398c88d", null ],
      [ "bInterruptPolarity", "structstc__hbif__config__t.html#ae426050bc0c4a313a4235f95815d8aa1", null ],
      [ "pfnIrqCb", "structstc__hbif__config__t.html#ace5e3ed0c3d9d49cef7d26bc1da14c9e", null ],
      [ "bTouchNvic", "structstc__hbif__config__t.html#a8818c4bc924fc1cf3e35a645002a232c", null ]
    ] ]
];