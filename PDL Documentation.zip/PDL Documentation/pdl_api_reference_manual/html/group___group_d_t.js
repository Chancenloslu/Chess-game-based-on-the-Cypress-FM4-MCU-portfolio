var group___group_d_t =
[
    [ "Macros", "group___group_d_t___macros.html", null ],
    [ "Functions", "group___group_d_t___functions.html", "group___group_d_t___functions" ],
    [ "Data Structures", "group___group_d_t___data_structures.html", "group___group_d_t___data_structures" ],
    [ "Enumerated Types", "group___group_d_t___types.html", "group___group_d_t___types" ]
];