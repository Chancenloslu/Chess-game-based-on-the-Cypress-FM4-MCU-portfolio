var group___group_p_c_r_c___data_structures =
[
    [ "stc_pcrc_config_t", "structstc__pcrc__config__t.html", [
      [ "u32GeneratorPolynomial", "structstc__pcrc__config__t.html#adb8e2a220ca57489a1e31192d8a8b6ef", null ],
      [ "enInputFormat", "structstc__pcrc__config__t.html#ab101d160bb57aad6f678e9282b9c6257", null ],
      [ "enOutputFormat", "structstc__pcrc__config__t.html#adb301b341715e78b4586d9638b47f652", null ],
      [ "enInputDataSize", "structstc__pcrc__config__t.html#ac1a801e92a3b4ef26e9c44f8c55f7a88", null ],
      [ "u32CrcInitValue", "structstc__pcrc__config__t.html#af53a4cedf0e23ad988ed71b64efc296f", null ],
      [ "u32FinalXorValue", "structstc__pcrc__config__t.html#a848dd21ee989fa2536598f414f339a8a", null ],
      [ "bUseDstc", "structstc__pcrc__config__t.html#a60c71dc4d308ba70de401d245fd87d02", null ],
      [ "bIrqEn", "structstc__pcrc__config__t.html#ae662f16f51c79e92603f437704b78d67", null ],
      [ "pfnIrqCb", "structstc__pcrc__config__t.html#aebea33907497d7d2eea571cf7575dfaa", null ],
      [ "bTouchNvic", "structstc__pcrc__config__t.html#a0e05d6545b296aa225c807f66ee68070", null ]
    ] ]
];