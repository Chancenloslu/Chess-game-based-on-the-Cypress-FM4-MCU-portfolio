var group___group_w_c___functions =
[
    [ "Wc_Pres_SelClk", "group___group_w_c___functions.html#ga21c39618968437b69ee0501bd7075ef9", null ],
    [ "Wc_Pres_EnableDiv", "group___group_w_c___functions.html#gae2a6fa51d5021931eb4950a4d02cad4c", null ],
    [ "Wc_Pres_DisableDiv", "group___group_w_c___functions.html#gad3d62fbc09b374eb1754da456308be11", null ],
    [ "Wc_Pres_GetDivStat", "group___group_w_c___functions.html#gaeeccd024bebdc81d0f694f770ebcb17b", null ],
    [ "Wc_Init", "group___group_w_c___functions.html#gade7710744a927b2c6363b4e57fa6b3ab", null ],
    [ "Wc_DeInit", "group___group_w_c___functions.html#gac9828056937cdae1da80d9825d6338da", null ],
    [ "Wc_EnableCount", "group___group_w_c___functions.html#ga7030fcbafbdee9e621172caa14fd3c6e", null ],
    [ "Wc_DisableCount", "group___group_w_c___functions.html#ga93ecc287627973f42878e515d4b328f5", null ],
    [ "Wc_EnableIrq", "group___group_w_c___functions.html#ga70cc5328960ed0ce0c364be45df78f2b", null ],
    [ "Wc_DisableIrq", "group___group_w_c___functions.html#ga8ac6785d6d4fd75dec52cc3e11ebcca9", null ],
    [ "Wc_WriteReloadVal", "group___group_w_c___functions.html#gaea5e4831044a13fdde723e90a5097ec2", null ],
    [ "Wc_ReadCurCnt", "group___group_w_c___functions.html#ga87e21edaca8f32a5c230892485fd47fa", null ],
    [ "Wc_ClearIrqFlag", "group___group_w_c___functions.html#ga4d2d3b10ea04ad39cea32c38ba24b8d3", null ],
    [ "Wc_GetIrqFlag", "group___group_w_c___functions.html#ga458be8006775b2b9b24800089f25eaa5", null ],
    [ "Wc_GetOperationFlag", "group___group_w_c___functions.html#ga66e4384a1e764e85738d15fc66ac254a", null ],
    [ "Wc_IrqHandler", "group___group_w_c___functions.html#ga8b84b76038aa29bec3e11109459d2919", null ]
];