var group___group_r_t_c___macros =
[
    [ "PDL_RTC_WITHOUT_VBAT_TYPEA", "group___group_r_t_c___macros.html#gaf0ba47c89d1516884907f51c50c9e2d6", null ],
    [ "PDL_RTC_WITHOUT_VBAT_TYPEB", "group___group_r_t_c___macros.html#gad74a24745488aeab55adc2ec1fa7dd89", null ],
    [ "PDL_RTC_VBAT_TYPEA", "group___group_r_t_c___macros.html#ga82c2eba5ad465cda5c2c7efc0f85d7f9", null ],
    [ "PDL_RTC_VBAT_TYPEB", "group___group_r_t_c___macros.html#gab1d847ea3b1a9f33c6c004bc591e4a11", null ],
    [ "RTC_MAX_FREQ_CORR_VALUE", "group___group_r_t_c___macros.html#ga3d892eac32b7cb91f9fe2e4e81938741", null ],
    [ "RTC_MAX_FREQ_CORR_CYCLE_SET_VALUE", "group___group_r_t_c___macros.html#gaa72b727add17a5f281016a5acdb62ad1", null ],
    [ "RTC_MAX_TIMER_SET_VALUE", "group___group_r_t_c___macros.html#ga91e34ca39c5120abce99cb0bb12ac6e4", null ]
];