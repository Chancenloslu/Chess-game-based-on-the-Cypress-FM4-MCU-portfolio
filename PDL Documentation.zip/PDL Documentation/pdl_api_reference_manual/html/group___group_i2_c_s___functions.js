var group___group_i2_c_s___functions =
[
    [ "I2csIrqHandlerTx", "group___group_i2_c_s___functions.html#gade7c75506beddb6ee8732d66b4326b87", null ],
    [ "I2csIrqHandlerRx", "group___group_i2_c_s___functions.html#ga2cb2a7018327fb5debaa50f504298d06", null ],
    [ "I2csIrqHandlerStatus", "group___group_i2_c_s___functions.html#ga21deb1c9bd67f3d95b6531d392866219", null ],
    [ "I2cs_EnableIrq", "group___group_i2_c_s___functions.html#ga57f7c1dc3d2f6b56a8caaa93dcd05d71", null ],
    [ "I2cs_DisableIrq", "group___group_i2_c_s___functions.html#gad604536de741645e55536a0983b70c60", null ],
    [ "I2cs_Init", "group___group_i2_c_s___functions.html#ga42426bbf8d0932291f26392dd8161a2d", null ],
    [ "I2cs_DeInit", "group___group_i2_c_s___functions.html#ga2c832cf2a5083d00a177e84d45aa12a7", null ],
    [ "I2cs_SendData", "group___group_i2_c_s___functions.html#ga247f4d9b31624d8f80cf16567caf511a", null ],
    [ "I2cs_ReceiveData", "group___group_i2_c_s___functions.html#ga79a310de2c5dd89213553b3166bab9bc", null ],
    [ "I2cs_ConfigAck", "group___group_i2_c_s___functions.html#gad83b8280356ecf0461daadecce48213d", null ],
    [ "I2cs_GetAck", "group___group_i2_c_s___functions.html#ga6fe802f4c1a56988b533de23d3ec2837", null ],
    [ "I2cs_GetStatus", "group___group_i2_c_s___functions.html#gae952b27ae142978a3e9fe2515d197b38", null ],
    [ "I2cs_ClrStatus", "group___group_i2_c_s___functions.html#ga9a818b7a524cda3a167969235a443230", null ],
    [ "I2cs_GetDataDir", "group___group_i2_c_s___functions.html#ga5b724ce954da9b3db2807b816ee8fb75", null ]
];