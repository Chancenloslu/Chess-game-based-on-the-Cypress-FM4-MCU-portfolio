var group___group_h_s_s_p_i___macros =
[
    [ "HS_SPI_DEFAULT_CLK_DIV", "group___group_h_s_s_p_i___macros.html#gadaff103070adfab8964739886c67668e", null ],
    [ "HS_SPI_DEFAULT_MODE", "group___group_h_s_s_p_i___macros.html#ga664ba4af6e655196df6d3dd226d02cc8", null ],
    [ "HS_SPI_DEFAULT_PROTOCOL_MODE", "group___group_h_s_s_p_i___macros.html#gaa63ccc68545156a0a4783fe9aa4b47ea", null ]
];