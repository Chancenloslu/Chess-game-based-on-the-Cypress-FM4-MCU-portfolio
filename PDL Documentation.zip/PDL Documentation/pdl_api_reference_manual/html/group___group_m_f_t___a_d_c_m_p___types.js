var group___group_m_f_t___a_d_c_m_p___types =
[
    [ "en_adcmp_frt_t", "group___group_m_f_t___a_d_c_m_p___types.html#gaaab4ba7843a7121f223597b03ab5b922", [
      [ "Frt0ToAdcmp", "group___group_m_f_t___a_d_c_m_p___types.html#ggaaab4ba7843a7121f223597b03ab5b922a4813f36e5838cd67939c1e6e33ebdcb3", null ],
      [ "Frt1ToAdcmp", "group___group_m_f_t___a_d_c_m_p___types.html#ggaaab4ba7843a7121f223597b03ab5b922a9b65d169ca60238f67aed48f7bcbbb68", null ],
      [ "Frt2ToAdcmp", "group___group_m_f_t___a_d_c_m_p___types.html#ggaaab4ba7843a7121f223597b03ab5b922a6403d6901304c0f40ab9397cf9d35760", null ]
    ] ],
    [ "en_adcmp_frt_fm3_t", "group___group_m_f_t___a_d_c_m_p___types.html#ga368b11795d732976d110c69e1f0b491e", [
      [ "Frt0ToAdcmpFm3", "group___group_m_f_t___a_d_c_m_p___types.html#gga368b11795d732976d110c69e1f0b491eacb9eb5777fd249e9f90a3b8c4fea8095", null ],
      [ "Frt1ToAdcmpFm3", "group___group_m_f_t___a_d_c_m_p___types.html#gga368b11795d732976d110c69e1f0b491eacf559d68a4b24c4581e03774307a571b", null ],
      [ "Frt2ToAdcmpFm3", "group___group_m_f_t___a_d_c_m_p___types.html#gga368b11795d732976d110c69e1f0b491ea4f6cae1cb2911f52f2a02ffd3a437846", null ]
    ] ],
    [ "en_adcmp_buf_t", "group___group_m_f_t___a_d_c_m_p___types.html#ga77228429f24072fc5a68cd63c7ac0aab", [
      [ "AdcmpBufDisable", "group___group_m_f_t___a_d_c_m_p___types.html#gga77228429f24072fc5a68cd63c7ac0aaba09967144ac61a85e50b5413c5761265b", null ],
      [ "AdcmpBufFrtZero", "group___group_m_f_t___a_d_c_m_p___types.html#gga77228429f24072fc5a68cd63c7ac0aaba75dd8d714495edc646e81661171fbb14", null ],
      [ "AdcmpBufFrtPeak", "group___group_m_f_t___a_d_c_m_p___types.html#gga77228429f24072fc5a68cd63c7ac0aaba81f6b35cf3ed17717e2ec06da77317a6", null ],
      [ "AdcmpBufFrtZeroPeak", "group___group_m_f_t___a_d_c_m_p___types.html#gga77228429f24072fc5a68cd63c7ac0aabaee475fd1c68521f3693218d7f0fd7b1c", null ],
      [ "AdcmpBufFrtZeroMszcZero", "group___group_m_f_t___a_d_c_m_p___types.html#gga77228429f24072fc5a68cd63c7ac0aabaa6c2a26b9cfe2785e834b8fac63604b1", null ],
      [ "AdcmpBufFrtPeakMspcZero", "group___group_m_f_t___a_d_c_m_p___types.html#gga77228429f24072fc5a68cd63c7ac0aaba94063ac99ab95e4377bda71289923e3b", null ],
      [ "AdcmpBufFrtZeroMszcZeroOrFrtPeakMspcZero", "group___group_m_f_t___a_d_c_m_p___types.html#gga77228429f24072fc5a68cd63c7ac0aaba3ac4bf2dcd142bb448389d75d1c6dc9d", null ]
    ] ],
    [ "en_adcmp_start_trig_t", "group___group_m_f_t___a_d_c_m_p___types.html#ga9d02e4305bb4787a2a80ba1dbdd7410c", [
      [ "AdcmpStartTrig0", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410ca49196fcadf5287b673f550b33ca815ae", null ],
      [ "AdcmpStartTrig1", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410cab1db4ea6151bb46b5197ae9b30529eb7", null ],
      [ "AdcmpStartTrig2", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410ca83098d55db6a9cae732119058eb50a3d", null ],
      [ "AdcmpStartTrig3", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410cabd625a15d0576123a9ca6122ad8723d5", null ],
      [ "AdcmpStartTrig4", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410caa795f5064ed72c5581579d1f8001e7cd", null ],
      [ "AdcmpStartTrig5", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410ca93d461bb5d76b27ac8771edb1f34b096", null ],
      [ "AdcmpStartTrig6", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410ca807865a179ad43252a06d6c179c08ebe", null ],
      [ "AdcmpStartTrig7", "group___group_m_f_t___a_d_c_m_p___types.html#gga9d02e4305bb4787a2a80ba1dbdd7410cad81acd4eec15f2ae84a24b07d02421fc", null ]
    ] ],
    [ "en_adcmp_trig_sel_t", "group___group_m_f_t___a_d_c_m_p___types.html#ga4545d5b3a619e5145f3c69a7afe6beb8", [
      [ "AdcmpTrigAdc0Scan", "group___group_m_f_t___a_d_c_m_p___types.html#gga4545d5b3a619e5145f3c69a7afe6beb8a071038fe63d97246ea9fd6c628f847ea", null ],
      [ "AdcmpTrigAdc0Prio", "group___group_m_f_t___a_d_c_m_p___types.html#gga4545d5b3a619e5145f3c69a7afe6beb8aa8e968d8c000dce8e589aa7be4e449e4", null ],
      [ "AdcmpTrigAdc1Scan", "group___group_m_f_t___a_d_c_m_p___types.html#gga4545d5b3a619e5145f3c69a7afe6beb8a14728b1a8ab8fa07cef907956fb583c4", null ],
      [ "AdcmpTrigAdc1Prio", "group___group_m_f_t___a_d_c_m_p___types.html#gga4545d5b3a619e5145f3c69a7afe6beb8a9153621c3c090c708bd01e375d800ebd", null ],
      [ "AdcmpTrigAdc2Scan", "group___group_m_f_t___a_d_c_m_p___types.html#gga4545d5b3a619e5145f3c69a7afe6beb8a0ba9eb3666e35ea6ad98daf79308df14", null ],
      [ "AdcmpTrigAdc2Prio", "group___group_m_f_t___a_d_c_m_p___types.html#gga4545d5b3a619e5145f3c69a7afe6beb8a0b66bf3d022e74b8ff74be53745d80d0", null ]
    ] ],
    [ "en_adcmp_mode_t", "group___group_m_f_t___a_d_c_m_p___types.html#ga00fa91d647e95fb7d49b2799445d76bc", [
      [ "AdcmpNormalMode", "group___group_m_f_t___a_d_c_m_p___types.html#gga00fa91d647e95fb7d49b2799445d76bca32d951ee7d530e96e84c0156b9be4417", null ],
      [ "AdcmpOffsetMode", "group___group_m_f_t___a_d_c_m_p___types.html#gga00fa91d647e95fb7d49b2799445d76bca26f840fbbabf3c9fee0b32f19ebce54a", null ]
    ] ],
    [ "en_adcmp_occp_sel_t", "group___group_m_f_t___a_d_c_m_p___types.html#ga7d5a257fafc24590b4a331dca9418496", [
      [ "AdcmpSelOccp0", "group___group_m_f_t___a_d_c_m_p___types.html#gga7d5a257fafc24590b4a331dca9418496a7f7fc5b9f5c493e5b725d85e7f7ef99b", null ],
      [ "AdcmpSelOccp1", "group___group_m_f_t___a_d_c_m_p___types.html#gga7d5a257fafc24590b4a331dca9418496acec1cfc787d4b804f161cbf56f94f654", null ]
    ] ],
    [ "en_adcmp_mode_fm3_t", "group___group_m_f_t___a_d_c_m_p___types.html#ga0b4f7c95fd5f433574739f0bbaf6e64c", [
      [ "AdcmpAccpUpAccpDownFm3", "group___group_m_f_t___a_d_c_m_p___types.html#gga0b4f7c95fd5f433574739f0bbaf6e64cacef30ddcf4c81857a954e05e60183ee1", null ],
      [ "AdcmpAccpUpFm3", "group___group_m_f_t___a_d_c_m_p___types.html#gga0b4f7c95fd5f433574739f0bbaf6e64cad5b3930868ac3238705c2d99694bfa46", null ],
      [ "AdcmpAccpDownFm3", "group___group_m_f_t___a_d_c_m_p___types.html#gga0b4f7c95fd5f433574739f0bbaf6e64cae80df292599d3f9a3a5699c74719f4c4", null ],
      [ "AdcmpAccpUpAccpdnDownFm3", "group___group_m_f_t___a_d_c_m_p___types.html#gga0b4f7c95fd5f433574739f0bbaf6e64cacb881480947dceb072611b9fe38f604f", null ]
    ] ]
];