var group___group_h_s_s_p_i =
[
    [ "Macros", "group___group_h_s_s_p_i___macros.html", "group___group_h_s_s_p_i___macros" ],
    [ "Functions", "group___group_h_s_s_p_i___functions.html", "group___group_h_s_s_p_i___functions" ],
    [ "Global Variables", "group___group_h_s_s_p_i___global_variables.html", "group___group_h_s_s_p_i___global_variables" ],
    [ "Enumerated Types", "group___group_h_s_s_p_i___types.html", "group___group_h_s_s_p_i___types" ],
    [ "Data Structures", "group___group_h_s_s_p_i___data_structures.html", "group___group_h_s_s_p_i___data_structures" ]
];