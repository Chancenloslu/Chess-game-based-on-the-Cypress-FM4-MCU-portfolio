var group___group_c_r___types =
[
    [ "en_cr_freq_div_t", "group___group_c_r___types.html#gad2fe311267574b6b5757545ba13744a1", [
      [ "CrFreqDivBy4", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1aadd04ff898a2eb0ce02ab99b9eaba726", null ],
      [ "CrFreqDivBy8", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1a18b53519c26180e8afae2716bf410b85", null ],
      [ "CrFreqDivBy16", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1afe62cd11bb73c11c8b04aecf0eaa14d3", null ],
      [ "CrFreqDivBy32", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1a5e7980f0135c9e201e3fbc39d1ccf5b7", null ],
      [ "CrFreqDivBy64", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1acb43edf1166956bc6b39c8ee546f6bd9", null ],
      [ "CrFreqDivBy128", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1adb5ab5c0cfdff7235134466f4f242fe7", null ],
      [ "CrFreqDivBy256", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1a107021e0fe298df7286934c5657000dc", null ],
      [ "CrFreqDivBy512", "group___group_c_r___types.html#ggad2fe311267574b6b5757545ba13744a1a8600c756969561c6a23447bf976bd4f8", null ]
    ] ]
];