var group___group_s_w_w_d_g___functions =
[
    [ "SwwdgIrqHandler", "group___group_s_w_w_d_g___functions.html#ga1e416788401a2205a2462e9815d7f18d", null ],
    [ "Swwdg_Init", "group___group_s_w_w_d_g___functions.html#ga7a5b997f8a08cb88a8026d767809e74d", null ],
    [ "Swwdg_DeInit", "group___group_s_w_w_d_g___functions.html#gaaec302ce397e707e83cefd19db49d108", null ],
    [ "Swwdg_Start", "group___group_s_w_w_d_g___functions.html#ga70d1248f40e920ca7ad19914cf43aec8", null ],
    [ "Swwdg_Stop", "group___group_s_w_w_d_g___functions.html#ga77e2bc191330ca9c3b2ef746082ff58a", null ],
    [ "Swwdg_WriteWdgLoad", "group___group_s_w_w_d_g___functions.html#gaede3a75f1fa8debab3d7493851143ee7", null ],
    [ "Swwdg_ReadWdgValue", "group___group_s_w_w_d_g___functions.html#ga7975a5b036b5b6972a35691fea145dd6", null ],
    [ "Swwdg_Feed", "group___group_s_w_w_d_g___functions.html#gaab5fc2cad26a76aaa2607716d891bfdf", null ],
    [ "Swwdg_QuickFeed", "group___group_s_w_w_d_g___functions.html#ga9f0aaea1a58d3ae100b555420100a85e", null ],
    [ "Swwdg_EnableDbgBrkWdgCtl", "group___group_s_w_w_d_g___functions.html#ga5cc26a6d923ec7cabe9cae6504eced77", null ],
    [ "Swwdg_DisableDbgBrkWdgCtl", "group___group_s_w_w_d_g___functions.html#gaa2845dc49f29a56731063dcd7e04ee31", null ]
];