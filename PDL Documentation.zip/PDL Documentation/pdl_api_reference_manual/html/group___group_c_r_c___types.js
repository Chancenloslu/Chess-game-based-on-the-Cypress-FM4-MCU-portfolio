var group___group_c_r_c___types =
[
    [ "en_crc_mode_t", "group___group_c_r_c___types.html#ga1739fc3994266e0bf394b320f002ddcd", [
      [ "Crc16", "group___group_c_r_c___types.html#gga1739fc3994266e0bf394b320f002ddcda579db7768451c170382cb9654a748f1c", null ],
      [ "Crc32", "group___group_c_r_c___types.html#gga1739fc3994266e0bf394b320f002ddcda5cd0b889fbda66bb5ae233911dfe8795", null ]
    ] ]
];