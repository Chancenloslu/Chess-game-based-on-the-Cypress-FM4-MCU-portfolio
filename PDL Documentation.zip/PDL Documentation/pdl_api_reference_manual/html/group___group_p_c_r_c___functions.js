var group___group_p_c_r_c___functions =
[
    [ "PcrcIrqHandler", "group___group_p_c_r_c___functions.html#ga55534084bd864b91f47a4a68abbe2cb0", null ],
    [ "Pcrc_Init", "group___group_p_c_r_c___functions.html#ga9e4bb758a57124032b51eb815f4ca515", null ],
    [ "Pcrc_DeInit", "group___group_p_c_r_c___functions.html#gaa89c275411b64d0cfac5d2f91e6f9252", null ],
    [ "Pcrc_SetInitialValue", "group___group_p_c_r_c___functions.html#ga8c6b5873998dc5c9e4cff69f5cb38604", null ],
    [ "Pcrc_SetFinalXorValue", "group___group_p_c_r_c___functions.html#ga487a4917d748f85cace4953624bafde2", null ],
    [ "Pcrc_SetOutputDataFormat", "group___group_p_c_r_c___functions.html#gad11eb94593924c0d90242efff20be519", null ],
    [ "Pcrc_SetInputDataFormat", "group___group_p_c_r_c___functions.html#ga34248e69f33e03306c5fe5c39aee416a", null ],
    [ "Pcrc_SetInputDataSize", "group___group_p_c_r_c___functions.html#gae1f9dacdddb452f572602680211f1746", null ],
    [ "Pcrc_SetCfgTest", "group___group_p_c_r_c___functions.html#gaddc9b275b78a8ad620e5087a548b0d90", null ],
    [ "Pcrc_GetIntRequestFlag", "group___group_p_c_r_c___functions.html#ga0a87d2abe9295a38becb46d3f755e8fe", null ],
    [ "Pcrc_EnableIntRequest", "group___group_p_c_r_c___functions.html#gae573245aba9a90ba392dcbfc97324427", null ],
    [ "Pcrc_DisableIntRequest", "group___group_p_c_r_c___functions.html#gab81dfe108be955ef4545895c020d1f5e", null ],
    [ "Pcrc_EnableDmaTx", "group___group_p_c_r_c___functions.html#gad5d42b33db79223fa5e04eb0af4272aa", null ],
    [ "Pcrc_DisableDmaTx", "group___group_p_c_r_c___functions.html#gad1402f445b03e5c60a03c426a90192dc", null ],
    [ "Pcrc_GetLockStatus", "group___group_p_c_r_c___functions.html#gacaa2fb4aaee48231a547f67cebc0616d", null ],
    [ "Pcrc_ClrIntRequest", "group___group_p_c_r_c___functions.html#ga17bc98312459e474bf0814005eff6219", null ],
    [ "Pcrc_WriteData", "group___group_p_c_r_c___functions.html#ga47d1fcdd268f625499e8277e393abbf3", null ],
    [ "Pcrc_ReadResult", "group___group_p_c_r_c___functions.html#gad63849fa53751628ba5469d8c45ba26a", null ]
];