var group___group_r_e_s_e_t =
[
    [ "Functions", "group___group_r_e_s_e_t___functions.html", "group___group_r_e_s_e_t___functions" ],
    [ "Data Structures", "group___group_r_e_s_e_t___data_structures.html", "group___group_r_e_s_e_t___data_structures" ]
];