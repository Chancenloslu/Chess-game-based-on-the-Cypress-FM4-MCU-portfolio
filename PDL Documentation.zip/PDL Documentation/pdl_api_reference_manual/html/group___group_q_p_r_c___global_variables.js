var group___group_q_p_r_c___global_variables =
[
    [ "m_astcQprcInstanceDataLut", "group___group_q_p_r_c___global_variables.html#gae60b0e2fc797c2410e2d244a20fa1c80", null ]
];