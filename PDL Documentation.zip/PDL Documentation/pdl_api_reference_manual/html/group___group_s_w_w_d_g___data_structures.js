var group___group_s_w_w_d_g___data_structures =
[
    [ "stc_swwdg_config_t", "structstc__swwdg__config__t.html", [
      [ "u32LoadValue", "structstc__swwdg__config__t.html#a314a656575c76f833d0f2a5280d9c6a0", null ],
      [ "bResetEnable", "structstc__swwdg__config__t.html#a83416672bf74ac464fe113b9142d1129", null ],
      [ "bWinWdgEnable", "structstc__swwdg__config__t.html#aa674a6bd0c4fb86a25106e986bebe223", null ],
      [ "bWinWdgResetEnable", "structstc__swwdg__config__t.html#a3483dde09419d3cadd859528261c93c7", null ],
      [ "u8TimingWindow", "structstc__swwdg__config__t.html#a166e476a5c745c423021e1b01987f3f5", null ],
      [ "pfnSwwdgIrqCb", "structstc__swwdg__config__t.html#a623b5a26d79951fb721815b587201065", null ]
    ] ]
];