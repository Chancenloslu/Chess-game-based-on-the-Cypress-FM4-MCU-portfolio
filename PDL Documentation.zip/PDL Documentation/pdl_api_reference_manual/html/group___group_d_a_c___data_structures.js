var group___group_d_a_c___data_structures =
[
    [ "stc_dac_config_t", "structstc__dac__config__t.html", [
      [ "dac_channel", "structstc__dac__config__t.html#a71be72c6292102208b20f45489e70d3b", null ],
      [ "dac_type", "structstc__dac__config__t.html#aad6cbf5f173eae98e141eb7aeb8cf8df", null ]
    ] ]
];