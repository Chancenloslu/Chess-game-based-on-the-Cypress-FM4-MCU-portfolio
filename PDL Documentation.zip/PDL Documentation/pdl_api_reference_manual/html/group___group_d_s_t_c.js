var group___group_d_s_t_c =
[
    [ "Macros", "group___group_d_s_t_c___macros.html", "group___group_d_s_t_c___macros" ],
    [ "Functions", "group___group_d_s_t_c___functions.html", "group___group_d_s_t_c___functions" ],
    [ "Data Structures", "group___group_d_s_t_c___data_structures.html", "group___group_d_s_t_c___data_structures" ],
    [ "Enumerated Types", "group___group_d_s_t_c___types.html", "group___group_d_s_t_c___types" ]
];