var group___group_d_t___functions =
[
    [ "DtIrqHandler1", "group___group_d_t___functions.html#gaea72601bc20e2c1d9eef3db5b3bd52ec", null ],
    [ "DtIrqHandler2", "group___group_d_t___functions.html#ga1c0f54c7502f0b2c4d171421962c6a09", null ],
    [ "Dt_EnableIrq", "group___group_d_t___functions.html#ga5635bace52478f80a43f2cf9ae3166ec", null ],
    [ "Dt_DisableIrq", "group___group_d_t___functions.html#ga9f8f58cef0d377b5af4d203f3d835756", null ],
    [ "Dt_Init", "group___group_d_t___functions.html#gadfc4f12226731e32eb4ce2c5fa1fa200", null ],
    [ "Dt_DeInit", "group___group_d_t___functions.html#ga3f1d660a14e56683376217ceb771e452", null ],
    [ "Dt_EnableCount", "group___group_d_t___functions.html#gaf3b48739ea9830e8c2573279cc95405e", null ],
    [ "Dt_DisableCount", "group___group_d_t___functions.html#gae591305e28475967495c784a79a7b62f", null ],
    [ "Dt_GetIrqFlag", "group___group_d_t___functions.html#gac380b46ad4b8ab7972bc1695b918cba7", null ],
    [ "Dt_GetMaskIrqFlag", "group___group_d_t___functions.html#ga3608ced0971ecdb9b28fbfd0516e5181", null ],
    [ "Dt_ClrIrqFlag", "group___group_d_t___functions.html#ga61114a28a2ba7a0b6d856e9d4e451758", null ],
    [ "Dt_WriteLoadVal", "group___group_d_t___functions.html#ga8377e124257f8a80a11ccdbf9972624f", null ],
    [ "Dt_WriteBgLoadVal", "group___group_d_t___functions.html#ga2c62edff2823fb456fb62d915a5178f0", null ],
    [ "Dt_ReadCurCntVal", "group___group_d_t___functions.html#gacf96a53a3c26dcc192414ba967f69231", null ]
];