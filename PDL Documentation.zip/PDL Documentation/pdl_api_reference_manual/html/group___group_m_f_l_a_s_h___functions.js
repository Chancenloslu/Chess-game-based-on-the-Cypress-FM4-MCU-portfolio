var group___group_m_f_l_a_s_h___functions =
[
    [ "MFlash_ChipErase", "group___group_m_f_l_a_s_h___functions.html#ga2daf893829b62db8fe1f596ac381f09c", null ],
    [ "MFlash_SectorErase", "group___group_m_f_l_a_s_h___functions.html#gaab3435a9f8cc002339b4113fa82cd720", null ],
    [ "MFlash_WriteData32Bit", "group___group_m_f_l_a_s_h___functions.html#gadecd140adda77dab9a7e88c3cf08ae6e", null ],
    [ "MFlash_WriteData16Bit", "group___group_m_f_l_a_s_h___functions.html#ga1b6c0f382e82e777f4bbf5f7315584f7", null ],
    [ "MFlash_WriteData16Bit_Fm0Type3CrSecureArea", "group___group_m_f_l_a_s_h___functions.html#gabf4fde043bc1e29ebf03ef59d37966df", null ],
    [ "MFlash_SetDualMode", "group___group_m_f_l_a_s_h___functions.html#ga074ef22aeea6e151eecd70f43ca38806", null ],
    [ "MFlash_SetRemapMode", "group___group_m_f_l_a_s_h___functions.html#ga4e6c0fe3da5adcbf8560c28c0c60908a", null ],
    [ "MFlash_DualSectorErase", "group___group_m_f_l_a_s_h___functions.html#ga7daa977a620e7ef601b8fd8ae921de3a", null ],
    [ "MFlash_DualWriteData32Bit", "group___group_m_f_l_a_s_h___functions.html#ga4571c35173f70bbd7fe1cb90a28703e7", null ],
    [ "MFlash_DualWriteData16Bit", "group___group_m_f_l_a_s_h___functions.html#ga7ccf7406cdfc105be384edfd3e22cc1d", null ]
];