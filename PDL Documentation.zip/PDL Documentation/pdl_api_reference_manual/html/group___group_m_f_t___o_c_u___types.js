var group___group_m_f_t___o_c_u___types =
[
    [ "en_ocu_instance_index_t", "group___group_m_f_t___o_c_u___types.html#ga2d13679b93817c3ae8f5257d47e54ef6", [
      [ "OcuInstanceIndexOcu0", "group___group_m_f_t___o_c_u___types.html#gga2d13679b93817c3ae8f5257d47e54ef6abefefe52401f9ed7d697a87c870b60bc", null ],
      [ "OcuInstanceIndexOcu1", "group___group_m_f_t___o_c_u___types.html#gga2d13679b93817c3ae8f5257d47e54ef6aaddf255a5ed869482c23c83ec182ea8c", null ],
      [ "OcuInstanceIndexOcu2", "group___group_m_f_t___o_c_u___types.html#gga2d13679b93817c3ae8f5257d47e54ef6a286880a18dec66fe90d1a35f2db4bf1c", null ]
    ] ],
    [ "en_mft_ocu_frt_t", "group___group_m_f_t___o_c_u___types.html#gaf76dce590fb6f8e934c5e72ef9267e41", [
      [ "Frt0ToOcu", "group___group_m_f_t___o_c_u___types.html#ggaf76dce590fb6f8e934c5e72ef9267e41a8040f790fae0a27452d05e1cda665593", null ],
      [ "Frt1ToOcu", "group___group_m_f_t___o_c_u___types.html#ggaf76dce590fb6f8e934c5e72ef9267e41a2209c8902cbfc1c3128503d1b5fb0261", null ],
      [ "Frt2ToOcu", "group___group_m_f_t___o_c_u___types.html#ggaf76dce590fb6f8e934c5e72ef9267e41a1cf7cee201280129006f91cf7e26b57c", null ]
    ] ],
    [ "en_ocu_rt_out_state_t", "group___group_m_f_t___o_c_u___types.html#ga52e89696fd298e285a8cb85a91701e13", [
      [ "RtLowLevel", "group___group_m_f_t___o_c_u___types.html#gga52e89696fd298e285a8cb85a91701e13a081fc09d8cbac32b3e53a86c36fdcdea", null ],
      [ "RtHighLevel", "group___group_m_f_t___o_c_u___types.html#gga52e89696fd298e285a8cb85a91701e13a461e2d1e19d0bdb5c8080956ae7988c9", null ]
    ] ],
    [ "en_ocu_occp_buf_t", "group___group_m_f_t___o_c_u___types.html#gad48b929af2991741c8dc9208ac62bf47", [
      [ "OccpBufDisable", "group___group_m_f_t___o_c_u___types.html#ggad48b929af2991741c8dc9208ac62bf47a1c87786743b05888fe75314803031063", null ],
      [ "OccpBufTrsfByFrtZero", "group___group_m_f_t___o_c_u___types.html#ggad48b929af2991741c8dc9208ac62bf47a76123b354231624fc8f64dd6f23b32d3", null ],
      [ "OccpBufTrsfByFrtPeak", "group___group_m_f_t___o_c_u___types.html#ggad48b929af2991741c8dc9208ac62bf47aacbdf9d6c479cb55571c9528e27c007c", null ],
      [ "OccpBufTrsfByFrtZeroPeak", "group___group_m_f_t___o_c_u___types.html#ggad48b929af2991741c8dc9208ac62bf47aa9fe3a61cd258ee92a8fcdc3c4ebb77b", null ],
      [ "OccpBufTrsfByFrtZeroMszcZero", "group___group_m_f_t___o_c_u___types.html#ggad48b929af2991741c8dc9208ac62bf47a9c0bc83bac0b716e71326819440dd40e", null ],
      [ "OccpBufTrsfByFrtPeakMspcZero", "group___group_m_f_t___o_c_u___types.html#ggad48b929af2991741c8dc9208ac62bf47afdfc7bf009de9196dd1a6d7a6a4ad63e", null ],
      [ "OccpBufTrsfByFrtZeroMszcZeroOrFrtPeakMspcZero", "group___group_m_f_t___o_c_u___types.html#ggad48b929af2991741c8dc9208ac62bf47a34b505e18c361be8ff63abac4df3b014", null ]
    ] ],
    [ "en_ocu_ocse_buf_t", "group___group_m_f_t___o_c_u___types.html#gaa484df83a3d68bbaee9b9230791eb1d8", [
      [ "OcseBufDisable", "group___group_m_f_t___o_c_u___types.html#ggaa484df83a3d68bbaee9b9230791eb1d8a5210b83ecfc426bb9cef776ff82c5f52", null ],
      [ "OcseBufTrsfByFrtZero", "group___group_m_f_t___o_c_u___types.html#ggaa484df83a3d68bbaee9b9230791eb1d8a4fa2367f57cc27e9c6ff016f09d6cb3b", null ],
      [ "OcseBufTrsfByFrtPeak", "group___group_m_f_t___o_c_u___types.html#ggaa484df83a3d68bbaee9b9230791eb1d8aaf2b33e0e06a6ab4f7453ddd901f23e1", null ],
      [ "OcseBufTrsfByFrtZeroPeak", "group___group_m_f_t___o_c_u___types.html#ggaa484df83a3d68bbaee9b9230791eb1d8a299523047d0f0b453b19d2c79435368d", null ],
      [ "OcseBufTrsfByFrtZeroMszcZero", "group___group_m_f_t___o_c_u___types.html#ggaa484df83a3d68bbaee9b9230791eb1d8a97d99f5aed3822e06a3dc380ab884d1b", null ],
      [ "OcseBufTrsfByFrtPeakMspcZero", "group___group_m_f_t___o_c_u___types.html#ggaa484df83a3d68bbaee9b9230791eb1d8ae51fd296ef87f78d4bd0e1904f822e7d", null ],
      [ "OcseBufTrsfByFrtZeroMszcZeroOrFrtPeakMspcZero", "group___group_m_f_t___o_c_u___types.html#ggaa484df83a3d68bbaee9b9230791eb1d8a11209aca557a349d80e30a73ce5baa6f", null ]
    ] ],
    [ "en_rt_odd_status_t", "group___group_m_f_t___o_c_u___types.html#ga0aa2375ae37371770cc9f18056bba190", [
      [ "RtOutputHold", "group___group_m_f_t___o_c_u___types.html#gga0aa2375ae37371770cc9f18056bba190a6e26cb49ca621e2b6427e9175621677e", null ],
      [ "RtOutputHigh", "group___group_m_f_t___o_c_u___types.html#gga0aa2375ae37371770cc9f18056bba190a0d0d4046729dffb1693d3d7790632061", null ],
      [ "RtOutputLow", "group___group_m_f_t___o_c_u___types.html#gga0aa2375ae37371770cc9f18056bba190a8ebdbf45e84bd450b1a1f8ba78558fef", null ],
      [ "RtOutputReverse", "group___group_m_f_t___o_c_u___types.html#gga0aa2375ae37371770cc9f18056bba190a90ea862c6c761624b5f600b6ed7b508c", null ]
    ] ],
    [ "en_iop_flag_odd_t", "group___group_m_f_t___o_c_u___types.html#ga7420cd3e5b6f8bbf6ada71493e2ad65a", [
      [ "IopFlagHold", "group___group_m_f_t___o_c_u___types.html#gga7420cd3e5b6f8bbf6ada71493e2ad65aa443d8d6c65ee1ae3b17521e259157ef7", null ],
      [ "IopFlagSet", "group___group_m_f_t___o_c_u___types.html#gga7420cd3e5b6f8bbf6ada71493e2ad65aac3c032b0bd3f9bad46c4ee2e8d32b5d2", null ]
    ] ],
    [ "en_ocu_compare_mode_t", "group___group_m_f_t___o_c_u___types.html#gac16356fbb25208894dc09c5f784d2442", [
      [ "OcuOdd1ChangeEven1Change", "group___group_m_f_t___o_c_u___types.html#ggac16356fbb25208894dc09c5f784d2442ac0b0b6625d74718d68c66230c05e77b2", null ],
      [ "OcuOdd2ChangeEven1Change", "group___group_m_f_t___o_c_u___types.html#ggac16356fbb25208894dc09c5f784d2442a6c10e84277c25257f1df42ae4fe9e66a", null ],
      [ "OcuOdd1ChangeEvenActiveHigh", "group___group_m_f_t___o_c_u___types.html#ggac16356fbb25208894dc09c5f784d2442a68c9bc80fe626d4a78a497260b26b87b", null ],
      [ "OcuOddActiveHighEven1Change", "group___group_m_f_t___o_c_u___types.html#ggac16356fbb25208894dc09c5f784d2442abe142997eb78ad0e6c5c337f88e65cb1", null ],
      [ "OcuOddActiveLowEven1Change", "group___group_m_f_t___o_c_u___types.html#ggac16356fbb25208894dc09c5f784d2442adeb2002161c8ec407ae6f3c06e13a334", null ],
      [ "OcuOddActiveHighEvenActiveHigh", "group___group_m_f_t___o_c_u___types.html#ggac16356fbb25208894dc09c5f784d2442a38cb06460fe5879fac102a69d963d818", null ],
      [ "OcuOddActiveLowEvenActiveLow", "group___group_m_f_t___o_c_u___types.html#ggac16356fbb25208894dc09c5f784d2442acf2a44f1068469c4dd9d6da28353e162", null ]
    ] ]
];