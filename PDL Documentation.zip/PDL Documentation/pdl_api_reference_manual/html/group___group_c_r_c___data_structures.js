var group___group_c_r_c___data_structures =
[
    [ "stc_crc_config_t", "structstc__crc__config__t.html", [
      [ "enMode", "structstc__crc__config__t.html#a1941d96257983527f2b4c7530384b6bf", null ],
      [ "bUseDma", "structstc__crc__config__t.html#aaa878ec0f650a50e7d9762c0a2fd0da3", null ],
      [ "bFinalXor", "structstc__crc__config__t.html#af92f04d7b607fe87dc405133d1072c58", null ],
      [ "bResultLsbFirst", "structstc__crc__config__t.html#abc4f8107a9c1742b8038b47680532f36", null ],
      [ "bResultLittleEndian", "structstc__crc__config__t.html#aa52762c18556666e9bbb8d43b66d86b7", null ],
      [ "bDataLsbFirst", "structstc__crc__config__t.html#a35cf39a1c134b1b2ce5893c817e59e84", null ],
      [ "bDataLittleEndian", "structstc__crc__config__t.html#a87cef7df4819d683b492fd817faab9db", null ],
      [ "u32CrcInitValue", "structstc__crc__config__t.html#a43f93bdc529aebbe45c51dab80e0b3b9", null ]
    ] ]
];