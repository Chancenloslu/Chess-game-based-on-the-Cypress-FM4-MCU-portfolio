var group___group_m_f_l_a_s_h___types =
[
    [ "en_mflash_state_t", "group___group_m_f_l_a_s_h___types.html#ga9d449e0db5ae03f2f12620294fc87cf8", [
      [ "MFLASH_RET_OK", "group___group_m_f_l_a_s_h___types.html#gga9d449e0db5ae03f2f12620294fc87cf8ab0aa30fd21838d0aa5d49cad0d27eb11", null ],
      [ "MFLASH_RET_INVALID_PARA", "group___group_m_f_l_a_s_h___types.html#gga9d449e0db5ae03f2f12620294fc87cf8aa0c6c0cf029eb35fa41191e608abc476", null ],
      [ "MFLASH_RET_ABNORMAL", "group___group_m_f_l_a_s_h___types.html#gga9d449e0db5ae03f2f12620294fc87cf8aeec7eb7a1157d1a4573c413e5ae004e0", null ],
      [ "MFLASH_RET_ECCERROR", "group___group_m_f_l_a_s_h___types.html#gga9d449e0db5ae03f2f12620294fc87cf8ab25b6e0fdcbe8e7f82d97216a121cb22", null ]
    ] ],
    [ "en_mflash_toggle_t", "group___group_m_f_l_a_s_h___types.html#gab6cbe04ca75b7cebc43903e2238f57ef", [
      [ "MFLASH_CHK_TOGG_NORMAL", "group___group_m_f_l_a_s_h___types.html#ggab6cbe04ca75b7cebc43903e2238f57efa71c57a2225becfbe60b1bac40c8555fe", null ],
      [ "MFLASH_CHK_TOGG_ABNORMAL", "group___group_m_f_l_a_s_h___types.html#ggab6cbe04ca75b7cebc43903e2238f57efadef060e9d9420ed57f45c8984be47a85", null ]
    ] ],
    [ "en_mflash_datapoll_t", "group___group_m_f_l_a_s_h___types.html#ga2c1535f5c94b278d9c21723c253443bb", [
      [ "MFLASH_CHK_DPOL_NORMAL", "group___group_m_f_l_a_s_h___types.html#gga2c1535f5c94b278d9c21723c253443bba50b97ca2e613cbee1ade9563c1d1a1c9", null ],
      [ "MFLASH_CHK_DPOL_ABNORMAL", "group___group_m_f_l_a_s_h___types.html#gga2c1535f5c94b278d9c21723c253443bbab0a252b09a953e36314e82d08458f954", null ]
    ] ],
    [ "en_mflash_eccbitstat_t", "group___group_m_f_l_a_s_h___types.html#ga0eddf1a8fc97485ff528f40c65957b84", [
      [ "MFLASH_ECC_NORMAL", "group___group_m_f_l_a_s_h___types.html#gga0eddf1a8fc97485ff528f40c65957b84a8c5a0a5de5b21df573f5d4baa0ca10a1", null ],
      [ "MFLASH_ECC_ABNORMAL", "group___group_m_f_l_a_s_h___types.html#gga0eddf1a8fc97485ff528f40c65957b84a723e424d1037953dd50ab13a4e678f24", null ]
    ] ]
];