var group___group_e_x_t_i_f___functions =
[
    [ "Extif_IrqHandler", "group___group_e_x_t_i_f___functions.html#gad2fbd809d661155dd7731c07b0594338", null ],
    [ "Extif_InitArea", "group___group_e_x_t_i_f___functions.html#ga6127fb425f9cb298586cbfc69b778aad", null ],
    [ "Extif_ReadErrorStatus", "group___group_e_x_t_i_f___functions.html#ga32774579c4ce6c79ba51c18fdf4c20cc", null ],
    [ "Extif_ReadErrorAddress", "group___group_e_x_t_i_f___functions.html#ga234a6c5ac10414b9968aabb90805a1b3", null ],
    [ "Extif_ClearErrorStatus", "group___group_e_x_t_i_f___functions.html#gaadb79cb064cf61680dc0a3bb5a07610a", null ],
    [ "Extif_CheckSdcmdReady", "group___group_e_x_t_i_f___functions.html#ga12f87f7ec945154aa6dd3f2d26aaed76", null ],
    [ "Extif_SetSdramCommand", "group___group_e_x_t_i_f___functions.html#gafc6124a685f63afec105ba8f325c49cd", null ]
];