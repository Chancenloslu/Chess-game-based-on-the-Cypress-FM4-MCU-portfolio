var group___group_d_f_l_a_s_h___functions =
[
    [ "DFlash_ChipErase", "group___group_d_f_l_a_s_h___functions.html#ga85e4a4ce160b0b746bca5e4251282520", null ],
    [ "DFlash_SectorErase", "group___group_d_f_l_a_s_h___functions.html#gabb1db572a5a42c699000de9962976b30", null ],
    [ "DFlash_WriteData32Bit", "group___group_d_f_l_a_s_h___functions.html#ga84e18677878bb29e0f8620603793cc47", null ],
    [ "DFlash_WriteData16Bit", "group___group_d_f_l_a_s_h___functions.html#ga58559a52a9f3dea7358e69c7aecd8e43", null ],
    [ "DFlash_WriteData8Bit", "group___group_d_f_l_a_s_h___functions.html#gab5caf804ed3c1ccd98781bee3e69480d", null ]
];