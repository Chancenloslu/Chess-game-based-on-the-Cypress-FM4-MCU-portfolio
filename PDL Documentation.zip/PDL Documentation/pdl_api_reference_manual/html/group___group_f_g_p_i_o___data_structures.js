var group___group_f_g_p_i_o___data_structures =
[
    [ "stc_fgpio1pin_init_t", "structstc__fgpio1pin__init__t.html", [
      [ "bOutput", "structstc__fgpio1pin__init__t.html#a3bde76233f7d8945e330b65f50763817", null ],
      [ "bInitVal", "structstc__fgpio1pin__init__t.html#a9c901ccbae05003aa2fe5ffdf9324819", null ],
      [ "bPullup", "structstc__fgpio1pin__init__t.html#a4d74913a7843f7b86ee9070abac3b702", null ]
    ] ]
];