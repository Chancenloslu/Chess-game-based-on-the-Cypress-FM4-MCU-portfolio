var group___group_c_a_n___macros =
[
    [ "CAN_MESSAGE_DATA_BUFFER_SIZE", "group___group_c_a_n___macros.html#gab0e017ad1ba2ef70f0ff42e7bff84971", null ],
    [ "CAN_MESSAGE_BUFFER_COUNT", "group___group_c_a_n___macros.html#ga8962a7438c490ea9bff12bc8674aa710", null ],
    [ "CAN_BITRATE_TSEG1_MIN", "group___group_c_a_n___macros.html#ga2f673845b42bb425d2982f5b834afb79", null ],
    [ "CAN_BITRATE_TSEG1_MAX", "group___group_c_a_n___macros.html#ga47e0293ce35baca333d3d64a15f38f1d", null ],
    [ "CAN_BITRATE_TSEG2_MIN", "group___group_c_a_n___macros.html#ga7a84df02e015c047cbecdbd993a4b325", null ],
    [ "CAN_BITRATE_TSEG2_MAX", "group___group_c_a_n___macros.html#ga31edd35a946ef004d175944ecde7434f", null ],
    [ "CAN_BITRATE_SYNC_JUMP_WIDTH_MIN", "group___group_c_a_n___macros.html#ga79d40bf7af1641fdaed4acf123a5af97", null ],
    [ "CAN_BITRATE_SYNC_JUMP_WIDTH_MAX", "group___group_c_a_n___macros.html#ga153ad6b6362a5b1fbb71d2f330a7b50d", null ],
    [ "CAN_BITRATE_PRESCALER_MIN", "group___group_c_a_n___macros.html#ga707fc6e18fd00b96d9bf83272fc9e42b", null ],
    [ "CAN_BITRATE_PRESCALER_MAX", "group___group_c_a_n___macros.html#ga13e8425bda7971525429f52fecd980f3", null ],
    [ "CAN_MAX_CLK", "group___group_c_a_n___macros.html#ga5ea6bc00dc202d464e3e75a51f215d0c", null ]
];