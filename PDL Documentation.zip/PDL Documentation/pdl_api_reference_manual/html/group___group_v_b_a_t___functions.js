var group___group_v_b_a_t___functions =
[
    [ "Vbat_Init", "group___group_v_b_a_t___functions.html#ga995288dc2e31a7542e273b741e37709f", null ],
    [ "Vbat_SetPinFunc_VREGCTL", "group___group_v_b_a_t___functions.html#ga7b25a0ca893fc14e6a1c071f1ec2253e", null ],
    [ "Vbat_SetPinFunc_VWAKEUP", "group___group_v_b_a_t___functions.html#gab2eb643ba55bc3d4d05d90c3569068d7", null ],
    [ "Vbat_SetPinFunc_X0A_X1A", "group___group_v_b_a_t___functions.html#gabfbbf0755fe93e7a7e62bc555470e865", null ],
    [ "Vbat_InitGpioOutput", "group___group_v_b_a_t___functions.html#ga21a9488405841890f181beea022a2785", null ],
    [ "Vbat_InitGpioInput", "group___group_v_b_a_t___functions.html#gaedddcbe63dd7eded0b3746c36432659b", null ],
    [ "Vbat_PutPinP46", "group___group_v_b_a_t___functions.html#ga4ed80a11734e6a8f325e5b39f3fc3633", null ],
    [ "Vbat_PutPinP47", "group___group_v_b_a_t___functions.html#gad0c029ebcf3a4288365fc2f55659c18d", null ],
    [ "Vbat_PutPinP48", "group___group_v_b_a_t___functions.html#ga80e7b85a0620e9872eefbf9792d18e73", null ],
    [ "Vbat_PutPinP49", "group___group_v_b_a_t___functions.html#ga1e91d2b3a1b5341343b562912a017fda", null ],
    [ "Vbat_GetPinP46", "group___group_v_b_a_t___functions.html#gafe59db588d34fd53759742be36c6a917", null ],
    [ "Vbat_GetPinP47", "group___group_v_b_a_t___functions.html#ga6f7e9ad608ee74dc5c9934e0b77525d9", null ],
    [ "Vbat_GetPinP48", "group___group_v_b_a_t___functions.html#ga68ebffdcbe2a35ef49342fa6c62d8093", null ],
    [ "Vbat_GetPinP49", "group___group_v_b_a_t___functions.html#gac17681f3cb72b76126f72ae826d47f9c", null ],
    [ "Vbat_StartHibernation", "group___group_v_b_a_t___functions.html#ga96b0937433ad82e0be8f4228ebfcc064", null ],
    [ "Vbat_GetPowerOnFlag", "group___group_v_b_a_t___functions.html#gacdc32244286ee7bd33c1c4829f3b725f", null ],
    [ "Vbat_GetWakeupFlag", "group___group_v_b_a_t___functions.html#ga0050a26ba2d62c7c0d52959d55b34616", null ],
    [ "Vbat_ClrWakeupFlag", "group___group_v_b_a_t___functions.html#gad932714634470ca562aa072183cdaca6", null ]
];