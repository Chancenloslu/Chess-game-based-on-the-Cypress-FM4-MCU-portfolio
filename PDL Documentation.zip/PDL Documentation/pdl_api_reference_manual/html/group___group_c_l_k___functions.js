var group___group_c_l_k___functions =
[
    [ "Clk_IrqHandler", "group___group_c_l_k___functions.html#gab9f06ca0f9406c3638bd6e668899ca73", null ],
    [ "Clk_Init", "group___group_c_l_k___functions.html#ga217f9722717a8b68b5ddd5089bb681e8", null ],
    [ "Clk_EnableHscr", "group___group_c_l_k___functions.html#ga99c08b08fd5881bdac88eebfad3981d3", null ],
    [ "Clk_DisableHscr", "group___group_c_l_k___functions.html#gacf9cdb669008570177b67bd25bf578e5", null ],
    [ "Clk_EnableMainClock", "group___group_c_l_k___functions.html#gafad2698425e3cc48c441c87e2d543c81", null ],
    [ "Clk_DisableMainClock", "group___group_c_l_k___functions.html#ga30d6b56b91dee941105e825301d5189b", null ],
    [ "Clk_EnableSubClock", "group___group_c_l_k___functions.html#ga92e48a33f0515f896324c71c2c5dba54", null ],
    [ "Clk_DisableSubClock", "group___group_c_l_k___functions.html#gaf3149ed1dcc93e72cb6705076e8b9b9d", null ],
    [ "Clk_EnablePllClock", "group___group_c_l_k___functions.html#gacfb93af39dab8b71018d0cf22f90a292", null ],
    [ "Clk_DisablePllClock", "group___group_c_l_k___functions.html#gab20fb0b02216723ec451d5204c36e092", null ],
    [ "Clk_SetSource", "group___group_c_l_k___functions.html#ga2fb0973e2d3daedc9ce7e83890a8d4e0", null ],
    [ "Clk_PeripheralClockEnable", "group___group_c_l_k___functions.html#gac726822e488b9bcb278e89d5f45bed99", null ],
    [ "Clk_PeripheralClockDisable", "group___group_c_l_k___functions.html#gafa803e084b750655bfec6946e812cac2", null ],
    [ "Clk_PeripheralGetClockState", "group___group_c_l_k___functions.html#ga1817bd0310cd7258016f315af339c05e", null ],
    [ "Clk_PeripheralClockEnableAll", "group___group_c_l_k___functions.html#ga7f806d0c315e44538cc5d0e93886e51b", null ],
    [ "Clk_PeripheralClockDisableAll", "group___group_c_l_k___functions.html#ga3b61740a9f587e2a5a62ca1412134c61", null ],
    [ "Clk_PeripheralSetReset", "group___group_c_l_k___functions.html#ga623a8cd37ca6d0fe14ce7320f0f0cdce", null ],
    [ "Clk_PeripheralClearReset", "group___group_c_l_k___functions.html#ga5e124152a97ff169b00c575fb4866301", null ]
];