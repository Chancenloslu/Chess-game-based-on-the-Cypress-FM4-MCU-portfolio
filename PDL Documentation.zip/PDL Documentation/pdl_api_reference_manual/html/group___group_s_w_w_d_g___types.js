var group___group_s_w_w_d_g___types =
[
    [ "en_swwdg_timing_window_t", "group___group_s_w_w_d_g___types.html#gaeded1cf3d2732cd0a9f0e680b1f4e8e8", [
      [ "en_swwdg_timing_window_100", "group___group_s_w_w_d_g___types.html#ggaeded1cf3d2732cd0a9f0e680b1f4e8e8a02f08d358ab0da02a65ad86c52b31e3f", null ],
      [ "en_swwdg_timing_window_75", "group___group_s_w_w_d_g___types.html#ggaeded1cf3d2732cd0a9f0e680b1f4e8e8ae179ed1b4564578c496bf673625b9030", null ],
      [ "en_swwdg_timing_window_50", "group___group_s_w_w_d_g___types.html#ggaeded1cf3d2732cd0a9f0e680b1f4e8e8a7aa76994c9bcd8facf91cd72a1a0060d", null ],
      [ "en_swwdg_timing_window_25", "group___group_s_w_w_d_g___types.html#ggaeded1cf3d2732cd0a9f0e680b1f4e8e8a00a4ba487cad3bb6d572f0eb818d925b", null ]
    ] ]
];