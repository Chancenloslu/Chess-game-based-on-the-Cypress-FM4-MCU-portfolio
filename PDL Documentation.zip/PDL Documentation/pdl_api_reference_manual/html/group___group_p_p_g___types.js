var group___group_p_p_g___types =
[
    [ "en_ppg_opt_mode_t", "group___group_p_p_g___types.html#ga20f11cd2400863a7d6d4a97f0817d6de", [
      [ "Ppg8Bit8Bit", "group___group_p_p_g___types.html#gga20f11cd2400863a7d6d4a97f0817d6deab055ea07da545c99a6f7870f2f8a9e2e", null ],
      [ "Ppg8Bit8Pres", "group___group_p_p_g___types.html#gga20f11cd2400863a7d6d4a97f0817d6deaaa65f4760fce9cc62d4d77840751db46", null ],
      [ "Ppg16Bit", "group___group_p_p_g___types.html#gga20f11cd2400863a7d6d4a97f0817d6dea959c11a288f5127e56c68ac48ec7b0fd", null ],
      [ "Ppg16Bit16Pres", "group___group_p_p_g___types.html#gga20f11cd2400863a7d6d4a97f0817d6deab46571c3d37d93d40f7f6f8d7ca92b73", null ]
    ] ],
    [ "en_ppg_clock_t", "group___group_p_p_g___types.html#ga982436f01857fe628b597d0742249c17", [
      [ "PpgPclkDiv1", "group___group_p_p_g___types.html#gga982436f01857fe628b597d0742249c17a4a8b842ffed45a39542bb34bd1987c27", null ],
      [ "PpgPclkDiv4", "group___group_p_p_g___types.html#gga982436f01857fe628b597d0742249c17a6e66e0045e677254835256a4faa7ebec", null ],
      [ "PpgPclkDiv16", "group___group_p_p_g___types.html#gga982436f01857fe628b597d0742249c17ae3497dbb6f1b8e4d81625f34392432cb", null ],
      [ "PpgPclkDiv64", "group___group_p_p_g___types.html#gga982436f01857fe628b597d0742249c17a949ea28524e433edca21cf2e1df469b4", null ]
    ] ],
    [ "en_ppg_trig_t", "group___group_p_p_g___types.html#gabb58f747980f434c28a10ab21f6cca9f", [
      [ "PpgSoftwareTrig", "group___group_p_p_g___types.html#ggabb58f747980f434c28a10ab21f6cca9faa0f3c89555822003330cd8ea5c3e58fd", null ],
      [ "PpgMftGateTrig", "group___group_p_p_g___types.html#ggabb58f747980f434c28a10ab21f6cca9fac65082f2064467d79db0dbacfd83f99f", null ],
      [ "PpgTimingGenTrig", "group___group_p_p_g___types.html#ggabb58f747980f434c28a10ab21f6cca9fa9c0eea817d2db6f1bed9f2e2d27a956f", null ]
    ] ],
    [ "en_ppg_level_t", "group___group_p_p_g___types.html#ga0bd2786030f7df69c6e5d4acdc7f5980", [
      [ "PpgNormalLevel", "group___group_p_p_g___types.html#gga0bd2786030f7df69c6e5d4acdc7f5980a147c720e53623c9e9c97aa6f60715e77", null ],
      [ "PpgReverseLevel", "group___group_p_p_g___types.html#gga0bd2786030f7df69c6e5d4acdc7f5980acc5e4fcf7dd7e3aa75bd61fcc97f4be1", null ]
    ] ],
    [ "en_ppg_irq_mode_t", "group___group_p_p_g___types.html#gabfca5e31bfcf50ca8772e10a87cfa892", [
      [ "PpgIrqHighOrLowUnderflow", "group___group_p_p_g___types.html#ggabfca5e31bfcf50ca8772e10a87cfa892a9571acf0e6cf1af6d20395ce1649bb9b", null ],
      [ "PpgIrqHighUnderflow", "group___group_p_p_g___types.html#ggabfca5e31bfcf50ca8772e10a87cfa892a4c65bf8c6a6f606b22a2942e01745a9c", null ]
    ] ],
    [ "en_ppg_gate_level_t", "group___group_p_p_g___types.html#ga6a15c83c0a7c542541f4c68e49772cb8", [
      [ "PpgGateHighActive", "group___group_p_p_g___types.html#gga6a15c83c0a7c542541f4c68e49772cb8a449ad84cf39711f113337fa6c7c0713b", null ],
      [ "PpgGateLowActive", "group___group_p_p_g___types.html#gga6a15c83c0a7c542541f4c68e49772cb8a67c89c51898f0c446735ee0ffe3a69b0", null ]
    ] ],
    [ "en_ppg_upcnt_clk_t", "group___group_p_p_g___types.html#ga0f5a6375c4a2585df6cffe37c81228b0", [
      [ "PpgUpCntPclkDiv2", "group___group_p_p_g___types.html#gga0f5a6375c4a2585df6cffe37c81228b0a78340ae897049456f33cdab7feca21f2", null ],
      [ "PpgUpCntPclkDiv8", "group___group_p_p_g___types.html#gga0f5a6375c4a2585df6cffe37c81228b0a0c140dbc6b710348fd740adb8d92c880", null ],
      [ "PpgUpCntPclkDiv32", "group___group_p_p_g___types.html#gga0f5a6375c4a2585df6cffe37c81228b0a4543acb873b850624354eefb18388d3b", null ],
      [ "PpgUpCntPclkDiv64", "group___group_p_p_g___types.html#gga0f5a6375c4a2585df6cffe37c81228b0a08d47cc289a3f2d9094d0e09e9c82248", null ]
    ] ],
    [ "en_igbt_prohibition_mode_t", "group___group_p_p_g___types.html#gafc57cb4a13e32d2b950b083d6236a7ca", [
      [ "IgbtNormalMode", "group___group_p_p_g___types.html#ggafc57cb4a13e32d2b950b083d6236a7caae2e6c93e7161a04c334b604d57c671f6", null ],
      [ "IgbtStopProhibitionMode", "group___group_p_p_g___types.html#ggafc57cb4a13e32d2b950b083d6236a7caa59d649568632f1d1bd76bb9fcfdfc0d4", null ]
    ] ],
    [ "en_igbt_filter_width_t", "group___group_p_p_g___types.html#gae413b69f308d4c2a5a983feb79dd365f", [
      [ "IgbtNoFilter", "group___group_p_p_g___types.html#ggae413b69f308d4c2a5a983feb79dd365fa44800adb62eafbc2327ccaac373cc85d", null ],
      [ "IgbtFilter4Pclk", "group___group_p_p_g___types.html#ggae413b69f308d4c2a5a983feb79dd365fa5b87fdbb5a06639d5c04e292c168c08d", null ],
      [ "IgbtFilter8Pclk", "group___group_p_p_g___types.html#ggae413b69f308d4c2a5a983feb79dd365fa35705a11e942ffc40466b13f5261d187", null ],
      [ "IgbtFilter16Pclk", "group___group_p_p_g___types.html#ggae413b69f308d4c2a5a983feb79dd365fa26532c03231d701d8734b4d1ddd61fb2", null ],
      [ "IgbtFilter32Pclk", "group___group_p_p_g___types.html#ggae413b69f308d4c2a5a983feb79dd365fa3f98eb0412934c526a77498d8052db91", null ]
    ] ],
    [ "en_igbt_level_t", "group___group_p_p_g___types.html#ga59a9fbe4995dd13ac0a4dd0db1dcbf64", [
      [ "IgbtLevelNormal", "group___group_p_p_g___types.html#gga59a9fbe4995dd13ac0a4dd0db1dcbf64aca4e58631d1327965a4a93ea4a83cefa", null ],
      [ "IgbtLevelInvert", "group___group_p_p_g___types.html#gga59a9fbe4995dd13ac0a4dd0db1dcbf64a98c0aced3db8c46098c72f7b3c9cc233", null ]
    ] ],
    [ "en_ppg_irq_ch_t", "group___group_p_p_g___types.html#ga6ba7e1ac250ca660545a9a78cd801d3b", [
      [ "PpgCh024", "group___group_p_p_g___types.html#gga6ba7e1ac250ca660545a9a78cd801d3ba10ac789a3a3413efee5faefb99e31ee7", null ],
      [ "PpgCh81012", "group___group_p_p_g___types.html#gga6ba7e1ac250ca660545a9a78cd801d3ba4b5b3e80e5c8d7e8a2ac5443c41d08d7", null ],
      [ "PpgCh161820", "group___group_p_p_g___types.html#gga6ba7e1ac250ca660545a9a78cd801d3ba16430b0dc8c94c93740b4199a69b949b", null ]
    ] ]
];