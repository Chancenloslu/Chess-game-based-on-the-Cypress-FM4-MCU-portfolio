/**
 * Cyclically activates RGB LEDs: red -> green -> blue
 */
int BlinkRainbowMain();
int BlinkRainbowMain_s();