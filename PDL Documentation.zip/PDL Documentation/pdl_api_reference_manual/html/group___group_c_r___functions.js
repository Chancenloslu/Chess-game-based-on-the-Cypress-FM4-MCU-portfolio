var group___group_c_r___functions =
[
    [ "Cr_SetFreqDiv", "group___group_c_r___functions.html#gaff51fcb47fb61587a7e0f1a032cc5e39", null ],
    [ "Cr_SetTempTrimmingData", "group___group_c_r___functions.html#ga67a5b0caa507a43f64a0a37845cead41", null ],
    [ "Cr_GetTempTrimmingData", "group___group_c_r___functions.html#ga3c8207f6cb8e800c06719b0001173fff", null ],
    [ "Cr_SetFreqTrimmingData", "group___group_c_r___functions.html#ga64b630e8e0338a6e02fd6fe6f197c8cc", null ],
    [ "Cr_GetFreqTrimmingData", "group___group_c_r___functions.html#ga5d8398a8f4fc83a18fb6908ba9d065f7", null ]
];