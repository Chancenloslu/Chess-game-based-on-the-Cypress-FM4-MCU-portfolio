var group___group_m_f_t___w_f_g___types =
[
    [ "en_wfg_instance_index_t", "group___group_m_f_t___w_f_g___types.html#ga9cc14597fcccb5c34d58a5241a21f6b3", [
      [ "WfgInstanceIndexWfg0", "group___group_m_f_t___w_f_g___types.html#gga9cc14597fcccb5c34d58a5241a21f6b3ab73e58d38b576a3e3bf621e486d5bf05", null ],
      [ "WfgInstanceIndexWfg1", "group___group_m_f_t___w_f_g___types.html#gga9cc14597fcccb5c34d58a5241a21f6b3a4fdfc9336e07514ea4a29854f2dd6099", null ],
      [ "WfgInstanceIndexWfg2", "group___group_m_f_t___w_f_g___types.html#gga9cc14597fcccb5c34d58a5241a21f6b3a9444cbc87ca9ae0ea53f72b6cbda8c7e", null ]
    ] ],
    [ "en_mft_wfg_mode_t", "group___group_m_f_t___w_f_g___types.html#ga6f9fbda8e9a7f341a1e40dc97724610f", [
      [ "WfgThroughMode", "group___group_m_f_t___w_f_g___types.html#gga6f9fbda8e9a7f341a1e40dc97724610fa519c658d1d3cc63c2f452441803ce332", null ],
      [ "WfgRtPpgMode", "group___group_m_f_t___w_f_g___types.html#gga6f9fbda8e9a7f341a1e40dc97724610fa77689d5a37429124d5391a066c06ddb9", null ],
      [ "WfgTimerPpgMode", "group___group_m_f_t___w_f_g___types.html#gga6f9fbda8e9a7f341a1e40dc97724610fa4a2257f756f7f268bddaac2e8b0eb9b3", null ],
      [ "WfgRtDeadTimerMode", "group___group_m_f_t___w_f_g___types.html#gga6f9fbda8e9a7f341a1e40dc97724610fae132f14a8fa6338b51667d072d985060", null ],
      [ "WfgRtDeadTimerFilterMode", "group___group_m_f_t___w_f_g___types.html#gga6f9fbda8e9a7f341a1e40dc97724610fa98fa3682fa87fd9e39d0a433c3fdb14b", null ],
      [ "WfgPpgDeadTimerFilterMode", "group___group_m_f_t___w_f_g___types.html#gga6f9fbda8e9a7f341a1e40dc97724610fac7ea6097bbed4387d3af66071cf8711e", null ],
      [ "WfgPpgDeadTimerMode", "group___group_m_f_t___w_f_g___types.html#gga6f9fbda8e9a7f341a1e40dc97724610fa5c9972a4fe3db2fe4e356d22a50692d4", null ]
    ] ],
    [ "en_gten_bits_t", "group___group_m_f_t___w_f_g___types.html#ga0bf98e7bc5cf84bb4802fe9d6825cc81", [
      [ "GtenBits00B", "group___group_m_f_t___w_f_g___types.html#gga0bf98e7bc5cf84bb4802fe9d6825cc81a063a2649c6ac6b60d8b32805ac5bc5b1", null ],
      [ "GtenBits01B", "group___group_m_f_t___w_f_g___types.html#gga0bf98e7bc5cf84bb4802fe9d6825cc81a912af7acf1f1f7720725fe3cc68c0a71", null ],
      [ "GtenBits10B", "group___group_m_f_t___w_f_g___types.html#gga0bf98e7bc5cf84bb4802fe9d6825cc81a678c97fa01e1c6cdaf7154776e43970b", null ],
      [ "GtenBits11B", "group___group_m_f_t___w_f_g___types.html#gga0bf98e7bc5cf84bb4802fe9d6825cc81a7c5f6db38b8ef9f3f8294ff52dbe9868", null ]
    ] ],
    [ "en_psel_bits_t", "group___group_m_f_t___w_f_g___types.html#ga2b7d727395a517722702f53908977267", [
      [ "PselBits00B", "group___group_m_f_t___w_f_g___types.html#gga2b7d727395a517722702f53908977267a8f6a264859ea35359f8b80c019dce208", null ],
      [ "PselBits01B", "group___group_m_f_t___w_f_g___types.html#gga2b7d727395a517722702f53908977267a3b70243c1904279678c192c00ed3ed53", null ],
      [ "PselBits10B", "group___group_m_f_t___w_f_g___types.html#gga2b7d727395a517722702f53908977267a2e8600cc73ee5a3135f53f9f5c1ed1c1", null ],
      [ "PselBits11B", "group___group_m_f_t___w_f_g___types.html#gga2b7d727395a517722702f53908977267ada3a46c71439b495b384a3139b483ca7", null ]
    ] ],
    [ "en_pgen_bits_t", "group___group_m_f_t___w_f_g___types.html#gafccb6ac8fa2085e67891ad5354e2e13f", [
      [ "PgenBits00B", "group___group_m_f_t___w_f_g___types.html#ggafccb6ac8fa2085e67891ad5354e2e13faf243e38170b30726810798b34fc07fd6", null ],
      [ "PgenBits01B", "group___group_m_f_t___w_f_g___types.html#ggafccb6ac8fa2085e67891ad5354e2e13fac5cb60cbcb1dae160cc2e8b3f4b6a8c1", null ],
      [ "PgenBits10B", "group___group_m_f_t___w_f_g___types.html#ggafccb6ac8fa2085e67891ad5354e2e13fa6412c95855ef34cb178c34042444edcf", null ],
      [ "PgenBits11B", "group___group_m_f_t___w_f_g___types.html#ggafccb6ac8fa2085e67891ad5354e2e13faa9795df8b4af37b0da5eb82a2c6cadeb", null ]
    ] ],
    [ "en_dmod_bits_t", "group___group_m_f_t___w_f_g___types.html#ga805910cd27ef98d3f1520e7cdcac639e", [
      [ "DmodBits00B", "group___group_m_f_t___w_f_g___types.html#gga805910cd27ef98d3f1520e7cdcac639eac37d627ffeb0697203c858cebea5652a", null ],
      [ "DmodBits01B", "group___group_m_f_t___w_f_g___types.html#gga805910cd27ef98d3f1520e7cdcac639ea87a708824791deaa7e3567d8ddea1906", null ],
      [ "DmodBits10B", "group___group_m_f_t___w_f_g___types.html#gga805910cd27ef98d3f1520e7cdcac639ea26d683047acc9d32167ee63856676f47", null ],
      [ "DmodBits11B", "group___group_m_f_t___w_f_g___types.html#gga805910cd27ef98d3f1520e7cdcac639ea7e859eba5acecd8bf27f065f7f863d89", null ]
    ] ],
    [ "en_wfg_timer_clock_t", "group___group_m_f_t___w_f_g___types.html#ga87f41071c3648aa8ce27bfccf49802d6", [
      [ "WfgPlckDiv1", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6ac6069284b6b0b376db826d4f71d1a6c4", null ],
      [ "WfgPlckDiv2", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6ab9abef0e63e1a6cc8d5267c165ee97ad", null ],
      [ "WfgPlckDiv4", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6ab2abc3bf06e90c32e0308a0a6c8830e7", null ],
      [ "WfgPlckDiv8", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6a566c9bcfee6f0c0d472cbba353bbd653", null ],
      [ "WfgPlckDiv16", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6aa84fdc8cfb8ec23ddd259e3e83536b84", null ],
      [ "WfgPlckDiv32", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6a56ac8e5596492661ec27054015fe327b", null ],
      [ "WfgPlckDiv64", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6a7ce9fb38bbec4d52451c694925247af0", null ],
      [ "WfgPlckDiv128", "group___group_m_f_t___w_f_g___types.html#gga87f41071c3648aa8ce27bfccf49802d6aae3796fc899083293593106903cb5bb1", null ]
    ] ],
    [ "en_nzcl_filter_width_t", "group___group_m_f_t___w_f_g___types.html#ga3350e1f4df490791b77a0bf912f9bf01", [
      [ "NzlcNoFilter", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01a221fae5d9bfa432901b88f71316443b4", null ],
      [ "NzlcWidth4Cycle", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01a08d6c73912d5e285e87dc4a1bd76f355", null ],
      [ "NzlcWidth8Cycle", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01a5da139e76f65caf8f90375be8b7af1a3", null ],
      [ "NzlcWidth16Cycle", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01a1dbc8b82c42981fba713fd6b5956e344", null ],
      [ "NzlcWidth32Cycle", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01ab2c373178d056b083751a8e2207bda6e", null ],
      [ "NzlcWidth64Cycle", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01ac00e91f3b15f19aef84b30941c40e890", null ],
      [ "NzlcWidth128Cycle", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01ad6867624b3fa877f990014d7f78b83d0", null ],
      [ "NzlcWidth256Cycle", "group___group_m_f_t___w_f_g___types.html#gga3350e1f4df490791b77a0bf912f9bf01abfd907216d7f1ddc44d23cff1b075df8", null ]
    ] ]
];