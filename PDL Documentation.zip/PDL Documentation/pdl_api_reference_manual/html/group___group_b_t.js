var group___group_b_t =
[
    [ "Macros", "group___group_b_t___macros.html", null ],
    [ "Functions", "group___group_b_t___functions.html", "group___group_b_t___functions" ],
    [ "Globals Variables", "group___group_b_t___global_variables.html", "group___group_b_t___global_variables" ],
    [ "Data Structures", "group___group_b_t___data_structures.html", "group___group_b_t___data_structures" ],
    [ "Enumerated Types", "group___group_b_t___types.html", "group___group_b_t___types" ]
];