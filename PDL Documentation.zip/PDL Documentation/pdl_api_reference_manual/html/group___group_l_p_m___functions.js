var group___group_l_p_m___functions =
[
    [ "Lpm_GoToStandByMode", "group___group_l_p_m___functions.html#ga958337eadb71b797628ce3f10dc4f088", null ],
    [ "Lpm_ConfigDeepStbRetCause", "group___group_l_p_m___functions.html#ga8095d186c826684af613765956f9af53", null ],
    [ "Lpm_ReadDeepStbRetCause", "group___group_l_p_m___functions.html#ga980114688f65655c8ca4448ad0dc869f", null ],
    [ "Lpm_SetWkupPinLevel", "group___group_l_p_m___functions.html#gabe202061eed735288292c8edfb2e43a3", null ],
    [ "Lpm_ConfigSubClk", "group___group_l_p_m___functions.html#gae39de37a9fd0ca6748f680691c258926", null ],
    [ "Lpm_ConfigDeepStbRAMRetention", "group___group_l_p_m___functions.html#ga22a9e5c699ec48ad8820fd4bd778b2d2", null ],
    [ "Lpm_ConfigInternalVoltage", "group___group_l_p_m___functions.html#gab42f5c535d8e898713fad5345b0326ec", null ],
    [ "Lpm_SelMainOscTypes", "group___group_l_p_m___functions.html#ga0785bc7269871b6a81a0ae4c34bae3d8", null ],
    [ "Lpm_ConfigFlashPower", "group___group_l_p_m___functions.html#ga68b6a4240e9b3f23e43a7d3f110eec7d", null ],
    [ "Lpm_Readu8DataBackupRegister", "group___group_l_p_m___functions.html#ga76e23468726d0162da22bc8bff45984d", null ],
    [ "Lpm_Writeu8DataBackupRegister", "group___group_l_p_m___functions.html#gacc866ad40a5b2aa963152100a8ecba28", null ],
    [ "Lpm_Readu16DataBackupRegister", "group___group_l_p_m___functions.html#gad331309a850be8f4015c936d09793990", null ],
    [ "Lpm_Writeu16DataBackupRegister", "group___group_l_p_m___functions.html#ga1143822398fcd70e4f997c5d68834cfd", null ],
    [ "Lpm_Readu32DataBackupRegister", "group___group_l_p_m___functions.html#ga097690bccb77a74b2e5f7e0d49b87325", null ],
    [ "Lpm_Writeu32DataBackupRegister", "group___group_l_p_m___functions.html#ga393cd1950087d7011aa9b8469dc09b83", null ]
];