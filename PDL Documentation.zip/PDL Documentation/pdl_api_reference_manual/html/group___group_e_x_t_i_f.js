var group___group_e_x_t_i_f =
[
    [ "Macros", "group___group_e_x_t_i_f___macros.html", "group___group_e_x_t_i_f___macros" ],
    [ "Functions", "group___group_e_x_t_i_f___functions.html", "group___group_e_x_t_i_f___functions" ],
    [ "Data Structures", "group___group_e_x_t_i_f___data_structures.html", "group___group_e_x_t_i_f___data_structures" ],
    [ "Enumerated Types", "group___group_e_x_t_i_f___types.html", "group___group_e_x_t_i_f___types" ]
];