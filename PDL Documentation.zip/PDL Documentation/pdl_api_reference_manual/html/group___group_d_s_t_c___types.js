var group___group_d_s_t_c___types =
[
    [ "func_ptr_dstc_args_t", "group___group_d_s_t_c___types.html#gaf0544e8391b379fa658dfd4c5c2c1753", null ],
    [ "en_dstc_cmd_t", "group___group_d_s_t_c___types.html#gaa99b3c247460d0d9bf6c45a9bc895d93", [
      [ "CmdStandyRelease", "group___group_d_s_t_c___types.html#ggaa99b3c247460d0d9bf6c45a9bc895d93a5894ea6616b8bc92ece5b0e49d3d1a9c", null ],
      [ "CmdStandyTransition", "group___group_d_s_t_c___types.html#ggaa99b3c247460d0d9bf6c45a9bc895d93a783144d6d49a76031ce0ce92160c45d8", null ],
      [ "CmdSwclr", "group___group_d_s_t_c___types.html#ggaa99b3c247460d0d9bf6c45a9bc895d93ad68fdd6860f05eca8f1318eb1ee43c37", null ],
      [ "CmdErclr", "group___group_d_s_t_c___types.html#ggaa99b3c247460d0d9bf6c45a9bc895d93a80efe69486897eace9fe98c08d00fa4c", null ],
      [ "CmdRbclr", "group___group_d_s_t_c___types.html#ggaa99b3c247460d0d9bf6c45a9bc895d93a98a308d6c3974a6142c47f88ec9f2f82", null ],
      [ "CmdMkclr", "group___group_d_s_t_c___types.html#ggaa99b3c247460d0d9bf6c45a9bc895d93aaca98ca797a4fd4e590d594ac59fddc2", null ]
    ] ],
    [ "en_dstc_swpr_t", "group___group_d_s_t_c___types.html#gae8a055e3f9dfb3334c4dbab0ae75ba3b", [
      [ "PriorityHighest", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3ba561007eb9b21d1927700e10a9ca80819", null ],
      [ "Priority1_2", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3bad0dbeed28d553c969f7d302e6c903f52", null ],
      [ "Priority1_3", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3ba51fb9f7ed43887361fd0d0d9f6bfe94b", null ],
      [ "Priority1_7", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3bac3a800cdec86872279d0134344ff256c", null ],
      [ "Priority1_15", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3baebe00feaad5411ce66eb9ebd8c9d46ee", null ],
      [ "Priority1_31", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3bae69d0a71427899993aa69e9e34037c9d", null ],
      [ "Priority1_63", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3bae517934fbbc36d8df7cfb4f01d07e745", null ],
      [ "PriorityLowest", "group___group_d_s_t_c___types.html#ggae8a055e3f9dfb3334c4dbab0ae75ba3ba94eca72a9e31924861b7de693296b36d", null ]
    ] ],
    [ "en_dstc_est_error_t", "group___group_d_s_t_c___types.html#gafca5e8575d1e3cdd4993f50130f99e7e", [
      [ "NoError", "group___group_d_s_t_c___types.html#ggafca5e8575d1e3cdd4993f50130f99e7eaef9104c292609ba6db320509be8fe27f", null ],
      [ "SourceAccessError", "group___group_d_s_t_c___types.html#ggafca5e8575d1e3cdd4993f50130f99e7ea9984ed8f40d4bf9c4b39744e5760ae10", null ],
      [ "DestinationAccessError", "group___group_d_s_t_c___types.html#ggafca5e8575d1e3cdd4993f50130f99e7ea5d6c19b6a7b5e00a7c2e4246da057a16", null ],
      [ "ForcedTransferStop", "group___group_d_s_t_c___types.html#ggafca5e8575d1e3cdd4993f50130f99e7eabd472e8a9b56efcf424d73bf44ed53ca", null ],
      [ "DesAccessError", "group___group_d_s_t_c___types.html#ggafca5e8575d1e3cdd4993f50130f99e7ea518472f3bfc435705648a69305005282", null ],
      [ "DesOpenError", "group___group_d_s_t_c___types.html#ggafca5e8575d1e3cdd4993f50130f99e7eaf077f274333761f52a68c1a0de61115c", null ],
      [ "UnknownError", "group___group_d_s_t_c___types.html#ggafca5e8575d1e3cdd4993f50130f99e7ea36b13bee92e122caddcb8abefb6eec31", null ]
    ] ]
];