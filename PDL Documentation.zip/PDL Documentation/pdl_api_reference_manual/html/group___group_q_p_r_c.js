var group___group_q_p_r_c =
[
    [ "Macros", "group___group_q_p_r_c___macros.html", null ],
    [ "Functions", "group___group_q_p_r_c___functions.html", "group___group_q_p_r_c___functions" ],
    [ "Data Structures", "group___group_q_p_r_c___data_structures.html", "group___group_q_p_r_c___data_structures" ],
    [ "Enumerated Types", "group___group_q_p_r_c___types.html", "group___group_q_p_r_c___types" ],
    [ "Global Variables", "group___group_q_p_r_c___global_variables.html", "group___group_q_p_r_c___global_variables" ]
];