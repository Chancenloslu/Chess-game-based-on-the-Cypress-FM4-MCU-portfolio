var group___group_c_a_n_f_d___macros =
[
    [ "CANFD_MESSAGE_DATA_BUFFER_SIZE", "group___group_c_a_n_f_d___macros.html#gab224ef5ecc79b6c1b2ef5315e5282d50", null ],
    [ "CANFD_MESSAGE_DATA_BUFFER_SIZEW", "group___group_c_a_n_f_d___macros.html#ga2a261fee136b0bc1ec7d48a8ee2874f6", null ],
    [ "CANFD_MESSAGE_RXBUFFER_COUNT", "group___group_c_a_n_f_d___macros.html#ga8a27446306741c399a4c1d32b1153870", null ],
    [ "CANFD_MESSAGE_RXFIFO_COUNT", "group___group_c_a_n_f_d___macros.html#ga04718ae04aefabaa93e1b6578855b07b", null ],
    [ "CANFD_MESSAGE_TXBUFFER_COUNT", "group___group_c_a_n_f_d___macros.html#ga8bb55dda74f7c7678dec1abfa00243a2", null ],
    [ "CANFD_MSGIDX_MIN", "group___group_c_a_n_f_d___macros.html#gadec48409a8c8c4c9ff335c8c1e806cdc", null ],
    [ "CANFD_ERROR_STE", "group___group_c_a_n_f_d___macros.html#gaff573b610f0580fc315aeb9d5afc1995", null ]
];