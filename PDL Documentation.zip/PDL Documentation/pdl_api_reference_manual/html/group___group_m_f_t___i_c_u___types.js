var group___group_m_f_t___i_c_u___types =
[
    [ "en_icu_instance_index_t", "group___group_m_f_t___i_c_u___types.html#ga94565987f7aea53df66ed92a9eb66883", [
      [ "IcuInstanceIndexIcu0", "group___group_m_f_t___i_c_u___types.html#gga94565987f7aea53df66ed92a9eb66883a583259ab5a10fe15454a9e4c494ddb4d", null ],
      [ "IcuInstanceIndexIcu1", "group___group_m_f_t___i_c_u___types.html#gga94565987f7aea53df66ed92a9eb66883a8f134b61964ef5431cee6319906f5e25", null ],
      [ "IcuInstanceIndexIcu2", "group___group_m_f_t___i_c_u___types.html#gga94565987f7aea53df66ed92a9eb66883a4da09e10932d6662ea62400eb343e345", null ]
    ] ],
    [ "en_mft_icu_frt_t", "group___group_m_f_t___i_c_u___types.html#ga2cf1597347f0528a531e7ca77a1ec871", [
      [ "Frt0ToIcu", "group___group_m_f_t___i_c_u___types.html#gga2cf1597347f0528a531e7ca77a1ec871ae9bb26a44921a601ab1c7e9b4d0e64f2", null ],
      [ "Frt1ToIcu", "group___group_m_f_t___i_c_u___types.html#gga2cf1597347f0528a531e7ca77a1ec871aa670eec6d573ff5bfdf0f2a46fb83238", null ],
      [ "Frt2ToIcu", "group___group_m_f_t___i_c_u___types.html#gga2cf1597347f0528a531e7ca77a1ec871a6a93e79a017ef3ba8c5fdccc1967e24d", null ],
      [ "IcuFrtToExt0", "group___group_m_f_t___i_c_u___types.html#gga2cf1597347f0528a531e7ca77a1ec871a36c3b6d1370d89e57102519a8f31c52f", null ],
      [ "IcuFrtToExt1", "group___group_m_f_t___i_c_u___types.html#gga2cf1597347f0528a531e7ca77a1ec871aa45fce583bf9513c7bf7f6b6959228ad", null ]
    ] ],
    [ "en_mft_icu_mode_t", "group___group_m_f_t___i_c_u___types.html#ga79c2c6a05e5c950336b60d07c9590a98", [
      [ "IcuDisable", "group___group_m_f_t___i_c_u___types.html#gga79c2c6a05e5c950336b60d07c9590a98a5c8b8af247c6cdf3348f451de19f36dc", null ],
      [ "IcuRisingDetect", "group___group_m_f_t___i_c_u___types.html#gga79c2c6a05e5c950336b60d07c9590a98ae2ec95581caf5c19623a0813fa406970", null ],
      [ "IcuFallingDetect", "group___group_m_f_t___i_c_u___types.html#gga79c2c6a05e5c950336b60d07c9590a98aec5c738255f2d94d05d71e6df2d39373", null ],
      [ "IcuBothDetect", "group___group_m_f_t___i_c_u___types.html#gga79c2c6a05e5c950336b60d07c9590a98ac41db712b24905f1166ad205052b0b01", null ]
    ] ],
    [ "en_mft_icu_edge_t", "group___group_m_f_t___i_c_u___types.html#ga769ae72756e7da0bac5fe511b9b9fa92", [
      [ "IcuFallingEdge", "group___group_m_f_t___i_c_u___types.html#gga769ae72756e7da0bac5fe511b9b9fa92a51dc90124ce14e08c89c9a0cb79b7f9a", null ],
      [ "IcuRisingEdge", "group___group_m_f_t___i_c_u___types.html#gga769ae72756e7da0bac5fe511b9b9fa92a3506b69b176d98cff7769165a543cffa", null ]
    ] ]
];