var group___group_r_e_s_e_t___functions =
[
    [ "Reset_GetCause", "group___group_r_e_s_e_t___functions.html#gabfa27ebdbb1cb0fd127b9790a2d0146f", null ],
    [ "Reset_GetStoredCause", "group___group_r_e_s_e_t___functions.html#ga225fc4c8b154cba13b2500189ff36051", null ]
];