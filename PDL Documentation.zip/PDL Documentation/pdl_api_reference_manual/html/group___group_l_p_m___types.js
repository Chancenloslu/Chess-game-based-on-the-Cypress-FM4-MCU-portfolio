var group___group_l_p_m___types =
[
    [ "en_lpm_mode_t", "group___group_l_p_m___types.html#gaa3c31a8e785e3febb7e99917e7be561f", [
      [ "StbSleepMode", "group___group_l_p_m___types.html#ggaa3c31a8e785e3febb7e99917e7be561fa9fd3a053ed04feb884e3f342835580e6", null ],
      [ "StbTimerMode", "group___group_l_p_m___types.html#ggaa3c31a8e785e3febb7e99917e7be561fa6cab05885947c14c41e9bb86d616e126", null ],
      [ "StbStopMode", "group___group_l_p_m___types.html#ggaa3c31a8e785e3febb7e99917e7be561fabf5d3b05d24ce3cb0f7e0877a6f9c33c", null ],
      [ "StbRtcMode", "group___group_l_p_m___types.html#ggaa3c31a8e785e3febb7e99917e7be561fa1af01b2808f9a6c2c1ce952d5d1eca26", null ],
      [ "DeepStbRtcMode", "group___group_l_p_m___types.html#ggaa3c31a8e785e3febb7e99917e7be561fad9eb56720abb8ba3a86ff70fd89e29f0", null ],
      [ "DeepStbStopMode", "group___group_l_p_m___types.html#ggaa3c31a8e785e3febb7e99917e7be561fad1879346e63d1bce2a78e038b99b8a9d", null ]
    ] ],
    [ "en_dstb_ret_cause_t", "group___group_l_p_m___types.html#ga4ffe72042fed3d3e3b79f02cc68794b9", [
      [ "DeepStbNoFlag", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a2403bb84eff07181840f26f0948696a3", null ],
      [ "DeepStbInitx", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a5f83ecc4715b64b0036b01933c5a764e", null ],
      [ "DeepStbLvdReset", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a676d34a3df5c445b98bb5341b3dec780", null ],
      [ "DeepStbRtcInt", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a4a00c6f62dbf384bc1f165d0a4cbfb2a", null ],
      [ "DeepStbLvdInt", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a78b2577af248b880a5daacd136cedbd3", null ],
      [ "DeepStbWkupPin0", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a562e33fbc84d305877fce4ef482392c1", null ],
      [ "DeepStbWkupPin1", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9aebb1fba64fc7b483060f5ce9e45d8ddc", null ],
      [ "DeepStbWkupPin2", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9adfa64761fcedf05d5a095c8f7225222e", null ],
      [ "DeepStbWkupPin3", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9ae3809492e6ee497afd1bc8643f33d159", null ],
      [ "DeepStbWkupPin4", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a5d3adf79a4688d0403e674edaf50ec40", null ],
      [ "DeepStbWkupPin5", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9af761d0825e7f7ea0cd58788dd9eaabec", null ],
      [ "DeepStbCec0", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9ab5b185039cd1d667be0984e8044caf4a", null ],
      [ "DeepStbCec1", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9ad9774a8eed58475a14ec5d95e3f3c288", null ],
      [ "DeepStbWkupPin6", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a4f66c663678b4cd615388b8bd614df31", null ],
      [ "DeepStbWkupPin7", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a0fe0456bd36d96c9614747db35cbabce", null ],
      [ "DeepStbWkupPin8", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a16a902e75096f0607303cdb5a9051d87", null ],
      [ "DeepStbWkupPin9", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9abbdf275e4ff2d391039199bccd7f1a52", null ],
      [ "DeepStbWkupPin10", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a6539e8d1a7d6aaa73127967ba3a213e7", null ],
      [ "DeepStbWkupPin11", "group___group_l_p_m___types.html#gga4ffe72042fed3d3e3b79f02cc68794b9a0ad1227aa617347704052232b96c0378", null ]
    ] ],
    [ "en_dstb_wkup_pin_t", "group___group_l_p_m___types.html#ga3653b955904caab3b25c90bf745f79c2", [
      [ "WkupPin1", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2aabc7e9ae4f00cfadd2a87cc3b5dcf4ec", null ],
      [ "WkupPin2", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2a8883ef0bbaf3887b646d7a124a0390f9", null ],
      [ "WkupPin3", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2aa51c935849d111d16924aae93ba835e0", null ],
      [ "WkupPin4", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2a6686397df082a28fa655ef7d978d6d7a", null ],
      [ "WkupPin5", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2ac9bfb17deebc1594f419674c27da6622", null ],
      [ "WkupPin6", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2a0919f0e8ba4404f466abeee7d97b3d43", null ],
      [ "WkupPin7", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2a52adcbfab64e20173f905428398b4529", null ],
      [ "WkupPin8", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2ae1b5b4cb3a6d26d306bf8d1d52e3378f", null ],
      [ "WkupPin9", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2aee39ac6eb93b507a90382fac7c44e8ed", null ],
      [ "WkupPin10", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2ab850ca53f72d67d2a8aa342c07f4bd68", null ],
      [ "WkupPin11", "group___group_l_p_m___types.html#gga3653b955904caab3b25c90bf745f79c2a619f178bfdad584a400cd280d0184aca", null ]
    ] ],
    [ "en_wkup_valid_level_t", "group___group_l_p_m___types.html#ga509b868989315c5cfc33a3f52c205400", [
      [ "WkupLowLevelValid", "group___group_l_p_m___types.html#gga509b868989315c5cfc33a3f52c205400aa5d6ae830c50363da735e854a97a3dc2", null ],
      [ "WkupHighLevelValid", "group___group_l_p_m___types.html#gga509b868989315c5cfc33a3f52c205400aa5f9f91e0b9f678b53e59a51b8e83b2a", null ]
    ] ],
    [ "en_lpm_internal_voltage_t", "group___group_l_p_m___types.html#ga927b997d578b05aa82e2dedcf0f1f3cd", [
      [ "LpmInternalVoltage120", "group___group_l_p_m___types.html#gga927b997d578b05aa82e2dedcf0f1f3cdaf656fce6b6690a8c92b3810b1690bdfd", null ],
      [ "LpmInternalVoltage105", "group___group_l_p_m___types.html#gga927b997d578b05aa82e2dedcf0f1f3cdaf950eebbf5af8c021066047e76078bc0", null ],
      [ "LpmInternalVoltage110", "group___group_l_p_m___types.html#gga927b997d578b05aa82e2dedcf0f1f3cda61a049bc981ee08a8aaffc71eafc642f", null ]
    ] ],
    [ "en_lpm_main_osc_t", "group___group_l_p_m___types.html#gad05daa155c4898e6c64e39d6e778f676", [
      [ "LpmMainOsc4M", "group___group_l_p_m___types.html#ggad05daa155c4898e6c64e39d6e778f676a5c864df39854fc88a831709dcc8663e0", null ],
      [ "LpmMainOsc4M8M", "group___group_l_p_m___types.html#ggad05daa155c4898e6c64e39d6e778f676aa040441bdf427895dee3cdeb67942e20", null ],
      [ "LpmMainOsc4M8M16M", "group___group_l_p_m___types.html#ggad05daa155c4898e6c64e39d6e778f676a605e8f85f33905a8c306a75a1cf2992b", null ],
      [ "LpmMainOsc48M", "group___group_l_p_m___types.html#ggad05daa155c4898e6c64e39d6e778f676a39672ecc19412e07e37d24eba4d018de", null ]
    ] ],
    [ "en_dstb_bakup_reg_t", "group___group_l_p_m___types.html#ga633745dbd996473df504c40bf748ef57", [
      [ "BackupReg1", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a819b8bd2fae80a7a236a8687177e3faa", null ],
      [ "BackupReg2", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a888ded53bc5258694eec0e6c1fa24beb", null ],
      [ "BackupReg3", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57ae677a9d116675097a0718cc51f82bcf5", null ],
      [ "BackupReg4", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a15db3ca338722198169f97df38aded10", null ],
      [ "BackupReg5", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a1d3ccaa03d89b95b54ab2804e13045b7", null ],
      [ "BackupReg6", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57aa8d803b7ba5f72987f34e2aa4e06b7ca", null ],
      [ "BackupReg7", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a48baf78ea260aadff732b64526d1f8e1", null ],
      [ "BackupReg8", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57aeabfbff207d6793ab41a44a149b23f28", null ],
      [ "BackupReg9", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a6e7fc72974650c2293d47aa8a279b93d", null ],
      [ "BackupReg10", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a2e4eb2381ab4fe99749e8eac08e9d171", null ],
      [ "BackupReg11", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a34ffc76dfd0a3b00c9fd9eea9a1c131e", null ],
      [ "BackupReg12", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57aacafcaa53207ed4e079dd6d2a4f79b1e", null ],
      [ "BackupReg13", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a1ceac050dfb7cae3c8dd28416dfeee57", null ],
      [ "BackupReg14", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57aef9333f029b6973e2478c8fb9999a07a", null ],
      [ "BackupReg15", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a928d991613bbdf5afca5e4a6539b3f66", null ],
      [ "BackupReg16", "group___group_l_p_m___types.html#gga633745dbd996473df504c40bf748ef57a863df794048bc4827b34241fd934fc21", null ]
    ] ]
];