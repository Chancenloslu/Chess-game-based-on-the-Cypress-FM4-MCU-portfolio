var group___group_p_c_r_c___types =
[
    [ "en_crc_data_format_t", "group___group_p_c_r_c___types.html#ga254b95e254300ea62bbb137db5d7a7b0", [
      [ "MsbFirstBigEndian", "group___group_p_c_r_c___types.html#gga254b95e254300ea62bbb137db5d7a7b0ac7d750eef281bffbd516f49651df73d2", null ],
      [ "MsbFirstLittleEndian", "group___group_p_c_r_c___types.html#gga254b95e254300ea62bbb137db5d7a7b0ad88511cb570e744d4f1efa7a3502004a", null ],
      [ "LsbFirstBigEndian", "group___group_p_c_r_c___types.html#gga254b95e254300ea62bbb137db5d7a7b0a42e26d17209e5908e1cc60e9facf7771", null ],
      [ "LsbFirstLittleEndian", "group___group_p_c_r_c___types.html#gga254b95e254300ea62bbb137db5d7a7b0a715af70c77b0f0690f08726e888f0112", null ]
    ] ],
    [ "en_crc_input_data_size_t", "group___group_p_c_r_c___types.html#ga1638ccb381a1af9b4f718ba8cc7e22cd", [
      [ "InputData8Bit", "group___group_p_c_r_c___types.html#gga1638ccb381a1af9b4f718ba8cc7e22cda882787ba28680a6989fc415a67d6c94d", null ],
      [ "InputData16Bit", "group___group_p_c_r_c___types.html#gga1638ccb381a1af9b4f718ba8cc7e22cdac231ed80c8cfae94fd95448b0e3e7650", null ],
      [ "InputData24Bit", "group___group_p_c_r_c___types.html#gga1638ccb381a1af9b4f718ba8cc7e22cdaf933da214db9388ba3d8d2ef1aadee13", null ],
      [ "InputData32Bit", "group___group_p_c_r_c___types.html#gga1638ccb381a1af9b4f718ba8cc7e22cda4bd99b1e06470945a0aabb69d481c176", null ]
    ] ]
];