var group___group_c_s_v___data_structures =
[
    [ "stc_csv_status_t", "structstc__csv__status__t.html", [
      [ "bCsvMainClockStatus", "structstc__csv__status__t.html#a33fbb98540760b40137b5d394f3e94c0", null ],
      [ "bCsvSubClockStatus", "structstc__csv__status__t.html#a44df5b5869f71b7dae08e94ed18c7d85", null ]
    ] ]
];