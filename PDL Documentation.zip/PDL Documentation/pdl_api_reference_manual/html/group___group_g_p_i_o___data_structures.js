var group___group_g_p_i_o___data_structures =
[
    [ "stc_gpio1pin_init_t", "structstc__gpio1pin__init__t.html", [
      [ "bOutput", "structstc__gpio1pin__init__t.html#a5143a0a634e3917cf245a03df24d742a", null ],
      [ "bInitVal", "structstc__gpio1pin__init__t.html#ab0dd892200f15dbc07bb04a6681d507a", null ],
      [ "bPullup", "structstc__gpio1pin__init__t.html#aa59712d63d6c38a29979a18f6150eb1b", null ]
    ] ]
];