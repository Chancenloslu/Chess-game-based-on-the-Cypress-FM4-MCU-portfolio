var group___group_c_l_k =
[
    [ "Macros", "group___group_c_l_k___macros.html", null ],
    [ "Enumerated Types", "group___group_c_l_k___types.html", "group___group_c_l_k___types" ],
    [ "Data Structures", "group___group_c_l_k___data_structures.html", "group___group_c_l_k___data_structures" ],
    [ "Global Variables", "group___group_c_l_k___global_variables.html", null ],
    [ "Functions", "group___group_c_l_k___functions.html", "group___group_c_l_k___functions" ]
];