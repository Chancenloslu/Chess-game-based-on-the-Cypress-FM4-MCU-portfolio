var group___group_c_a_n_f_d___types =
[
    [ "canfd_tx_msg_func_ptr_t", "group___group_c_a_n_f_d___types.html#gad6a2de91bc142395f6bcdb8fe2c4a3af", null ],
    [ "canfd_status_chg_func_ptr_t", "group___group_c_a_n_f_d___types.html#gaa55ba5607e047a9c3e72d7e12747d674", null ],
    [ "canfd_error_func_ptr_t", "group___group_c_a_n_f_d___types.html#ga175b5ca5344cb9e2e647c4b6a3710089", null ],
    [ "en_canfd_prescaler_t", "group___group_c_a_n_f_d___types.html#ga13366ecc07bb90a6a6ad8d47e6174f77", null ],
    [ "en_canfd_mode_t", "group___group_c_a_n_f_d___types.html#ga4f3e0d9f7a16fbf5bdf9a4079b79f6ff", null ],
    [ "en_canfd_clock_t", "group___group_c_a_n_f_d___types.html#ga04c71f62d155b18dce3911922bfbec26", null ],
    [ "en_canfd_status_t", "group___group_c_a_n_f_d___types.html#gac43cdd9dc964b3bf0e39a821b7de3f5e", null ]
];