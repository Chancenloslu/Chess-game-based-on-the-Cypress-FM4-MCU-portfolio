var group___group_u_i_d___data_structures =
[
    [ "stc_unique_id_t", "structstc__unique__id__t.html", [
      [ "u32Uidr0", "structstc__unique__id__t.html#a26d9f695f3768ea73643fc178be9adeb", null ],
      [ "u32Uidr1", "structstc__unique__id__t.html#a5ed1e22731fa4d0c691a3b0c23f14992", null ]
    ] ]
];