var group___group_h_w_w_d_g___data_structures =
[
    [ "stc_hwwdg_config_t", "structstc__hwwdg__config__t.html", [
      [ "u32LoadValue", "structstc__hwwdg__config__t.html#a7c4a10cf1fe95fc4ac1fff8dbeee1407", null ],
      [ "bResetEnable", "structstc__hwwdg__config__t.html#ad51b66c6e9a56890a5de9e0adf33a849", null ],
      [ "pfnHwwdgIrqCb", "structstc__hwwdg__config__t.html#aba3fb743442fc39470629f8d5fa0358a", null ]
    ] ]
];