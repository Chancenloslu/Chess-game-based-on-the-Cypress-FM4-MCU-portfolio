var group___group_l_v_d___functions =
[
    [ "Lvd_IrqHandler", "group___group_l_v_d___functions.html#ga7737a1c350a6e0aaa12ae113b5ded5be", null ],
    [ "Lvd_Init", "group___group_l_v_d___functions.html#ga14bffc159ba60a1ba73c47cd42a9998e", null ],
    [ "Lvd_DeInit", "group___group_l_v_d___functions.html#gab7e81daac2db69e5a818d640e2f2ff36", null ],
    [ "Lvd_EnableReset", "group___group_l_v_d___functions.html#ga6db632ad16f16c60660c0879d0569506", null ],
    [ "Lvd_DisableReset", "group___group_l_v_d___functions.html#gab58dd23d3dd35999138316813ac9d162", null ],
    [ "Lvd_GetResetOperationStatus", "group___group_l_v_d___functions.html#ga264a1b276d6ebe9eb2adb3de59a9bf46", null ],
    [ "Lvd_EnableIrqDetect", "group___group_l_v_d___functions.html#ga184e699af75426ea8f44ab1ba513c332", null ],
    [ "Lvd_DisableIrqDetect", "group___group_l_v_d___functions.html#ga843bd5ba80af74ce8719c4771c17775e", null ],
    [ "Lvd_GetIrqStatus", "group___group_l_v_d___functions.html#gac5e12a1f3de2e0d6c553cc9b15c560d7", null ],
    [ "Lvd_ClrIrqStatus", "group___group_l_v_d___functions.html#gaede65e50b26f0301cc5bcdaabdfa9ea0", null ],
    [ "Lvd_GetIrqOperationStatus", "group___group_l_v_d___functions.html#ga9486272fa05aaac75422e978e99bf9e2", null ]
];