var group___group_v_b_a_t___data_structures =
[
    [ "stc_vbat_config_t", "structstc__vbat__config__t.html", [
      [ "u8ClkDiv", "structstc__vbat__config__t.html#aabcbee336d8dfd9d32543c15ae55ee6b", null ],
      [ "bLinkSubClk", "structstc__vbat__config__t.html#ad4283de6293eee8bef7d155db30f9ceb", null ],
      [ "bVbatClkEn", "structstc__vbat__config__t.html#a6c6f52ed42222116651b1a743af475db", null ],
      [ "enSustainCurrent", "structstc__vbat__config__t.html#a13271bb8d16ecba20ab81bb9d54a1bfe", null ],
      [ "enBoostCurrent", "structstc__vbat__config__t.html#ad6846eade47855c4a310bd54e12a3659", null ],
      [ "enClkBoostTime", "structstc__vbat__config__t.html#aef7a9593020e70b5b6581025a8472b59", null ]
    ] ]
];