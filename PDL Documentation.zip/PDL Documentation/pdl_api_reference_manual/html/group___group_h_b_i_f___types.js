var group___group_h_b_i_f___types =
[
    [ "en_hbif_status_t", "group___group_h_b_i_f___types.html#ga4a0c9cd99d882f0f8537fa84e60c8271", [
      [ "HbifRstoDuringWrite", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271afddb5cd830fabd4a1e9b0b3afeeea149", null ],
      [ "HbifTransactionErrDuringWrite", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271af89d10025c61821176adc102b5932db4", null ],
      [ "HbifDecodeErrDuringWrite", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271a651516cb55c2d4861f0b029169f2b01a", null ],
      [ "HbifWriteActive", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271abf79aecab1a7f70fbd4661b20ed373d7", null ],
      [ "HbifRdsStallDuringRead", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271a5ab72e77d4086f18f7bfb1c057673756", null ],
      [ "HbifRstoDuringRead", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271afbef238c5b840307771036debe862583", null ],
      [ "HbifTransactionErrDuringRead", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271a3295bcba4661ee2a15abda149d18fe1d", null ],
      [ "HbifDecodeErrDuringRead", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271a144716a85d2f939b517a499bbec79f0f", null ],
      [ "HbifReadActive", "group___group_h_b_i_f___types.html#gga4a0c9cd99d882f0f8537fa84e60c8271a0ba18671cc03c6b17985e4e71f3ff686", null ]
    ] ],
    [ "en_hbif_wrap_size_t", "group___group_h_b_i_f___types.html#ga897d311be51d6bb2f9c3238ec4b6a9ef", [
      [ "HbifWrap64Bytes", "group___group_h_b_i_f___types.html#gga897d311be51d6bb2f9c3238ec4b6a9efaeaae8452e679cac88b5fe72ecb6f6b1b", null ],
      [ "HbifWrap16Bytes", "group___group_h_b_i_f___types.html#gga897d311be51d6bb2f9c3238ec4b6a9efa25b77494c718c5f93e0c1c2b0d777779", null ],
      [ "HbifWrap32Bytes", "group___group_h_b_i_f___types.html#gga897d311be51d6bb2f9c3238ec4b6a9efa35cfa6fb7aa769a9cce0e209dbe3aec9", null ]
    ] ],
    [ "en_hbif_wcshi_cycle_t", "group___group_h_b_i_f___types.html#gaa32536b3e62f64a132f4b6abd7169a8c", [
      [ "HbifCshi15Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca8df762b5f1f49a6e1c03cfec68cd0ffd", null ],
      [ "HbifCshi25Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca9297df9fe4c153e6a3c57816c43b2b66", null ],
      [ "HbifCshi35Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca0fa86c320f6890204f4307b0e8cd585e", null ],
      [ "HbifCshi45Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca172d7691b39d5ed4b7c9f431d1b42480", null ],
      [ "HbifCshi55Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8cab447ebe772cfce09106c49c755c21814", null ],
      [ "HbifCshi65Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca2258d3ffb6fbfe70880a161c939835fd", null ],
      [ "HbifCshi75Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca1d50c83621a0ceffa915712071deb84c", null ],
      [ "HbifCshi85Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca41c066c9e65d589e94383ce6e6345d34", null ],
      [ "HbifCshi95Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca55bc0d0999774213d83315bd7a6e17fd", null ],
      [ "HbifCshi105Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8cae480d23eecbfbd8b9b1a6a14f4030d0c", null ],
      [ "HbifCshi115Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8cadb002a6fb8c836ffe61762ac1962ed5f", null ],
      [ "HbifCshi125Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca5d1617ae204f2112e11c04973730a5a8", null ],
      [ "HbifCshi135Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca76821eb66cb7a54955351c9c4f9fa1aa", null ],
      [ "HbifCshi145Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8cad66a34844946a840f6d54184f6c27954", null ],
      [ "HbifCshi155Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca575f645d742271c0034c58c257ac44d5", null ],
      [ "HbifCshi165Clk", "group___group_h_b_i_f___types.html#ggaa32536b3e62f64a132f4b6abd7169a8ca34900a6785a59d182425d88ee29c0eff", null ]
    ] ],
    [ "en_hbif_wcss_cycle_t", "group___group_h_b_i_f___types.html#gabacf63b19c6f0ec21a52695de0c77d17", [
      [ "HbifCcs1Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a2b5f33bc6591a3123fcadfe4080f244c", null ],
      [ "HbifCcs2Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a0ed90d1a1818b71ed8353cefda40a63a", null ],
      [ "HbifCcs3Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17ad0a398250f4817bd0c77069967850151", null ],
      [ "HbifCcs4Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17acbb9f7edfafbee240adea0e9d873dcfa", null ],
      [ "HbifCcs5Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17af770c26dd241918c4ad2db628f36dfa0", null ],
      [ "HbifCcs6Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17ae9ffbe5da59bb38e1906782ca51dbb13", null ],
      [ "HbifCcs7Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a18b3c472db7caf8e7f5d4802bef37a91", null ],
      [ "HbifCcs8Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a78e9aacdf1c519e0d0c55130830e1482", null ],
      [ "HbifCcs9Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a6b152c7655bff2df9c8810fab49c4f70", null ],
      [ "HbifCcs10Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a767dcd6a86e87f3c161063a847678e01", null ],
      [ "HbifCcs11Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17ae11bb327acb04e79c3ecc52bbce0b592", null ],
      [ "HbifCcs12Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a714998f9c9d1020e2b1d35dc0dec8dfc", null ],
      [ "HbifCcs13Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a5cd302f9099a2168a3e377785c780777", null ],
      [ "HbifCcs14Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17a3dffbf6e65eada9903f915f1f8724b75", null ],
      [ "HbifCcs15Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17acc1d99777674d1be9f9d15c5720c818b", null ],
      [ "HbifCcs16Clk", "group___group_h_b_i_f___types.html#ggabacf63b19c6f0ec21a52695de0c77d17ae98ef29479225ec65e888c01350e2a7b", null ]
    ] ],
    [ "en_hbif_wcsh_cycle_t", "group___group_h_b_i_f___types.html#gafeb389f3a017c1689063f283662fb69b", [
      [ "HbifCsh1Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69bad08fec11e97dcefbc38b434a83e3d610", null ],
      [ "HbifCsh2Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba49def3e90069493698d66ff432dcf735", null ],
      [ "HbifCsh3Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69bafd841811242117c03e30c4a2e92976cb", null ],
      [ "HbifCsh4Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba8c7179308183d1f0cf135fb7c95faf19", null ],
      [ "HbifCsh5Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69bac00ecfe387c7a2377ccc839fb94593b0", null ],
      [ "HbifCsh6Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69bada4fd2282877313e4a251357d5cebfc0", null ],
      [ "HbifCsh7Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba12d353ab16c5d321e7da909fdb25f715", null ],
      [ "HbifCsh8Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba05faaf672faabfd861f48c3e030943cb", null ],
      [ "HbifCsh9Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba015f97111b2345764e0f86067e007c1d", null ],
      [ "HbifCsh10Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69bad9cdfef2c0b40021a13c3d733d21b47f", null ],
      [ "HbifCsh11Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69bad06878b816bc222e1d49f9e6b6a0fc4a", null ],
      [ "HbifCsh12Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69baa9f95b96f324da7db1b3f9f226700413", null ],
      [ "HbifCsh13Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69baa53b27222a92275f7734e3f8a4bedd81", null ],
      [ "HbifCsh14Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba439a420e7aa25e19624e1cd6e1df698e", null ],
      [ "HbifCsh15Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba6f0233e3d8c31be219f228a440392b4d", null ],
      [ "HbifCsh16Clk", "group___group_h_b_i_f___types.html#ggafeb389f3a017c1689063f283662fb69ba0085d5e141b35d632683f67de05b21cd", null ]
    ] ],
    [ "en_hbif_ltcy_cycle_t", "group___group_h_b_i_f___types.html#ga05927cadf9d337dbffb1abc7f4d20776", null ]
];