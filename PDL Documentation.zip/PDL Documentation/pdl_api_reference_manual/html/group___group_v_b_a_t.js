var group___group_v_b_a_t =
[
    [ "Functions", "group___group_v_b_a_t___functions.html", "group___group_v_b_a_t___functions" ],
    [ "Data Structures", "group___group_v_b_a_t___data_structures.html", "group___group_v_b_a_t___data_structures" ],
    [ "Enumerated Types", "group___group_v_b_a_t___types.html", null ],
    [ "en_clk_current_t", "group___group_v_b_a_t.html#ga41026243ad1544cd9bdd41361a065dfa", [
      [ "ClkLowPower", "group___group_v_b_a_t.html#gga41026243ad1544cd9bdd41361a065dfaae39b21450476d860af321ec80e3fd75f", null ],
      [ "ClkStandard", "group___group_v_b_a_t.html#gga41026243ad1544cd9bdd41361a065dfaa3f3cf16ad852d12a4a51505bd3060d2a", null ]
    ] ],
    [ "en_clk_boost_time_t", "group___group_v_b_a_t.html#ga296b0e44ce463d53097aadbd14c240c0", [
      [ "ClkBoost50ms", "group___group_v_b_a_t.html#gga296b0e44ce463d53097aadbd14c240c0ad3ce772b319c3edf3dcc536759dc0260", null ],
      [ "ClkBoost63ms", "group___group_v_b_a_t.html#gga296b0e44ce463d53097aadbd14c240c0aeebeb9c2157040b2a543553e70bb31f6", null ],
      [ "ClkBoost125ms", "group___group_v_b_a_t.html#gga296b0e44ce463d53097aadbd14c240c0aff11674831252f49a7206ff256043ddc", null ],
      [ "ClkBoost250ms", "group___group_v_b_a_t.html#gga296b0e44ce463d53097aadbd14c240c0aa29a648f63639c76430ae35141b8bb03", null ]
    ] ],
    [ "en_vbat_gpio_t", "group___group_v_b_a_t.html#gad7a3996066618fb3cfdc38b21700798e", [
      [ "VbatGpioP46", "group___group_v_b_a_t.html#ggad7a3996066618fb3cfdc38b21700798ea34e624bd478348c659b217689b95caaf", null ],
      [ "VbatGpioP47", "group___group_v_b_a_t.html#ggad7a3996066618fb3cfdc38b21700798eae14a27eae8dc43fa349145e96485bc2d", null ],
      [ "VbatGpioP48", "group___group_v_b_a_t.html#ggad7a3996066618fb3cfdc38b21700798ead9c02a183d8406ea7e8a39fc0fa0e532", null ],
      [ "VbatGpioP49", "group___group_v_b_a_t.html#ggad7a3996066618fb3cfdc38b21700798ea79d2c0367cb100d02186e698c41c9e86", null ]
    ] ]
];