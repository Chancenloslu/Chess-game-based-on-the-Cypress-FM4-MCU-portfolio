var group___group_d_m_a___functions =
[
    [ "DmaIrqHandler", "group___group_d_m_a___functions.html#gae263c0c75b155096a58f290596b87f63", null ],
    [ "Dma_EnableIrq", "group___group_d_m_a___functions.html#ga53036b1ed0da35fa622ef04c557191a2", null ],
    [ "Dma_DisableIrq", "group___group_d_m_a___functions.html#gae071bc6ecb1fae4783fd4cf42dbc7124", null ],
    [ "Dma_InitChannel", "group___group_d_m_a___functions.html#gad138b1885328fbd938461ee84adbf1bf", null ],
    [ "Dma_DeInitChannel", "group___group_d_m_a___functions.html#ga8e52d75c046fc3abd2fc6d3bd2188c36", null ],
    [ "Dma_SetIrq10Selector", "group___group_d_m_a___functions.html#ga68b8992d9faed9376086674ed3998b48", null ],
    [ "Dma_SetIrq11Selector", "group___group_d_m_a___functions.html#ga1153b22903dfce5bae3743be18b048a5", null ],
    [ "Dma_SetIrq24Selector", "group___group_d_m_a___functions.html#ga09f043a79e5eea6813b3af46a55c5f49", null ],
    [ "Dma_SetIrq25Selector", "group___group_d_m_a___functions.html#ga7b38c3fa6f2c75f4438324e643c92894", null ],
    [ "Dma_SetIrq26Selector", "group___group_d_m_a___functions.html#ga68c456043d91ce1093d305eb77336362", null ],
    [ "Dma_SetIrq27Selector", "group___group_d_m_a___functions.html#gadd35b69e14c5ae8f3d8cb25adc832884", null ],
    [ "Dma_SetIrq30Selector", "group___group_d_m_a___functions.html#ga47ce49be54b8ac6900586355fdda3f6b", null ],
    [ "Dma_SetIrq31Selector", "group___group_d_m_a___functions.html#ga5926c83b6521e05b13e1a3c2a934895d", null ],
    [ "Dma_SetChannel", "group___group_d_m_a___functions.html#ga5eea05fdb66ef31f55eb6affca954af2", null ],
    [ "Dma_GetStopCause", "group___group_d_m_a___functions.html#ga26ee3326421bbc823c1560ebefa05499", null ],
    [ "Dma_Enable", "group___group_d_m_a___functions.html#gac6a148370109de9b63863710cb822386", null ],
    [ "Dma_Disable", "group___group_d_m_a___functions.html#gadea850c78c03bd4ab9c3d9532e52275b", null ],
    [ "Dma_Pause", "group___group_d_m_a___functions.html#gae0b667d643170abcf26f0b8ffbe3387e", null ],
    [ "Dma_Resume", "group___group_d_m_a___functions.html#ga8bfab7391634c0cb292aeacf49fc4f1c", null ]
];