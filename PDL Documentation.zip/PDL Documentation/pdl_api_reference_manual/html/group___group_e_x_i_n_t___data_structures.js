var group___group_e_x_i_n_t___data_structures =
[
    [ "stc_exint_config_t", "structstc__exint__config__t.html", [
      [ "abEnable", "structstc__exint__config__t.html#aa253822fd607ef9417b8e7f69abf43a9", null ],
      [ "aenLevel", "structstc__exint__config__t.html#a613358b7c52c68671e0fbf48cb200d51", null ],
      [ "apfnExintCallback", "structstc__exint__config__t.html#a1602e2c3e3abc9aa595706da68f562a5", null ],
      [ "bTouchNvic", "structstc__exint__config__t.html#af0974ef1e25e6253c0b36668c1df2f52", null ]
    ] ],
    [ "stc_exint_intern_data_t", "structstc__exint__intern__data__t.html", [
      [ "apfnExintCallback", "structstc__exint__intern__data__t.html#ac6fe3b478291b64ffb5efea851ec3e7c", null ]
    ] ],
    [ "stc_exint_nmi_config_t", "structstc__exint__nmi__config__t.html", [
      [ "pfnNmiCallback", "structstc__exint__nmi__config__t.html#a26e18d5c24cb3eb7e987b9a9b59ffb81", null ]
    ] ],
    [ "stc_exint_nmi_intern_data_t", "structstc__exint__nmi__intern__data__t.html", [
      [ "pfnNmiCallback", "structstc__exint__nmi__intern__data__t.html#a65c1543230be06691c63f4f4be6b5736", null ]
    ] ]
];