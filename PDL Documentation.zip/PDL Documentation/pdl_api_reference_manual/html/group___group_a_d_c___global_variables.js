var group___group_a_d_c___global_variables =
[
    [ "m_astcAdcInstanceDataLut", "group___group_a_d_c___global_variables.html#ga1e5862686d8e0b8997fcad54ddba1b32", null ]
];