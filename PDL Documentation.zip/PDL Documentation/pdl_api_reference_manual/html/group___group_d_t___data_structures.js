var group___group_d_t___data_structures =
[
    [ "stc_dt_channel_config_t", "structstc__dt__channel__config__t.html", [
      [ "u8Mode", "structstc__dt__channel__config__t.html#a6919bd0fbc0747860038aaaf1b83009f", null ],
      [ "u8PrescalerDiv", "structstc__dt__channel__config__t.html#a755f638de93bf9d999a03185fc4dcb21", null ],
      [ "u8CounterSize", "structstc__dt__channel__config__t.html#a613c29d02eb637ab14b5a4aa8dfc4ab0", null ],
      [ "bIrqEnable", "structstc__dt__channel__config__t.html#a58a6381a99b365991cba9b603fce169b", null ],
      [ "pfnIrqCallback", "structstc__dt__channel__config__t.html#aec51fa744e54e0ad4380c4dd6f8dedd4", null ],
      [ "bTouchNvic", "structstc__dt__channel__config__t.html#a19576f96e03483ac0dd8c7d9c4bad2ae", null ]
    ] ],
    [ "stc_dt_intern_data_t", "structstc__dt__intern__data__t.html", [
      [ "pfnIrqCallbackIntern", "structstc__dt__intern__data__t.html#a960979afa4cdb7363f8b2ffa4e291812", null ]
    ] ],
    [ "stc_dt_instance_data_t", "structstc__dt__instance__data__t.html", [
      [ "pstcInstance", "structstc__dt__instance__data__t.html#acba7c65c8c873cae34edddf63c2a8659", null ],
      [ "stcInternData", "structstc__dt__instance__data__t.html#af26f900bb6b24744d242c244c1646808", null ]
    ] ],
    [ "stc_dtn_t", "group___group_d_t___data_structures.html#ga06cf3ff8f647c6e79cf82c5713786daf", null ]
];