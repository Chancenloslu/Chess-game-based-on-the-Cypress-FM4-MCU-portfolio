var group___group_r_e_s_e_t___data_structures =
[
    [ "stc_reset_result_t", "structstc__reset__result__t.html", [
      [ "bPowerOn", "structstc__reset__result__t.html#ade07561cb927edc19c0d598afcef769a", null ],
      [ "bInitx", "structstc__reset__result__t.html#aac1dbc6794872f8ad2c55e98fa22372f", null ],
      [ "bLowVoltageDetection", "structstc__reset__result__t.html#ab403cc49b9707ca0b681d1e1da47732b", null ],
      [ "bSoftwareWatchdog", "structstc__reset__result__t.html#ac414ed11237d261142a92c044d5dd50f", null ],
      [ "bHardwareWatchdog", "structstc__reset__result__t.html#a3c115d351c302016d939f4fa74a0c046", null ],
      [ "bClockSupervisor", "structstc__reset__result__t.html#a8278708827895ea85bbf287157546280", null ],
      [ "bAnomalousFrequency", "structstc__reset__result__t.html#ac7e7d831d70c50de57d2dcf9a4121469", null ],
      [ "bSoftware", "structstc__reset__result__t.html#aad3ed4e62a0ff99c21a8eeee6b9e3232", null ]
    ] ]
];