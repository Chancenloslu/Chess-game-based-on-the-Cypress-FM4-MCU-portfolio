var group___group_c_r =
[
    [ "Functions", "group___group_c_r___functions.html", "group___group_c_r___functions" ],
    [ "Enumerated Types", "group___group_c_r___types.html", "group___group_c_r___types" ]
];