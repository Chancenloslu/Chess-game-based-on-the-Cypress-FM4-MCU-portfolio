var group___group_d_t___types =
[
    [ "en_dt_mode_t", "group___group_d_t___types.html#ga5e009e7bb6036157c2de404d33f6a36c", [
      [ "DtFreeRun", "group___group_d_t___types.html#gga5e009e7bb6036157c2de404d33f6a36ca1b64cbbf24366826ffc155fb1d796026", null ],
      [ "DtPeriodic", "group___group_d_t___types.html#gga5e009e7bb6036157c2de404d33f6a36ca62259a9e26b453870f57f6236750e4ac", null ],
      [ "DtOneShot", "group___group_d_t___types.html#gga5e009e7bb6036157c2de404d33f6a36ca2053f5090c7fe0fe0f0ac1b21615544e", null ]
    ] ],
    [ "en_dt_prescaler_t", "group___group_d_t___types.html#ga9d3b7604f619ce3e83dc692ef72efbeb", [
      [ "DtPrescalerDiv1", "group___group_d_t___types.html#gga9d3b7604f619ce3e83dc692ef72efbeba4fc1d5370619ffcb0605816b6e91651e", null ],
      [ "DtPrescalerDiv16", "group___group_d_t___types.html#gga9d3b7604f619ce3e83dc692ef72efbebad81406e6d0ee9be7279a88fb415c31ee", null ],
      [ "DtPrescalerDiv256", "group___group_d_t___types.html#gga9d3b7604f619ce3e83dc692ef72efbeba33a33583caca05a8b6aab3c3225ba727", null ]
    ] ],
    [ "en_dt_countersize_t", "group___group_d_t___types.html#ga417ab52529469288dcfdd88899189061", [
      [ "DtCounterSize16", "group___group_d_t___types.html#gga417ab52529469288dcfdd88899189061a249e4cf099e73cd882ddc687d8e1abdb", null ],
      [ "DtCounterSize32", "group___group_d_t___types.html#gga417ab52529469288dcfdd88899189061a71d8fc1d69f66779eeb91a78a51882c4", null ]
    ] ],
    [ "en_dt_channel_t", "group___group_d_t___types.html#ga72a771c5bea46a4442854432e013c6b5", [
      [ "DtChannel0", "group___group_d_t___types.html#gga72a771c5bea46a4442854432e013c6b5af7f4dcadb88b1daf5594afc0218ebecd", null ],
      [ "DtChannel1", "group___group_d_t___types.html#gga72a771c5bea46a4442854432e013c6b5a53d53f776553dab34b66891c42598432", null ],
      [ "DtMaxChannels", "group___group_d_t___types.html#gga72a771c5bea46a4442854432e013c6b5ae42d9104cbf676686c84a4498f1ad5ac", null ]
    ] ],
    [ "en_dt_instance_index_t", "group___group_d_t___types.html#gae33bb6dc865a2f16c28028b1fee10034", null ]
];