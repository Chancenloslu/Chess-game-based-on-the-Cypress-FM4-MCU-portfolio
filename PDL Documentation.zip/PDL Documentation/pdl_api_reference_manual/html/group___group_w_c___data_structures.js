var group___group_w_c___data_structures =
[
    [ "stc_wc_pres_clk_t", "structstc__wc__pres__clk__t.html", [
      [ "enInputClk", "structstc__wc__pres__clk__t.html#a4091ee757045686f02cc15f15e34f062", null ],
      [ "enOutputClk", "structstc__wc__pres__clk__t.html#a3f0ce3351e4d0e7b015da7236127f4c6", null ]
    ] ],
    [ "stc_wc_config_t", "structstc__wc__config__t.html", [
      [ "enCntClk", "structstc__wc__config__t.html#a75894b40b3d1075a9b4895f7af88dc78", null ],
      [ "u8ReloadValue", "structstc__wc__config__t.html#acf6c01a48d54ac2f45759b40897f61fd", null ],
      [ "bIrqEnable", "structstc__wc__config__t.html#a0f869f7e2004466588bd512be9e95778", null ],
      [ "pfnIrqCallback", "structstc__wc__config__t.html#ae202a025f859e6bc1e306d735cf8a4b4", null ],
      [ "bTouchNvic", "structstc__wc__config__t.html#a304d992ef3805b1021c8641a434fb91d", null ]
    ] ]
];