var group___group_h_w_w_d_g =
[
    [ "Macros", "group___group_h_w_w_d_g___macros.html", null ],
    [ "Functions", "group___group_h_w_w_d_g___functions.html", "group___group_h_w_w_d_g___functions" ],
    [ "Data Structures", "group___group_h_w_w_d_g___data_structures.html", "group___group_h_w_w_d_g___data_structures" ],
    [ "Enumerated Types", "group___group_h_w_w_d_g___types.html", null ]
];