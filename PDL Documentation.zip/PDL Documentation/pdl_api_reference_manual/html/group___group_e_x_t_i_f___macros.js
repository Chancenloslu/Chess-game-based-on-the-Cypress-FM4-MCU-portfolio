var group___group_e_x_t_i_f___macros =
[
    [ "EXITIF_NAND_ALE_OFFSET", "group___group_e_x_t_i_f___macros.html#ga7e6910fffcdf625b585b7bb174167f80", null ],
    [ "EXITIF_NAND_ADDR_OFFSET", "group___group_e_x_t_i_f___macros.html#ga48aa817c3e0eaf5e687ce65a3e666fad", null ],
    [ "EXITIF_NAND_CMD_OFFSET", "group___group_e_x_t_i_f___macros.html#ga2d8d10ef8939c69c6ba79ba8be5f29a6", null ],
    [ "EXITIF_NAND_DATA_OFFSET", "group___group_e_x_t_i_f___macros.html#gabbcc479e4b271444ec090cf7a95d5039", null ],
    [ "Extif_Nand_SetCommand", "group___group_e_x_t_i_f___macros.html#ga6170206c56731d9ad8f11b11df2d1873", null ],
    [ "Extif_Nand_SetAddress", "group___group_e_x_t_i_f___macros.html#ga426cc14791e9eb9c43526b0aa1a78075", null ],
    [ "Extif_Nand_ReadData", "group___group_e_x_t_i_f___macros.html#ga8f624f6f892c844fa2335003c2b5bbab", null ],
    [ "Extif_Nand_WriteData", "group___group_e_x_t_i_f___macros.html#ga07c74393c6fff79532b628af2623b362", null ],
    [ "Extif_Nand_ClearAle", "group___group_e_x_t_i_f___macros.html#ga6940d90745976c11588f95174ea9e1ab", null ]
];