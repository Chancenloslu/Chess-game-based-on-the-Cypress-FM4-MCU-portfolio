var group___group_d_s_t_c___macros =
[
    [ "DSTC_TRANSITION_TIMEOUT", "group___group_d_s_t_c___macros.html#gaf397a9e857e463f753557635182c5040", null ],
    [ "DSTC_PCHK_CALC", "group___group_d_s_t_c___macros.html#ga4941f9cfd92181842a9773ec0f03b073", null ],
    [ "DSTC_IRQ_NUMBER_ADC0_PRIO", "group___group_d_s_t_c___macros.html#ga4afa39dfb25c7bf8553646a62ae9ae9b", null ]
];